export enum ROLES {
  ADMIN = 'Administrator',
  BACK_OFFICE = 'BackOffice',
  AGENT = 'Agent',
  RESELLER = 'Reseller',
}
