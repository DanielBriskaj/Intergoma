import { ROLES } from '../constants/enums/roles';

interface stringToArray {
  [key: string]: Array<string>;
}

const routesWithPermissions: stringToArray = {
  '/': [ROLES.ADMIN, ROLES.AGENT, ROLES.BACK_OFFICE, ROLES.RESELLER],
  '/shopping': [ROLES.ADMIN, ROLES.AGENT, ROLES.RESELLER],
  '/shopping/:id': [ROLES.ADMIN, ROLES.AGENT, ROLES.RESELLER],
  '/shopping-search': [ROLES.ADMIN, ROLES.AGENT, ROLES.RESELLER],
  '/orders': [ROLES.ADMIN, ROLES.AGENT, ROLES.BACK_OFFICE, ROLES.RESELLER],
  '/orders/:id': [ROLES.ADMIN, ROLES.AGENT, ROLES.BACK_OFFICE, ROLES.RESELLER],
  '/cart': [ROLES.AGENT, ROLES.RESELLER],
  '/favorites': [ROLES.ADMIN, ROLES.AGENT, ROLES.RESELLER],
  '/messages': [ROLES.AGENT, ROLES.BACK_OFFICE],
  '/messages/read/:id': [ROLES.AGENT, ROLES.BACK_OFFICE],
  '/users': [ROLES.ADMIN],
  '/users/:id': [ROLES.ADMIN],
  '/account': [ROLES.ADMIN, ROLES.AGENT, ROLES.BACK_OFFICE, ROLES.RESELLER],
  '/login': [],
  '/news': [],
  '/contacts': [],
  '/reports': [ROLES.ADMIN, ROLES.BACK_OFFICE],
};

export default routesWithPermissions;
