import React from 'react';
import CostumLoadable from '../components/Loaders/CostumLoadable';

type Route = {
  caseSensitive?: boolean;
  children?: Route[];
  element?: React.ReactNode;
  path?: string;
};

const Login = () => import('../pages/Login');
const MobileHome = () => import('../pages/Mobile/Home');
const MobileShoppingSearch = () => import('../pages/Mobile/ShoppingSearch');
const MobileShopping = () => import('../pages/Mobile/MobileShopping');
const MobileCart = () => import('../pages/Mobile/Cart');
const MyProfile = () => import('../pages/Profile');
const MobileFavorites = () => import('../pages/Mobile/MobileFavorites');
const MobileMessages = () => import('../pages/Mobile/MobileMessages');
const ReadMessages = () => import('../pages/Mobile/ReadMessages');
const MobileOrders = () => import('../pages/Mobile/MobileOrders');
const MobileEditOrder = () => import('../pages/Mobile/MobileEditOrder');
const MobileUsers = () => import('../pages/Mobile/MobileUsers');
const MobileEditUser = () => import('../pages/Mobile/MobileEditUser');
const UnderDevelopment = () => import('../pages/UnderDev');
const Contacts = () => import('../pages/Contacts');
const Reports = () => import('../pages/Reports');
const MobileArticleDetails = () => import('../pages/Mobile/ArticleDetails');

const mobileRoutes: Route[] = [
  {
    path: '/',
    element: <CostumLoadable loader={MobileHome} path="/" />,
  },
  {
    path: '/login',
    element: <CostumLoadable loader={Login} path="/login" />,
  },
  {
    path: '/shopping-search',
    element: (
      <CostumLoadable loader={MobileShoppingSearch} path="/shopping-search" />
    ),
  },
  {
    path: '/shopping',
    element: <CostumLoadable loader={MobileShopping} path="/shopping" />,
  },
  {
    path: '/shopping/:id',
    element: (
      <CostumLoadable loader={MobileArticleDetails} path="/shopping/:id" />
    ),
  },
  {
    path: '/cart',
    element: <CostumLoadable loader={MobileCart} path="/cart" />,
  },
  {
    path: '/account',
    element: <CostumLoadable loader={MyProfile} path="/account" />,
  },
  {
    path: '/favorites',
    element: <CostumLoadable loader={MobileFavorites} path="/favorites" />,
  },
  {
    path: '/messages',
    element: <CostumLoadable loader={MobileMessages} path="/messages" />,
  },
  {
    path: '/messages/read/:id',
    element: <CostumLoadable loader={ReadMessages} path="/messages/read/:id" />,
  },
  {
    path: '/orders',
    element: <CostumLoadable loader={MobileOrders} path="/orders" />,
  },
  {
    path: '/orders/:id',
    element: <CostumLoadable loader={MobileEditOrder} path="/orders/:id" />,
  },
  {
    path: '/users',
    element: <CostumLoadable loader={MobileUsers} path="/users" />,
  },
  {
    path: '/users/:id',
    element: <CostumLoadable loader={MobileEditUser} path="/users/:id" />,
  },
  {
    path: '/news',
    element: <CostumLoadable loader={UnderDevelopment} path="/news" />,
  },
  {
    path: '/contacts',
    element: <CostumLoadable loader={Contacts} path="/contacts" />,
  },
  {
    path: '/reports',
    element: <CostumLoadable loader={Reports} path="/reports" />,
  },
];

export default mobileRoutes;
