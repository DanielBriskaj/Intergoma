import React from 'react';
import CostumLoadable from '../components/Loaders/CostumLoadable';

type Route = {
  caseSensitive?: boolean;
  children?: Route[];
  element?: React.ReactNode;
  path?: string;
};

const Home = () => import('../pages/Home');
const Shopping = () => import('../pages/Shopping');
const Login = () => import('../pages/Login');
const Orders = () => import('../pages/History');
const Favorites = () => import('../pages/Favorites');
const Messages = () => import('../pages/Messages');
const Users = () => import('../pages/Users');
const MyProfile = () => import('../pages/Profile');
const UnderDevelopment = () => import('../pages/UnderDev');
const Contacts = () => import('../pages/Contacts');
const Reports = () => import('../pages/Reports');

const routes: Route[] = [
  {
    path: '/',
    element: <CostumLoadable loader={Home} path="/" />,
  },
  {
    path: '/shopping',
    element: <CostumLoadable loader={Shopping} path="/shopping" />,
  },
  {
    path: '/orders',
    element: <CostumLoadable loader={Orders} path="/orders" />,
  },
  {
    path: '/login',
    element: <CostumLoadable loader={Login} path="/login" />,
  },
  {
    path: '/favorites',
    element: <CostumLoadable loader={Favorites} path="/favorites" />,
  },
  {
    path: '/messages',
    element: <CostumLoadable loader={Messages} path="/messages" />,
  },
  {
    path: '/users',
    element: <CostumLoadable loader={Users} path="/users" />,
  },
  {
    path: '/account',
    element: <CostumLoadable loader={MyProfile} path="/account" />,
  },

  {
    path: '/news',
    element: <CostumLoadable loader={UnderDevelopment} path="/news" />,
  },
  {
    path: '/contacts',
    element: <CostumLoadable loader={Contacts} path="/contacts" />,
  },
  {
    path: '/reports',
    element: <CostumLoadable loader={Reports} path="/reports" />,
  },
];

export default routes;
