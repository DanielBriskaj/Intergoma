import { Breadcrumb, Modal } from 'antd';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import {
  signUpSchema,
  userSchema,
} from '../../helpers/yupSchemas/signUpSchema';
import InputFormItem from '../InputFormItem';
import SingleSelect from '../SingleSelect';
import { useSignUpMutation } from '../../redux/slices/auth/authApi';
import notificationThrower from '../../helpers/notificationThrower';
import {
  useLazyFetchAllUsersQuery,
  useLazyFetchSingleUserQuery,
  useUpdateUserMutation,
} from '../../redux/slices/users/usersApi';
import { useDispatch, useSelector } from 'react-redux';
import {
  resetUserState,
  selectUserState,
} from '../../redux/slices/users/usersSlice';
import Spinner from '../Spinner';
import { ReactComponent as PersonPlus } from '../../assets/svgIcons/person-plus-fill.svg';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';

export const RoleOptions = [
  { value: 'ADMIN', label: 'Administrator' },
  { value: 'AGENT', label: 'Agent' },
  { value: 'BACK_OFFICE', label: 'Back Office' },
  { value: 'RESELLER', label: 'Reseller' },
];

export const WarehouseOptions = [
  { value: 'MQ', label: 'MQ' },
  { value: 'ML', label: 'ML' },
  { value: 'MC', label: 'MC' },
  { value: 'MSH', label: 'MSH' },
];

type UserInfo =
  | 'firstName'
  | 'lastName'
  | 'username'
  | 'email'
  | 'password'
  | 'warehouse'
  | 'clientCode'
  | 'role';
interface UserModalProps {
  query: any;
  handleResetUsers?: () => void;
}
export const UserModal: React.FC<UserModalProps> = ({
  query,
  handleResetUsers,
}) => {
  const dispatch = useDispatch();
  const userState = useSelector(selectUserState);
  const loggedUser = useSelector(selectLoggedState);
  const { modalOpen, userId } = userState;
  const { userId: loggedUserId } = loggedUser;
  const { innerWidth: screenwidth, innerHeight: height } = window;

  const [signUp] = useSignUpMutation();
  const [updateUser] = useUpdateUserMutation();
  const [getAllUsers] = useLazyFetchAllUsersQuery();

  const [getSingleUser, { data: singleUser }] = useLazyFetchSingleUserQuery();

  const [initialValues, setInitialValues] = useState(() => {
    return {
      firstName: null,
      lastName: null,
      username: null,
      email: null,
      password: null,
      warehouse: null,
      role: null,
      clientCode: null,
    };
  });

  const form = useForm({
    reValidateMode: 'onSubmit',
    resolver: yupResolver(userId ? userSchema : signUpSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const handleSubmit = async (data: any) => {
    const transformedData = {
      id: userId,
      ...data,
      warehouse:
        data?.role === 'AGENT'
          ? data?.warehouse
          : data?.role === 'RESELLER'
          ? 'MQ'
          : null,
    };
    if (userId) {
      updateUser(transformedData)
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'User Updated Successfully',
          });
          handleCloseModal();
          getAllUsers(query);
        })
        .catch(error => {
          if (error?.data === 'Client code was not found in F5') {
            form.setError(
              'clientCode',
              { type: 'focus', message: 'Client Code Not Found!' },
              { shouldFocus: true },
            );
          }
          notificationThrower({
            type: 'error',
            title: 'Failed To Update User',
          });
        });
    } else {
      signUp(transformedData)
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'User Added Successfully',
          });
          handleCloseModal();
          handleResetUsers && handleResetUsers();
          !handleResetUsers && getAllUsers(query);
        })
        .catch(error => {
          if (error?.originalStatus === 409) {
            form.setError(
              'username',
              { type: 'focus', message: 'Username already exists!' },
              { shouldFocus: true },
            );
          } else if (error?.data === 'Client code was not found in F5') {
            form.setError(
              'clientCode',
              { type: 'focus', message: 'Client Code Not Found!' },
              { shouldFocus: true },
            );
          } else {
            notificationThrower({
              type: 'error',
              title: 'Something Went Wrong',
            });
          }
        });
    }
  };

  const handleCloseModal = () => {
    dispatch(resetUserState());
  };

  useEffect(() => {
    if (userId) {
      getSingleUser({ id: userId });
    }
  }, [userId]);

  const value = (options: any, value: any, name: UserInfo) => {
    if (value != null) {
      form.setValue(name, value);
      return options.find((option: any) => option.value === value);
    }
    return null;
  };

  useEffect(() => {
    if (singleUser) {
      setInitialValues(() => {
        return {
          firstName: singleUser?.firstName,
          lastName: singleUser?.lastName,
          username: singleUser?.username,
          email: singleUser?.email,
          role: singleUser?.role,
          warehouse: singleUser?.warehouse,
          clientCode: singleUser?.clientCode,
          password: null,
        };
      });
    }
  }, [singleUser]);

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Users</Breadcrumb.Item>
          <Breadcrumb.Item>{userId ? 'Edit User' : 'New User'}</Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      visible={modalOpen}
      footer={null}
      onCancel={handleCloseModal}
      className={`user-modal ${
        screenwidth < 840 && `animate__animated  animate__fadeInUp`
      }`}
      transitionName={screenwidth < 840 ? '' : undefined}
      maskTransitionName={screenwidth < 840 ? '' : undefined}
    >
      {userId && !singleUser ? (
        <Spinner />
      ) : (
        <FormProvider {...form}>
          <form
            className="user-form"
            onSubmit={form.handleSubmit(handleSubmit)}
            autoComplete="off"
          >
            <InputFormItem
              name="firstName"
              placeholder="Firstname"
              defaultValue={initialValues?.firstName}
            />
            <InputFormItem
              name="lastName"
              placeholder="Lastname"
              defaultValue={initialValues?.lastName}
            />
            <InputFormItem
              name="email"
              placeholder="Email"
              defaultValue={initialValues?.email}
            />
            <InputFormItem
              name="username"
              placeholder="Username"
              disabled={Boolean(userId)}
              defaultValue={initialValues?.username}
            />
            <SingleSelect
              name="role"
              options={RoleOptions}
              placeholder="Role"
              controlledValue={value(RoleOptions, initialValues?.role, 'role')}
              onChange={(e: any) => {
                setInitialValues((oldInitialValues: any) => {
                  return {
                    ...oldInitialValues,
                    role: e.value,
                  };
                });
              }}
              isSearchable={false}
              disabled={userId === loggedUserId}
            />

            {initialValues?.role === 'AGENT' && (
              <SingleSelect
                name="warehouse"
                options={WarehouseOptions}
                placeholder="Warehouse"
                controlledValue={value(
                  WarehouseOptions,
                  initialValues?.warehouse,
                  'warehouse',
                )}
                onChange={(e: any) => {
                  setInitialValues((oldInitialValues: any) => {
                    return {
                      ...oldInitialValues,
                      warehouse: e.value,
                    };
                  });
                }}
                isSearchable={false}
              />
            )}

            {initialValues?.role === 'RESELLER' && (
              <InputFormItem
                name="clientCode"
                placeholder="Client Code"
                defaultValue={initialValues?.clientCode}
              />
            )}

            {!userId && (
              <>
                <InputFormItem
                  name="password"
                  placeholder="Password"
                  type="password"
                />

                <InputFormItem
                  name="confirmPassword"
                  placeholder="Confirm Password"
                  type="password"
                />
              </>
            )}
            <div className="form-footer">
              <button className="btn-primary" type="submit">
                {userId ? (
                  'Save'
                ) : (
                  <span>
                    Register <PersonPlus className="person-svg" />{' '}
                  </span>
                )}
              </button>
            </div>
          </form>
        </FormProvider>
      )}
    </Modal>
  );
};
