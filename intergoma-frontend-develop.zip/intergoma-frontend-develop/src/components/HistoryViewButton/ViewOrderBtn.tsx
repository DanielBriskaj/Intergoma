import React from 'react';
import { useDispatch } from 'react-redux';
import { downloadPDF } from '../../redux/slices/order/orderSlice';
import { ReactComponent as Download } from '../../assets/svgIcons/download.svg';

interface ButtonProps {
  record: any;
}

export const OrderButton: React.FunctionComponent<ButtonProps> = ({
  record,
}) => {
  const dispatch = useDispatch();
  const handleDownloadOrder = () => {
    dispatch(downloadPDF(record.key));
  };

  return (
    <Download
      fill="#014e9e"
      className="download-svg"
      onClick={handleDownloadOrder}
    />
  );
};
