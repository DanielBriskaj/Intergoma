import React from 'react';
import { useDispatch } from 'react-redux';
import { openOrderForm } from '../../redux/slices/order/orderSlice';
import { ReactComponent as Edit } from '../../assets/svgIcons/pencil-square.svg';
interface ButtonProps {
  record: any;
}
export const EditOrder: React.FC<ButtonProps> = ({ record }) => {
  const dispatch = useDispatch();

  const handleEditOrder = () => {
    dispatch(openOrderForm(record.key));
  };

  return <Edit fill="#014e9e" className="edit-svg" onClick={handleEditOrder} />;
};
