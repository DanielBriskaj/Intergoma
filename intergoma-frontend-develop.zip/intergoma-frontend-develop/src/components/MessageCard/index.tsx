export { MessageCard as default } from './MessageCard';
