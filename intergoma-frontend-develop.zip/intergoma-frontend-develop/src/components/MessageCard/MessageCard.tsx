import React from 'react';
import { Message } from '../../interfaces/message';
import { format, parseISO } from 'date-fns';
import { ReactComponent as CheckAll } from '../../assets/svgIcons/check2-all.svg';

interface MessageCardProps extends Message {
  handleMessageClick: (id: number) => void;
  openMsg: number | null;
}

export const MessageCard: React.FC<MessageCardProps> = ({
  id,
  messageText,
  sender,
  sentDate,
  isRead,
  handleMessageClick,
  openMsg,
}) => {
  return (
    <div
      className="message-card-container"
      onClick={() => handleMessageClick(id)}
    >
      <div className={`wrapper ${openMsg === id ? 'active' : ''}`}>
        <div className="header">
          <div className="date">{format(parseISO(sentDate), 'dd-MM-yyyy')}</div>
          <div className="sender">Sent By {sender?.username}</div>
          {isRead && <CheckAll className="check" />}
        </div>
        <div className="text">{messageText}</div>
      </div>
    </div>
  );
};
