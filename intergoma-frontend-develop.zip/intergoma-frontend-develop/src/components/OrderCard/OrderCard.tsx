import React from 'react';
import { OrderProps } from '../../interfaces/order';
import { ReactComponent as Checklist } from '../../assets/svgIcons/checklist.svg';
import { format, parseISO } from 'date-fns';
import getOrderStatusLabel from '../../helpers/order/orderStatusLabel';
import { useNavigate } from 'react-router';
import getTotalPrice from '../../helpers/order/getTotalPrice';

export const OrderCard: React.FC<OrderProps> = ({
  id,
  documentDate,
  clientCode,
  user,
  orderArticles,
  orderStatus,
}) => {
  const navigate = useNavigate();

  const totalItems = orderArticles
    .map(article => {
      let total = 0;
      total += article?.quantity;
      return total;
    })
    .reduce((a, b) => a + b, 0);

  const pricesArray = orderArticles?.map(
    article => article?.quantity * article?.sellingPrice,
  );

  const totalPrice = getTotalPrice(pricesArray);

  return (
    <div
      className="order-card-container"
      onClick={() => navigate(`/orders/${id}`)}
    >
      <div className="card-wrapper">
        <div className="section-1">
          <span className="items">
            {totalItems} {totalItems > 1 ? 'Items' : 'Item'}
          </span>
          <Checklist className="checklist-svg" />
        </div>
        <div className="section-2">
          <span className="date">
            <span> Date: </span>
            {format(parseISO(documentDate), 'dd-MM-yyyy')}
          </span>
          <span className="agent">
            <span> Agent:</span> {user?.username}
          </span>
          <span className="client">
            <span> Client Code: </span>
            {clientCode}
          </span>
        </div>
        <div className="section-3">
          <span className="total">
            <span>€ </span>
            {totalPrice?.toLocaleString('en-US')}
          </span>
          <span className="status">{getOrderStatusLabel(orderStatus)}</span>
        </div>
      </div>
    </div>
  );
};
