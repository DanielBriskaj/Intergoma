export { OrderCard as default } from './OrderCard';
