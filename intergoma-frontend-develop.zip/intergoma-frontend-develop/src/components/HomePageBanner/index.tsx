export { Banner as default } from './Banner';
