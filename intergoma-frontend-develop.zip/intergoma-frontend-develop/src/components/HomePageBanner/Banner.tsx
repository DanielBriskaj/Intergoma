import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination, Navigation, Autoplay } from 'swiper';
import Goodrich from '../../assets/images/bf-goodrich.jpg';
import Continental from '../../assets/images/continental.jpg';
import Dunlop from '../../assets/images/dunlop.jpg';
import GoodYear from '../../assets/images/goodyear.jpg';
import KellyTires from '../../assets/images/kelly-tires.jpg';
import Michelin from '../../assets/images/michelin.jpg';
import RadarTires from '../../assets/images/radar-tires.jpg';
import SavaTires from '../../assets/images/sava-tires.jpg';
import TigarTires from '../../assets/images/tigar-tires.jpg';

import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';

export const Banner: React.FC = () => {
  return (
    <div className="home-banner">
      <Swiper
        pagination={{
          type: 'progressbar',
        }}
        autoplay={{
          delay: 3500,
          disableOnInteraction: false,
        }}
        navigation={true}
        effect="flip"
        loop={true}
        slidesPerView="auto"
        loopedSlides={2}
        speed={400}
        modules={[Autoplay, Pagination, Navigation]}
        className="mySwiper"
      >
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${Goodrich})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${Continental})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>{' '}
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${Dunlop})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>{' '}
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${GoodYear})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>{' '}
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${KellyTires})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${Michelin})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${RadarTires})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${SavaTires})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>
        <SwiperSlide>
          <div
            className="custom-slide"
            style={{
              backgroundImage: `url(${TigarTires})`,
              backgroundPosition: 'center',
              backgroundSize: 'cover',
              height: '300px',
            }}
          ></div>
        </SwiperSlide>
      </Swiper>
    </div>
  );
};
