import React from 'react';
import { useFormContext } from 'react-hook-form';
import FormErrors from '../FormErrors';

interface TextAreaFormItemProps {
  name: string;
  label?: string;
  placeholder?: string;
  required?: boolean;
  value?: string;
  disabled?: boolean;
  className?: string;
  onChange?: any;
  style?: any;
  rows?: number;
  columns?: number;
}

export const TextArea: React.FunctionComponent<TextAreaFormItemProps> = ({
  name,
  label,
  placeholder,
  required,
  value,
  disabled,
  className,
  onChange,
  style,
  rows,
  columns,
}) => {
  const {
    register,
    formState: { touchedFields, isSubmitted, errors },
    setValue,
  } = useFormContext();
  const errorMessage = FormErrors.errorMessage(
    name,
    errors,
    touchedFields,
    isSubmitted,
  );

  return (
    <div className="text-area-input-box">
      <label className="form-label">{label}</label>
      <textarea
        id={name}
        defaultValue={value}
        {...register(name)}
        placeholder={placeholder}
        disabled={disabled}
        className={`${
          errorMessage ? 'invalid-input' : disabled ? 'disabled' : ''
        } + ${className}`}
        style={style}
        onChange={e => {
          onChange && onChange(e.target.value);
          setValue(name, e.target.value);
        }}
        required={required}
        rows={rows}
        cols={columns}
        maxLength={4000}
      />
      {errorMessage && (
        <div className="error-message">{name && errorMessage}</div>
      )}
    </div>
  );
};

TextArea.defaultProps = {
  rows: 5,
  columns: 60,
  required: false,
};
