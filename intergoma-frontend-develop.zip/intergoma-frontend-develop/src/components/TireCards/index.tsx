export { TireCards as default } from './TireCards';
