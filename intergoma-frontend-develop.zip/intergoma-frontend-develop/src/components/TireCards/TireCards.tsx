import React, { useEffect, useState } from 'react';
import MichelinTire from '../../assets/images/pirelli.png';
import { useDispatch } from 'react-redux';
import {
  addItemToCart,
  changeQuantityOnCart,
  removeItemFromCart,
} from '../../redux/slices/cart/cartSlice';
import notificationThrower from '../../helpers/notificationThrower';
import { ReactComponent as Cart } from '../../assets/svgIcons/cart-plus.svg';
import { TireCardsProps } from '../../interfaces/shopping';
import { ReactComponent as Star } from '../../assets/svgIcons/star.svg';
import { ReactComponent as StarFill } from '../../assets/svgIcons/star-fill.svg';
import { ReactComponent as Delete } from '../../assets/svgIcons/trash-fill.svg';
import {
  useAddFavoriteMutation,
  useDeleteFavoriteMutation,
} from '../../redux/slices/favorites/favoritesApi';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';
import { useLocation, useNavigate } from 'react-router';
import { ReactComponent as Car } from '../../assets/svgIcons/car.svg';
import { ReactComponent as FWD } from '../../assets/svgIcons/4x4Car.svg';
import { ReactComponent as Van } from '../../assets/svgIcons/van.svg';
import { ReactComponent as Truck } from '../../assets/svgIcons/truck.svg';
import { ReactComponent as Sun } from '../../assets/svgIcons/sun.svg';
import { ReactComponent as Snowflake } from '../../assets/svgIcons/snowflake.svg';

export const TireCards: React.FC<TireCardsProps> = item => {
  const {
    id,
    brand,
    price,
    available,
    description,
    size,
    favorite,
    quantity,
    car,
    season,
    year,
  } = item;

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const role = getUserRole();
  const location = useLocation();
  const { pathname } = location;
  const [quantity2, setQuantity2] = useState<number>(available === 0 ? 0 : 1);
  const [itemPrice, setItemPrice] = useState<number>(price);
  const [favorite2, setFavorite2] = useState<boolean>(favorite);

  const [addFavorite] = useAddFavoriteMutation();
  const [deleteFavorite] = useDeleteFavoriteMutation();

  const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    if (available > 0 && quantity2 > 0 && quantity2 <= available) {
      const currentItem = {
        ...item,
        price: itemPrice,
      };
      dispatch(addItemToCart({ item: currentItem, quantity: quantity2 }));
    } else if (available > 0 && quantity2 < 1) {
      notificationThrower({
        type: 'warning',
        title: 'Amount must be higher than 0',
        toastId: id,
      });
    } else if (available < 1) {
      notificationThrower({
        type: 'info',
        title: 'Item not in stock',
        toastId: id,
      });
    } else if (quantity2 > available) {
      notificationThrower({
        type: 'warning',
        title: 'Amount is higher than available stock',
      });
      role !== ROLES.RESELLER && setQuantity2(available);
    }
  };

  const handleFavorite = async (type: string, articleCode: string) => {
    switch (type) {
      case 'add':
        addFavorite({ articleCode })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Item Added To Favorites Successfully',
            });
            setFavorite2(!favorite2);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Add Item To Favorites',
            });
          });
        break;
      case 'remove':
        deleteFavorite({ articleCode })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Item Removed From Favorites Successfully',
            });
            setFavorite2(!favorite2);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Remove Item From Favorites',
            });
          });
        break;
    }
  };

  useEffect(() => {
    if (pathname === '/cart') {
      setQuantity2(Number(quantity));
      setItemPrice(price);
    }
  }, [quantity]);

  const handleChangeQuantity = (e: number) => {
    const newQuantity = Math.abs(e);
    setQuantity2(newQuantity);
    if (pathname === '/cart') {
      if (available > 0 && newQuantity > 0 && newQuantity <= available) {
        dispatch(changeQuantityOnCart({ item, quantity: Math.abs(e) }));
      } else if (available > 0 && newQuantity < 1) {
        notificationThrower({
          type: 'warning',
          title: 'Amount must be higher than 0',
          toastId: id,
        });
      } else if (newQuantity > available) {
        notificationThrower({
          type: 'warning',
          title: 'Amount is higher than available stock',
          toastId: id,
        });
        setQuantity2(available);
        dispatch(changeQuantityOnCart({ item, quantity: available }));
      }
    }
  };

  const renderCarIcon = (type: string | undefined) => {
    switch (type) {
      case 'Veture':
        return <Car className="car-svg" />;
      case '4x4':
        return <FWD className="car-svg" />;
      case 'Furgon':
        return <Van className="car-svg" />;
      case 'Kamion':
        return <Truck className="car-svg" />;
      default:
        return;
    }
  };

  const renderSeasonIcon = (season: string | undefined) => {
    switch (season) {
      case 'Vere':
        return <Sun className="season-svg" />;
      case 'Dimer':
        return <Snowflake className="season-svg" />;
      case '4Stinet':
        return (
          <>
            <Sun className="season-svg" /> <Snowflake className="season-svg" />
          </>
        );
      default:
        return;
    }
  };

  const handleOpenDetails = () => {
    if (pathname !== `/shopping/${id}` && pathname !== `/cart`) {
      navigate(`/shopping/${id}`);
    }
  };

  return (
    <div className="tire-card-container" onClick={handleOpenDetails}>
      <div className="card-wrapper">
        <div className="card-image">
          <img src={MichelinTire} alt="Tire Image" loading="lazy" />
          {favorite2 ? (
            <StarFill
              className="favorite-svg"
              onClick={e => {
                handleFavorite('remove', id);
                e.stopPropagation();
              }}
            />
          ) : (
            <Star
              className="favorite-svg"
              onClick={e => {
                handleFavorite('add', id);
                e.stopPropagation();
              }}
            />
          )}
        </div>
        <div className="card-body">
          <div className="section1">
            <div className="brand">
              {brand} {renderCarIcon(car)}
              {renderSeasonIcon(season)}
            </div>
            <div className="description">{description}</div>
          </div>
          <div className="section2">
            <div className="tire-size">{size}</div>
            {role !== ROLES.ADMIN && (
              <div className="tire-quantity">
                QTY:
                <div className="input-box">
                  <input
                    name="quantity"
                    type="number"
                    min="1"
                    max={available}
                    value={quantity2}
                    onChange={(e: any) => handleChangeQuantity(e.target.value)}
                    onFocus={e => e.target.select()}
                    onClick={e => e.stopPropagation()}
                    style={{ borderRadius: 0 }}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="card-purchase">
          <span className="price">
            €
            <div className="input-box">
              <input
                name="price"
                type="number"
                min="0"
                max="9999"
                value={itemPrice}
                onChange={(e: any) => setItemPrice(Math.abs(e.target.value))}
                disabled={role !== 'Agent' || pathname === '/cart'}
                onFocus={e => e.target.select()}
                onClick={e => e.stopPropagation()}
              />
            </div>
          </span>
          <div
            className="stock"
            style={
              role === ROLES.RESELLER
                ? {
                    color:
                      available === 0
                        ? 'red'
                        : available < 4
                        ? 'orange'
                        : '#4CAF50',
                  }
                : {}
            }
          >
            Stock :{' '}
            {role === ROLES.RESELLER
              ? available >= 2
                ? '2+'
                : available
              : available}
          </div>
          {pathname !== '/cart' && role !== ROLES.ADMIN ? (
            <button className="card-btn" onClick={handleAddToCart}>
              <Cart className="cart-svg" />
            </button>
          ) : role !== ROLES.ADMIN ? (
            <button
              className="card-btn"
              onClick={e => {
                dispatch(removeItemFromCart({ cartItemId: id }));
                e.stopPropagation();
              }}
            >
              <Delete className="cart-svg" />
            </button>
          ) : (
            <div style={{ height: '26px' }}></div>
          )}
        </div>
      </div>
    </div>
  );
};
