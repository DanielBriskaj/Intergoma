export { InputFormItem as default } from './InputFormItem';
