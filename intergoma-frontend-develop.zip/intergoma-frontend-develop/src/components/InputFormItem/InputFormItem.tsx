import React, { useEffect, useState } from 'react';
import { useFormContext } from 'react-hook-form';
import useFocus from '../../helpers/focusHook';
import FormErrors from '../FormErrors';

interface InputFormItemProps {
  label?: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  value?: any;
  disabled?: boolean;
  className?: string;
  onChange?: any;
  style?: any;
  defaultValue?: any;
  min?: any;
  max?: any;
  step?: number;
}

export const InputFormItem: React.FunctionComponent<InputFormItemProps> = ({
  label,
  name,
  type,
  placeholder,
  required,
  value,
  disabled,
  className,
  onChange,
  style,
  defaultValue,
  min,
  max,
  step,
}) => {
  const {
    register,
    formState: { touchedFields, isSubmitted, errors },
    setValue,
  } = useFormContext();

  const errorMessage = FormErrors.errorMessage(
    name,
    errors,
    touchedFields,
    isSubmitted,
  );

  useEffect(() => {
    if (defaultValue) {
      setValue(name, defaultValue);
    }
    if (value) {
      setValue(name, value);
    }
  }, [defaultValue, value]);

  return (
    <div className="input-box">
      <label className="form-label">{label}</label>
      <input
        id={name}
        value={value}
        defaultValue={defaultValue}
        {...register(name)}
        type={type}
        placeholder={placeholder}
        disabled={disabled}
        className={`${
          errorMessage ? 'invalid-input' : disabled ? 'disabled' : ''
        } + ${className}`}
        style={style}
        onChange={e => {
          onChange && onChange(e);
          setValue(name, e.target.value);
        }}
        required={required}
        min={min}
        max={max}
        step={step}
      />
      {errorMessage && (
        <div className="error-message">{name && errorMessage}</div>
      )}
    </div>
  );
};

InputFormItem.defaultProps = {
  type: 'text',
  required: false,
};
