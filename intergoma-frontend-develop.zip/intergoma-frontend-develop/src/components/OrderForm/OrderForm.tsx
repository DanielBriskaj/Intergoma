import { Breadcrumb, Modal, Table, Tooltip } from 'antd';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ORDER_STATUS } from '../../constants/enums/orders';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';
import notificationThrower from '../../helpers/notificationThrower';
import { cartSchema } from '../../helpers/yupSchemas/cartSchema';
import { ClientsProps } from '../../interfaces/clients';
import {
  useLazyFetchAllOrdersQuery,
  useLazyFetchSingleOrderQuery,
  useProcessOrderMutation,
} from '../../redux/slices/order/orderApi';
import {
  openOrderForm,
  selectOrder,
} from '../../redux/slices/order/orderSlice';
import Form from '../Form';
import InputFormItem from '../InputFormItem';
import Spinner from '../Spinner';
import TextArea from '../TextArea';
import { format, parseISO } from 'date-fns';

interface OrderFormProps {
  query: any;
}

export const OrderForm: React.FC<OrderFormProps> = ({ query }) => {
  const dispatch = useDispatch();
  const role = getUserRole();
  const order = useSelector(selectOrder);
  const { openForm } = order;
  const [
    getSingleOrder,
    { data: singleOrder, isFetching: singleOrderLoading },
  ] = useLazyFetchSingleOrderQuery();
  const [processOrder] = useProcessOrderMutation();
  const [getAllOrders] = useLazyFetchAllOrdersQuery();

  const handleCloseModal = () => {
    dispatch(openOrderForm(false));
  };

  useEffect(() => {
    getSingleOrder(openForm)
      .unwrap()
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Get Order',
        });
      });
  }, [openForm]);

  const handleProcess = () => {
    const data = {
      orderStatus: ORDER_STATUS.CONFIRMED,
    };
    singleOrder &&
      processOrder({ data, id: singleOrder?.id })
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'Order Processed Successfully',
          });

          getAllOrders(query)
            .unwrap()
            .catch(() => {
              notificationThrower({
                type: 'error',
                title: 'Failed To Get Updated Order List',
              });
            });
          dispatch(openOrderForm(false));
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Process Order',
          });
        });
  };

  const columns = [
    {
      title: 'CODE',
      dataIndex: 'productCode',
      key: 'productCode',
      ellipsis: {
        showTitle: false,
      },
      render: (productCode: string) => (
        <Tooltip placement="topLeft" title={productCode}>
          {productCode}
        </Tooltip>
      ),
    },
    {
      title: 'BRAND',
      dataIndex: 'productType',
      key: 'productType',
      ellipsis: {
        showTitle: false,
      },
      render: (productType: string) => (
        <Tooltip placement="topLeft" title={productType}>
          {productType}
        </Tooltip>
      ),
    },
    {
      title: 'QUANTITY',
      dataIndex: 'quantity',
      key: 'quantity',
      align: 'right' as const,
      ellipsis: {
        showTitle: false,
      },
      render: (quantity: string) => (
        <Tooltip placement="topLeft" title={quantity}>
          {quantity}
        </Tooltip>
      ),
    },
    {
      title: 'SELLING PRICE',
      dataIndex: 'sellingPrice',
      key: 'sellingPrice',
      align: 'right' as const,
      ellipsis: {
        showTitle: false,
      },
      render: (sellingPrice: number) => (
        <Tooltip placement="topLeft" title={sellingPrice}>
          € {sellingPrice?.toLocaleString('en-US')}
        </Tooltip>
      ),
    },
    {
      title: 'TOTAL',
      dataIndex: 'total',
      key: 'total',
      align: 'right' as const,
      ellipsis: {
        showTitle: false,
      },
      render: (total: number) => (
        <Tooltip placement="topLeft" title={total}>
          € {total?.toLocaleString('en-US')}
        </Tooltip>
      ),
    },
  ];
  const tableData = singleOrder?.orderArticles?.map(article => ({
    key: article?.id,
    total: article?.quantity * article?.sellingPrice,
    ...article,
  }));

  const orderTotal = tableData
    ?.map(article => {
      let sum = 0;
      sum += article?.total;
      return sum;
    })
    .reduce((a, b) => a + b, 0);

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Orders</Breadcrumb.Item>
          <Breadcrumb.Item>{`Order ${singleOrder?.id}`}</Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      visible={openForm}
      footer={null}
      width={1300}
      onCancel={handleCloseModal}
      className="order-modal"
    >
      {!singleOrder ? (
        <Spinner />
      ) : (
        <Form
          schema={cartSchema}
          initialValues={undefined}
          onHandleSuccess={handleProcess}
          className="order-form"
        >
          <div className="row">
            <div className="first-half">
              <InputFormItem
                name="clientName"
                label="Client Name"
                defaultValue={singleOrder?.f5Client?.PERSHKRIM}
                disabled={true}
              />
            </div>
            <div className="half-row">
              <InputFormItem
                name="clientCode"
                label="Client Code"
                defaultValue={singleOrder?.clientCode}
                disabled={true}
              />

              <InputFormItem
                name="orderStatus"
                label="Order Status"
                defaultValue={singleOrder?.orderStatus}
                disabled={true}
              />
            </div>
          </div>
          <div className="row">
            <InputFormItem
              name="user"
              label="Agent"
              defaultValue={singleOrder?.user?.username}
              disabled={true}
            />
            <InputFormItem
              name="total"
              label="Order Total"
              defaultValue={`€ ${orderTotal?.toLocaleString('en-US')}`}
              disabled={true}
            />
            <InputFormItem
              name="documentDate"
              label="Date"
              defaultValue={format(
                parseISO(singleOrder?.documentDate),
                'dd-MM-yyyy',
              )}
              disabled={true}
            />
            <InputFormItem
              name="magazineCode"
              label="Warehouse"
              defaultValue={singleOrder?.magazineCode}
              disabled={true}
            />
          </div>
          <div className="row">
            <div className="first-half">
              <InputFormItem
                name="deliveryPlace"
                label="Delivery Place"
                defaultValue={singleOrder?.deliveryPlace}
                disabled={true}
              />
            </div>
          </div>
          <Table
            dataSource={tableData}
            columns={columns}
            style={{ marginTop: '20px' }}
            pagination={{
              defaultPageSize: 5,
              size: 'small',
            }}
          />

          <TextArea
            name="note"
            label="Notes"
            value={singleOrder?.note}
            disabled={true}
          />
          <div className="form-end">
            <button
              type="button"
              className="btn-cancel"
              onClick={handleCloseModal}
            >
              Cancel
            </button>
            {singleOrder?.orderStatus === ORDER_STATUS.CREATED &&
              role === ROLES.BACK_OFFICE && (
                <button
                  type="submit"
                  className="btn-primary"
                  disabled={singleOrderLoading}
                >
                  Process
                </button>
              )}
          </div>
        </Form>
      )}
    </Modal>
  );
};
