import { Spin } from 'antd';
import React from 'react';

interface SpinnerProps {
  wrapperStyle?: React.CSSProperties;
  fullScreen?: boolean;
}

export const Spinner: React.FC<SpinnerProps> = ({
  wrapperStyle,
  fullScreen,
}) => {
  return (
    <div className="spinner-container">
      <div
        className={`${fullScreen ? 'full-spinner' : 'spinner-wrapper '}`}
        style={wrapperStyle}
      >
        <Spin />
      </div>
    </div>
  );
};
