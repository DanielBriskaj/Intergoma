import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import clientDataTransformer from '../../helpers/order/clientDataTransformer';
import { orderDataTransformer } from '../../helpers/order/orderDataTransformer';
import { CartItemProps } from '../../interfaces/cart';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';
import InputFormItem from '../InputFormItem';
import SingleSelect from '../SingleSelect';
import TextArea from '../TextArea';
import { yupResolver } from '@hookform/resolvers/yup';
import notificationThrower from '../../helpers/notificationThrower';
import { cartSchema } from '../../helpers/yupSchemas/cartSchema';
import { ReactComponent as Arrow } from '../../assets/svgIcons/box-arrow-in-right.svg';
import {
  useLazyFetchAllClientsQuery,
  useLazyFetchLightSingleClientQuery,
} from '../../redux/slices/clients/clientsApi';
import { ClientsProps } from '../../interfaces/clients';
import { useCreateOrderMutation } from '../../redux/slices/order/orderApi';
import {
  downloadPDF,
  resetOrderState,
} from '../../redux/slices/order/orderSlice';
import { resetCartState } from '../../redux/slices/cart/cartSlice';
import { getUserRole } from '../../helpers/getUserInfo';
import { ROLES } from '../../constants/enums/roles';

interface CartFormProps {
  cartItems: CartItemProps[];
  toggle?: React.Dispatch<React.SetStateAction<boolean>>;
}
export const CartForm: React.FC<CartFormProps> = ({ cartItems, toggle }) => {
  const dispatch = useDispatch();
  const role = getUserRole();
  const [getAllClients] = useLazyFetchAllClientsQuery();
  const [getResellerInfo, { data: resellerInfo }] =
    useLazyFetchLightSingleClientQuery();
  const [createOrder] = useCreateOrderMutation();
  const user = useSelector(selectLoggedState);
  const { userId, warehouse, clientCode } = user;

  const [address, setAddress] = useState<string>('');
  const [clientsData, setClientsData] = useState<ClientsProps[]>([]);
  const [initialValues] = useState(() => {
    return {
      note: '',
      client: null,
    };
  });
  const form = useForm({
    reValidateMode: 'onBlur',
    resolver: yupResolver(cartSchema),
    mode: 'onChange',
    defaultValues: initialValues,
  });
  const handleSuccess = (data: any) => {
    const transformedData = orderDataTransformer(
      data,
      cartItems,
      userId,
      warehouse,
    );
    createOrder(transformedData)
      .unwrap()
      .then(payload => {
        notificationThrower({
          type: 'success',
          title: 'Order Created Successfully',
        });

        dispatch(downloadPDF(payload?.id));
        dispatch(resetCartState());
        dispatch(resetOrderState());
        toggle && toggle(false);
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Create Order',
        });
      });
  };

  useEffect(() => {
    role !== ROLES.RESELLER
      ? getAllClients(0, true)
          .unwrap()
          .then(payload => {
            setClientsData(payload);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Get Client Data',
            });
          })
      : clientCode &&
        getResellerInfo({ code: clientCode })
          .unwrap()
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Get Client Data',
            });
          });
  }, []);

  return (
    <FormProvider {...form}>
      <form className="cart-form" onSubmit={form.handleSubmit(handleSuccess)}>
        <div className="promo-code">
          <InputFormItem
            name="promote"
            placeholder="Promo Code"
            className="promo-input"
          />
          <button className="btn-primary" type="button">
            Apply
          </button>
        </div>
        <TextArea name="note" placeholder="Order Notes" />
        {role !== ROLES.RESELLER ? (
          <SingleSelect
            name="clientCode"
            options={clientDataTransformer(clientsData)}
            placeholder="Client"
            onChange={(e: any) => setAddress(e.address)}
          />
        ) : (
          <InputFormItem
            name="clientCode"
            placeholder="Client"
            value={resellerInfo?.PERSHKRIM}
            disabled={true}
          />
        )}
        <InputFormItem
          name="deliveryPlace"
          placeholder="Delivery Address"
          value={role === ROLES.RESELLER ? resellerInfo?.ADRESA1 : address}
          onChange={(e: any) => setAddress(e.target.value)}
        />
        <div className="form-footer">
          <button className="btn-primary">
            Confirm Order <Arrow />
          </button>
        </div>
      </form>
    </FormProvider>
  );
};
