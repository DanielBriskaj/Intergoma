import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { addItemToCart } from '../../redux/slices/cart/cartSlice';
import { ReactComponent as CartPlus } from '../../assets/svgIcons/cart-plus.svg';
import { useDispatch } from 'react-redux';
import InputFormItem from '../InputFormItem';
import notificationThrower from '../../helpers/notificationThrower';
import { Tooltip } from 'antd';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';

interface QuantityProps {
  item: any;
}
export const Quantity: React.FC<QuantityProps> = ({ item }) => {
  const dispatch = useDispatch();
  const role = getUserRole();
  const [quantity, setQuantity] = useState<number>(1);
  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });
  useEffect(() => {
    if (item.available < 1) {
      setQuantity(0);
    }
  }, [item]);
  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  const handleIncrease = () => {
    if (role === ROLES.RESELLER) {
      setQuantity(quantity + 1);
    } else if (quantity < item.available) {
      setQuantity(quantity + 1);
    }
  };
  const handleAddToCart = () => {
    if (item.available > 0 && quantity > 0 && quantity <= item.available) {
      dispatch(addItemToCart({ item, quantity }));
    } else if (item.available > 0 && quantity < 1) {
      notificationThrower({
        type: 'warning',
        title: 'Amount must be higher than 0',
      });
    } else if (item.available < 1) {
      notificationThrower({
        type: 'info',
        title: 'Item not in stock',
      });
    } else if (quantity > item.available) {
      notificationThrower({
        type: 'warning',
        title: 'Amount is higher than available stock',
      });
      role !== ROLES.RESELLER && setQuantity(item.available);
    }
  };
  const handleInputChange = (e: any) => {
    setQuantity(Math.abs(e.target.value));
  };
  const handleSubmit = (e: any) => {
    e.preventDefault();
    handleAddToCart();
  };
  return (
    <FormProvider {...formConfig}>
      <form className="table-form" onSubmit={handleSubmit}>
        <div className="table-count">
          <div className="action-button">
            <span className="action" onClick={handleDecrease}>
              -
            </span>
            <InputFormItem
              name="quantity"
              type="number"
              min="1"
              max={item.available}
              value={quantity}
              onChange={(e: any) => handleInputChange(e)}
            />
            <span className="action" onClick={handleIncrease}>
              +
            </span>
          </div>
        </div>
        <Tooltip placement="topLeft" title={'Add To Cart'}>
          <CartPlus
            className="add-cart"
            fill={
              item.available === 0
                ? 'red'
                : item?.available < 4
                ? 'orange'
                : '#25D366'
            }
            onClick={handleAddToCart}
          />
        </Tooltip>
      </form>
    </FormProvider>
  );
};
