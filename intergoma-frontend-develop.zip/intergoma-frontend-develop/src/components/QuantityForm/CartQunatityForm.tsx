import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { changeQuantityOnCart } from '../../redux/slices/cart/cartSlice';
import { useDispatch } from 'react-redux';

interface QuantityProps {
  item: any;
  amount: number;
}
export const CartQuantity: React.FC<QuantityProps> = ({ item, amount }) => {
  const dispatch = useDispatch();
  const [quantity, setQuantity] = useState<number>(amount);
  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  const handleDecrease = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  const handleIncrease = () => {
    if (quantity < item.available) {
      setQuantity(quantity + 1);
    }
  };
  useEffect(() => {
    dispatch(changeQuantityOnCart({ item, quantity }));
  }, [quantity]);

  useEffect(() => {
    setQuantity(amount);
  }, [amount]);

  return (
    <FormProvider {...formConfig}>
      <form className="table-form">
        <div className="table-count">
          <div className="action-button">
            <span className="action" onClick={handleDecrease}>
              -
            </span>
            <span className="quantity">{quantity}</span>
            <span className="action" onClick={handleIncrease}>
              +
            </span>
          </div>
        </div>
      </form>
    </FormProvider>
  );
};
