import React, { useRef, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { ReactComponent as Logo } from '../../assets/svgIcons/logo.svg';
import { ReactComponent as CartSVG } from '../../assets/svgIcons/cart.svg';
import { ReactComponent as Avatar } from '../../assets/svgIcons/person-circle.svg';
import { useDispatch, useSelector } from 'react-redux';
import { getUsername, getUserRole } from '../../helpers/getUserInfo';
import useOutsideClickChecker from '../../helpers/clickOutside';
import {
  resetCartState,
  selectCartItems,
} from '../../redux/slices/cart/cartSlice';
import { Cart } from '../Cart/Cart';
import { ROLES } from '../../constants/enums/roles';
import renderRoutesOnRole from '../../helpers/renderRoutesOnRole';
import { resetLoggedState } from '../../redux/slices/auth/authSlice';
import {
  resetMiscellaneousState,
  selectMessagesNumber,
} from '../../redux/slices/miscellaneous/miscellaneousSlice';
import { articleApi } from '../../redux/slices/articles/articlesApi';

export const Navbar: React.FunctionComponent = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const cartItems = useSelector(selectCartItems);
  const messagesNumber = useSelector(selectMessagesNumber);
  const userName = getUsername();
  const role = getUserRole();
  const [userDrawer, setUserDrawer] = useState<boolean>(false);
  const [openCart, setOpenCart] = useState<boolean>(false);
  const token = localStorage.getItem('idToken');

  const handleLogOut = () => {
    localStorage.clear();
    dispatch(resetCartState());
    dispatch(resetLoggedState());
    dispatch(resetMiscellaneousState());
    dispatch(articleApi.util.resetApiState());
    navigate('/login');
    setUserDrawer(false);
    window.location.reload();
  };

  const drawerRef = useRef(null);
  useOutsideClickChecker(drawerRef, setUserDrawer);
  const links = renderRoutesOnRole(role);

  return (
    <>
      {role && role != ROLES.BACK_OFFICE && (
        <Cart visible={openCart} toggle={setOpenCart} />
      )}
      <div className="navbar-container">
        <div className="navbar-wrapper">
          <div className="logo-container">
            <Link
              to={
                token
                  ? role === ROLES.BACK_OFFICE
                    ? '/orders'
                    : '/shopping'
                  : '/login'
              }
            >
              <Logo />
            </Link>
          </div>
          {token ? (
            <>
              <div className="route-container">
                {links?.map((link, index) => {
                  return link?.label === 'Messages' ? (
                    <NavLink key={index} to={link.link}>
                      {link.label}
                      <div className="badge">{messagesNumber}</div>
                    </NavLink>
                  ) : (
                    <NavLink key={index} to={link.link}>
                      {link.label}
                    </NavLink>
                  );
                })}
              </div>

              <div className="end-section">
                {role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN && (
                  <div
                    className="cartsvg-container"
                    onClick={() => setOpenCart(!openCart)}
                  >
                    <CartSVG className="cart" />
                    <div className="badge">{cartItems.length}</div>
                  </div>
                )}

                <div
                  className="avatar-container"
                  onClick={() => {
                    if (token) {
                      setUserDrawer(!userDrawer);
                    } else {
                      navigate('/login');
                    }
                  }}
                  ref={drawerRef}
                >
                  <span className="username">
                    {userName ? userName : 'Log In'}
                  </span>
                  <Avatar className="avatar" />
                  {userDrawer ? (
                    <div className="user-options">
                      <span
                        className="option"
                        onClick={() => {
                          navigate('/account');
                          setUserDrawer(!userDrawer);
                        }}
                      >
                        My Profile
                      </span>
                      <span
                        className="option"
                        style={{ color: 'red' }}
                        onClick={handleLogOut}
                      >
                        Log Out
                      </span>
                    </div>
                  ) : (
                    ''
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="logged-out-nav">
              <NavLink to={'/login'}>Login</NavLink>
              <NavLink to={'/contacts'}>Contacts</NavLink>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
