import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { CartProps } from '../../interfaces/cart';
import {
  selectCartItems,
  selectTotalCartPrice,
} from '../../redux/slices/cart/cartSlice';
import CartItem from '../CartItem';
import { useNavigate } from 'react-router';
import { ReactComponent as Close } from '../../assets/svgIcons/close.svg';
import { ReactComponent as CartAdd } from '../../assets/svgIcons/cart-plus.svg';
import { ReactComponent as Bag } from '../../assets/svgIcons/shopping-bag.svg';
import { Drawer } from 'antd';
import CartForm from '../CartForm';

export const Cart: React.FC<CartProps> = ({ toggle, visible }) => {
  const navigate = useNavigate();

  const cartItems = useSelector(selectCartItems);
  const totalCartPrice = useSelector(selectTotalCartPrice);

  const [closeHover, setCloseHover] = useState<boolean>(false);

  return (
    <Drawer
      width={650}
      visible={visible}
      placement="right"
      onClose={() => toggle(false)}
    >
      <div className="cart-container">
        <div className={`cart-wrapper`}>
          <div className="cart-header">
            <Close
              className={`close-icon ${
                closeHover ? 'close-enter' : 'close-leave'
              }`}
              onClick={() => toggle(false)}
              onMouseEnter={() => setCloseHover(true)}
              onMouseLeave={() => setCloseHover(false)}
            />
            <div className="cart-title">
              <h2>Order Summary</h2>
            </div>
            <Bag className="shopping-bag" />
          </div>
          {cartItems.length > 0 ? (
            <div className="cart-item-header">
              <div className="item">ITEM</div>
              <div className="price">PRICE</div>
              <div className="quantity">QUANTITY</div>
              <div className="subtotal">SUBTOTAL</div>
            </div>
          ) : (
            ''
          )}

          {cartItems.map((item, index) => {
            return <CartItem key={index} {...item} />;
          })}
          {cartItems.length > 0 ? (
            <>
              <div className="cart-total">
                <span>
                  TOTAL : €{' '}
                  <span className="total">
                    {totalCartPrice?.toLocaleString('en-US')}{' '}
                  </span>
                </span>
              </div>
              <div className="cart-footer">
                <CartForm cartItems={cartItems} toggle={toggle} />
              </div>
            </>
          ) : (
            <div className="cart-empty">
              <span>Your cart is empty.</span>
              <span>Once you add something it will appear here!</span>
              <button
                className="btn-primary"
                onClick={() => {
                  navigate('/shopping');
                  toggle(false);
                }}
              >
                Start Shopping <CartAdd className="cart-add-svg" />
              </button>
            </div>
          )}
        </div>
      </div>
    </Drawer>
  );
};
