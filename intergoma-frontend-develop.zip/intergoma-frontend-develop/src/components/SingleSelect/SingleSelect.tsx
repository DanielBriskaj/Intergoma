import React, { useEffect } from 'react';
import { useFormContext } from 'react-hook-form';
import Select, { StylesConfig } from 'react-select';
import FormErrors from '../FormErrors';

interface SingleSelectFormItemProps {
  name: string;
  options: any;
  placeholder?: string;
  disabled?: boolean;
  onChange?: any;
  initialValue?: any;
  isClearable?: boolean;
  controlledValue?: any;
  isSearchable?: boolean;
  isLoading?: boolean;
}

export const SingleSelectFormItem: React.FunctionComponent<
  SingleSelectFormItemProps
> = ({
  name,
  options,
  placeholder,
  disabled,
  onChange,
  initialValue,
  isClearable,
  controlledValue,
  isSearchable,
  isLoading,
}) => {
  const formContext = useFormContext();

  const getValuesSelected = () => {
    return formContext
      ? formContext
      : {
          register: ({ name: any }: any) => null,
          formState: {
            isSubmitted: null,
          },
          setValue: (obj: any) => null,
          watch: (obj: any) => null,
        };
  };

  const { register, setValue, watch } = getValuesSelected();

  const {
    formState: { touchedFields, isSubmitted, errors },
  } = useFormContext();

  const errorMessage = FormErrors.errorMessage(
    name,
    errors,
    touchedFields,
    isSubmitted,
  );

  useEffect(() => {
    register(name);
  }, [register, name]);

  const controlStyles: StylesConfig = {
    control: (provided, { isDisabled }) => ({
      ...provided,
      height: '40px',
      boxShadow: 'none',
      borderColor: '#ccc',
      borderRadius: '5px',
      fontSize: '16px',
      opacity: isDisabled ? 0.8 : 1,
      backgroundColor: isDisabled ? '#f9f9fb' : '#fff',
      '&:focus-within': {
        backgroundColor: '#fff',
        border: '1px solid #3f78e0',
        boxShadow: ' 0 0 4px #3f78e0',
      },
    }),
    singleValue: provided => ({
      ...provided,
      color: '#02044a',
    }),
    option: provided => ({
      ...provided,
      width: '100%',
      marginTop: '5px',
      marginBottom: '5px',
      '&:hover': {
        backgroundColor: '#3f78e0',
        color: '#fff',
      },
    }),
  };

  return (
    <div className="select-box">
      <Select
        value={controlledValue}
        defaultValue={initialValue && { label: name, value: initialValue }}
        onChange={(e: any) => {
          onChange && onChange(e);
          setValue(name, e?.value ?? null, { shouldValidate: true });
        }}
        id={name}
        name={name}
        placeholder={placeholder}
        openMenuOnFocus={true}
        options={options}
        isDisabled={disabled}
        styles={controlStyles}
        classNamePrefix={`${errorMessage ? 'invalid-input' : 'select'}`}
        isClearable={isClearable}
        isSearchable={isSearchable}
        isLoading={isLoading}
      />
      {errorMessage && (
        <div className="error-message">{name && errorMessage}</div>
      )}
    </div>
  );
};
