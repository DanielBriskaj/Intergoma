import { yupResolver } from '@hookform/resolvers/yup';
import { Breadcrumb, Modal } from 'antd';
import React, { useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { MessageType } from '../../constants/enums/messages';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';
import notificationThrower from '../../helpers/notificationThrower';
import { useSendMessagesMutation } from '../../redux/slices/messages/messagesApi';
import TextArea from '../TextArea';
import * as yup from 'yup';
import { useSelector } from 'react-redux';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';
import { format } from 'date-fns';
import { selectMessagesTabs } from '../../redux/slices/miscellaneous/miscellaneousSlice';

interface NewMessageProps {
  createMessage: boolean;
  setCreateMessage: React.Dispatch<React.SetStateAction<boolean>>;
  resetMessage: () => void;
}
export const NewMessage: React.FC<NewMessageProps> = ({
  createMessage,
  setCreateMessage,
  resetMessage,
}) => {
  const role = getUserRole();
  const currentTab = useSelector(selectMessagesTabs);
  const user = useSelector(selectLoggedState);
  const { userId, username } = user;
  const { innerWidth: screenwidth, innerHeight: height } = window;

  const [sendMessages, { isLoading }] = useSendMessagesMutation();

  const schema = yup.object().shape({
    messageText: yup
      .string()
      .nullable()
      .max(4000, '4000 Characters Maximum')
      .required('Enter A Message To Send'),
  });

  const [initialValues] = useState(() => {
    return {
      messageText: null,
      messageType:
        role === ROLES.BACK_OFFICE
          ? MessageType.SENT_BY_BACK_OFFICE
          : MessageType.SENT_BY_AGENT,
      senderId: userId,
    };
  });

  const form = useForm({
    resolver: yupResolver(schema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const handleSubmit = async (data: any) => {
    const messageResponse: any = await sendMessages(data);
    if (messageResponse?.error?.originalStatus === 200) {
      if (currentTab === 'outbox') {
        resetMessage();
      }
      notificationThrower({
        type: 'success',
        title: 'Message Sent Successfully!',
      });
      setCreateMessage(false);
      form.reset();
    } else {
      notificationThrower({
        type: 'error',
        title: 'Failed To Send Message!',
      });
    }
  };

  return (
    <Modal
      title={
        <Breadcrumb>
          <Breadcrumb.Item>Messages</Breadcrumb.Item>
          <Breadcrumb.Item>New Message</Breadcrumb.Item>
        </Breadcrumb>
      }
      centered
      visible={createMessage}
      onCancel={() => {
        setCreateMessage(false);
        form.clearErrors();
      }}
      width={700}
      footer={null}
      className={`new-message ${
        screenwidth < 840 && `animate__animated  animate__fadeInUp`
      }`}
      transitionName={screenwidth < 840 ? '' : undefined}
      maskTransitionName={screenwidth < 840 ? '' : undefined}
    >
      <FormProvider {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)}>
          <div className="info">
            <div className="date">
              <span> Date: </span>
              {format(new Date(), 'dd-MM-yyyy')}
            </div>
            <div className="sender">
              <span> Sending As: </span>
              {username}
            </div>
          </div>
          <TextArea name="messageText" placeholder="Message" />
          <div className="form-end">
            <button
              type="button"
              className="btn-cancel"
              onClick={() => {
                setCreateMessage(false);
                form.clearErrors();
              }}
            >
              Cancel
            </button>
            <button type="submit" className="btn-primary" disabled={isLoading}>
              Send
            </button>
          </div>
        </form>
      </FormProvider>
    </Modal>
  );
};
