export { Foter as default } from './Footer';
