import React from 'react';
import { NavLink } from 'react-router-dom';
import { ReactComponent as Logo } from '../../assets/svgIcons/logo.svg';
import { ReactComponent as Facebook } from '../../assets/svgIcons/facebook.svg';
import { ReactComponent as Whatsapp } from '../../assets/svgIcons/whatsapp.svg';
import { ReactComponent as Instagram } from '../../assets/svgIcons/instagram.svg';
import { getUserRole } from '../../helpers/getUserInfo';
import { renderFooterLinks } from '../../helpers/renderRoutesOnRole';

export const Foter: React.FunctionComponent = () => {
  const role = getUserRole();

  return (
    <div className="footer-container">
      <div className="footer-wrapper">
        <div className="footer-section">
          <div className="footer-header">
            <Logo />
          </div>
          {role && (
            <div className="footer-routes">{renderFooterLinks(role)}</div>
          )}
          <div className="contacts">
            <NavLink to="/contacts" className={'footer-link'}>
              Contacts
            </NavLink>
            <div className="icons">
              <Facebook className="icon" />
              <a href="https://wa.me/355694333336">
                <Whatsapp className="icon" />
              </a>
              <Instagram className="icon" />
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          Copyright &copy; 2022 - All Rights Reserved - Intergoma
        </div>
      </div>
    </div>
  );
};
