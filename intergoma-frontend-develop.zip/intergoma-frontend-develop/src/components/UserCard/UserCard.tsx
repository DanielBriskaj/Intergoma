import React from 'react';
import { useNavigate } from 'react-router';
import { User } from '../../interfaces/users';
import { ReactComponent as UserSVG } from '../../assets/svgIcons/person-badge-fill.svg';
import { geUserStatusLabel } from '../../helpers/order/orderStatusLabel';

export const UserCard: React.FC<User> = ({ id, firstName, lastName, role }) => {
  const navigate = useNavigate();

  return (
    <div
      className="user-card-container"
      onClick={() => navigate(`/users/${id}`)}
    >
      <div className="wrapper">
        <div className="section1">
          <UserSVG className="user-svg" />
        </div>
        <div className="details">
          <div className="row">
            <div className="name">
              {firstName} {lastName}
            </div>
            <div className="role">{geUserStatusLabel(role)}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
