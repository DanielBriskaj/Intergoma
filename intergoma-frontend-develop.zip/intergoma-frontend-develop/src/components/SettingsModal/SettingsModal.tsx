import Modal from 'antd/lib/modal/Modal';
import React, { useEffect, useState } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import { settingsSchema } from '../../helpers/yupSchemas/settingsSchema';
import { FormProvider, useForm } from 'react-hook-form';
import InputFormItem from '../InputFormItem';
import {
  useCreateRateMutation,
  useLazyGetRateQuery,
  useUpdateRateMutation,
} from '../../redux/slices/exchange/exchangeApi';
import notificationThrower from '../../helpers/notificationThrower';
import { useDispatch } from 'react-redux';
import { articleApi } from '../../redux/slices/articles/articlesApi';

interface SettingsProps {
  visible: boolean;
  setVisible: React.Dispatch<React.SetStateAction<boolean>>;
}
export const SettingsModal: React.FC<SettingsProps> = ({
  visible,
  setVisible,
}) => {
  const dispatch = useDispatch();
  const [getRates, { data: currentRate }] = useLazyGetRateQuery();
  const [updateRate] = useUpdateRateMutation();
  const [createRate] = useCreateRateMutation();
  const [initialValues, setInitialValues] = useState(() => {
    return {
      rate: 1,
    };
  });
  const form = useForm({
    reValidateMode: 'onSubmit',
    resolver: yupResolver(settingsSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const handleSubmit = async (data: any) => {
    if (currentRate) {
      updateRate({ id: currentRate?.id, rate: data?.rate })
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'Exchange Rate Updated Successfully',
          });
          dispatch(articleApi.util.resetApiState());
          handleCloseModal();
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Update Exchange Rate',
          });
        });
    } else {
      createRate({ rate: data?.rate })
        .unwrap()
        .then(() => {
          notificationThrower({
            type: 'success',
            title: 'Exchange Rate Created Successfully',
          });
          dispatch(articleApi.util.resetApiState());
          handleCloseModal();
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Create Exchange Rate',
          });
        });
    }
  };

  const handleCloseModal = () => {
    setVisible(false);
  };

  useEffect(() => {
    getRates()
      .unwrap()
      .then(payload => setInitialValues(payload))
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Get Exchange Rate',
        });
      });
  }, []);

  return (
    <Modal
      title="Settings"
      centered
      visible={visible}
      footer={null}
      onCancel={handleCloseModal}
      className="settings-modal animate__animated  animate__fadeInUp"
      transitionName=""
      maskTransitionName=""
    >
      <FormProvider {...form}>
        <form
          className="settings-form"
          onSubmit={form.handleSubmit(handleSubmit)}
          autoComplete="off"
        >
          <InputFormItem
            name="rate"
            label="Exchange Rate In EUR :"
            placeholder="Exchange Rate"
            defaultValue={initialValues?.rate}
            type="number"
            step={0.01}
          />
          <div className="form-footer">
            <button className="btn-primary" type="submit">
              Save
            </button>
          </div>
        </form>
      </FormProvider>
    </Modal>
  );
};
