import React from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import { FormProvider, useForm } from 'react-hook-form';

interface FormProps {
  schema: any;
  initialValues: any;
  onHandleSuccess: any;
  onHandleError?: any;
  children: any;
  style?: any;
  className?: any;
}

export const Form: React.FunctionComponent<FormProps> = ({
  schema,
  initialValues,
  onHandleSuccess,
  onHandleError,
  children,
  style,
  className,
}) => {
  const formConfig = useForm({
    reValidateMode: 'onChange',
    resolver: yupResolver(schema),
    mode: 'onChange',
    defaultValues: initialValues,
  });
  return (
    <div style={style}>
      <FormProvider {...formConfig}>
        <form
          onSubmit={formConfig.handleSubmit(onHandleSuccess, onHandleError)}
          className={className}
        >
          {children}
        </form>
      </FormProvider>
    </div>
  );
};
