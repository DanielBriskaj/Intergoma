import { Modal } from 'antd';
import { format, parseISO } from 'date-fns';
import React, { useEffect } from 'react';
import notificationThrower from '../../helpers/notificationThrower';
import { Message, MessageQuery } from '../../interfaces/message';
import {
  useDeleteMessageMutation,
  useLazyFetchSingleMessageQuery,
  useMarkAsReadMutation,
} from '../../redux/slices/messages/messagesApi';
import Spinner from '../Spinner';
import { ReactComponent as Trash } from '../../assets/svgIcons/trash-fill.svg';
import { useDispatch, useSelector } from 'react-redux';
import {
  selectMessagesNumber,
  selectMessagesTabs,
  updateMessageNumber,
} from '../../redux/slices/miscellaneous/miscellaneousSlice';

interface OpenMessageProps {
  openMsg: number | null;
  setOpenMsg: React.Dispatch<React.SetStateAction<number | null>>;
  query: MessageQuery;
  setMessagesArray: React.Dispatch<React.SetStateAction<Message[]>>;
  messagesArray: Message[];
}
export const OpenMessage: React.FC<OpenMessageProps> = ({
  openMsg,
  setOpenMsg,
  setMessagesArray,
  messagesArray,
}) => {
  const dispatch = useDispatch();
  const { confirm } = Modal;
  const currentTab = useSelector(selectMessagesTabs);
  const messagesNumber = useSelector(selectMessagesNumber);

  const [deleteMessage] = useDeleteMessageMutation();
  const [markRead] = useMarkAsReadMutation();
  const [getSingleMessage, { data: singleMessage, isFetching: loading }] =
    useLazyFetchSingleMessageQuery();

  const handleDeleteMessage = async (id: number) => {
    const response: any = await deleteMessage({ id });
    if (response?.error?.originalStatus === 200) {
      setOpenMsg(null);
      const newState = messagesArray.filter(message => message?.id !== id);
      setMessagesArray(newState);
      notificationThrower({
        type: 'success',
        title: 'Message Deleted Successfully',
      });
    } else {
      notificationThrower({
        type: 'error',
        title: 'Failed To Delete Message',
      });
    }
  };

  useEffect(() => {
    openMsg &&
      getSingleMessage({ id: openMsg })
        .unwrap()
        .then(message => {
          if (currentTab === 'inbox' && !message?.isRead) {
            markRead(message?.id)
              .unwrap()
              .then(result => {
                const currentMessage = messagesArray.filter(
                  item => item?.id === message?.id,
                );
                const newState = messagesArray.map(item => {
                  if (item?.id === message?.id) {
                    return { ...currentMessage[0], isRead: true };
                  }
                  return item;
                });
                setMessagesArray(newState);
                dispatch(updateMessageNumber(messagesNumber - 1));
              })
              .catch(error => {
                notificationThrower({
                  type: 'error',
                  title: `Failed To Mark Message As Read`,
                });
              });
          }
        })
        .catch(error => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Read Message',
          });
        });
  }, [openMsg]);

  const showConfirm = () => {
    confirm({
      title: 'Are you sure you want to delete this message?',
      centered: true,
      maskClosable: true,
      onOk() {
        singleMessage && handleDeleteMessage(singleMessage?.id);
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  if (loading) {
    return <Spinner />;
  }
  return (
    <div className="open-message-container">
      <div className="wrapper">
        <div className="header">
          <div className="details">
            <div className="date">
              <span>Date Sent:</span>{' '}
              {singleMessage &&
                format(parseISO(singleMessage?.sentDate), 'dd-MM-yyyy')}
            </div>
            <div className="read-at">
              <span>Date Read:</span>{' '}
              {singleMessage?.readAt
                ? format(parseISO(singleMessage?.readAt), 'dd-MM-yyyy')
                : 'Unread'}
            </div>

            <div className="sender">
              <span> Sent By:</span> {singleMessage?.sender?.username}
            </div>
          </div>
          <div className="footer">
            <span style={{ cursor: 'pointer' }} onClick={showConfirm}>
              <Trash className="delete-svg" fill="#014e9e" />
              Delete
            </span>
          </div>
        </div>
        <div className="body">{singleMessage?.messageText}</div>
      </div>
    </div>
  );
};
