import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { CartItemProps } from '../../interfaces/cart';
import { removeItemFromCart } from '../../redux/slices/cart/cartSlice';
import { ReactComponent as Delete } from '../../assets/svgIcons/close.svg';
import { CartQuantity } from '../QuantityForm/CartQunatityForm';

export const CartItem: React.FC<CartItemProps> = item => {
  const dispatch = useDispatch();
  const {
    id,
    brand,
    description,
    price,
    totalPrice,
    radial,
    quantity,
    season,
    car,
    available,
  } = item;
  const [closeHover, setCloseHover] = useState<boolean>(false);

  return (
    <div className="item-container">
      <div className="item-wrapper">
        <div className="section1">
          <div className="title">
            <h4>
              {brand} {car}
            </h4>
          </div>
          <div className="description">{description}</div>
          <div className="radial">
            {radial} {season}
          </div>
        </div>
        <div className="section2">
          <div className="price-div">
            <span className="price">€ {price?.toLocaleString('en-US')}</span>
          </div>
        </div>
        <div className="section3">
          <div className="quantity">
            <CartQuantity item={item} amount={quantity} />
          </div>
        </div>
        <div className="section4">
          <div className="subtotal-div">
            <span className="subtotal">
              € {totalPrice?.toLocaleString('en-US')}
            </span>
          </div>
        </div>
        <div className="section5">
          <Delete
            className={`delete-svg ${
              closeHover ? 'close-enter' : 'close-leave'
            }`}
            onClick={() => dispatch(removeItemFromCart({ cartItemId: id }))}
            onMouseEnter={() => setCloseHover(true)}
            onMouseLeave={() => setCloseHover(false)}
          />
        </div>
      </div>
    </div>
  );
};
