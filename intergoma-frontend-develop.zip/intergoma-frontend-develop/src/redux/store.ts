import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import rootReducer from './rootReducer';
import { articleApi } from './slices/articles/articlesApi';
import { authApi } from './slices/auth/authApi';
import { clientApi } from './slices/clients/clientsApi';
import { favoritesApi } from './slices/favorites/favoritesApi';
import { messagesApi } from './slices/messages/messagesApi';
import { usersApi } from './slices/users/usersApi';
import { rtkQueryErrorLogger } from './errorLogger';
import { exchangeApi } from './slices/exchange/exchangeApi';
import { rtkqOrdersApi } from './slices/order/orderApi';

export const store = configureStore({
  reducer: rootReducer,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(
      authApi.middleware,
      clientApi.middleware,
      favoritesApi.middleware,
      articleApi.middleware,
      messagesApi.middleware,
      usersApi.middleware,
      exchangeApi.middleware,
      rtkqOrdersApi.middleware,
      rtkQueryErrorLogger,
    ),
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
