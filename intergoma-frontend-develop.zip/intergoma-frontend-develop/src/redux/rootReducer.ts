import counterReducer from './slices/counter/counterSlice';
import { combineReducers } from '@reduxjs/toolkit';
import cartSlice from './slices/cart/cartSlice';
import orderSlice from './slices/order/orderSlice';
import { authApi } from './slices/auth/authApi';
import { clientApi } from './slices/clients/clientsApi';
import { favoritesApi } from './slices/favorites/favoritesApi';
import { articleApi } from './slices/articles/articlesApi';
import { messagesApi } from './slices/messages/messagesApi';
import { usersApi } from './slices/users/usersApi';
import usersSlice from './slices/users/usersSlice';
import loggedUserSlice from './slices/auth/authSlice';
import { exchangeApi } from './slices/exchange/exchangeApi';
import miscellaneousSlice from './slices/miscellaneous/miscellaneousSlice';
import { rtkqOrdersApi } from './slices/order/orderApi';

const rootReducer = combineReducers({
  counter: counterReducer,
  cart: cartSlice,
  order: orderSlice,
  user: usersSlice,
  loggedUser: loggedUserSlice,
  miscellaneous: miscellaneousSlice,
  [authApi.reducerPath]: authApi.reducer,
  [clientApi.reducerPath]: clientApi.reducer,
  [favoritesApi.reducerPath]: favoritesApi.reducer,
  [articleApi.reducerPath]: articleApi.reducer,
  [messagesApi.reducerPath]: messagesApi.reducer,
  [usersApi.reducerPath]: usersApi.reducer,
  [exchangeApi.reducerPath]: exchangeApi.reducer,
  [rtkqOrdersApi.reducerPath]: rtkqOrdersApi.reducer,
});

export default rootReducer;
