import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import getConfig from '../../../helpers/config';

const config = getConfig();

const { test } = config;

interface Favorites {
  user: {
    id: number;
    username: string;
  };
  articleCode: string;
}

export const favoritesApi = createApi({
  reducerPath: 'favorites',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/favourites`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),

  endpoints: builder => ({
    addFavorite: builder.mutation<any, { articleCode: string }>({
      query: ({ articleCode }) => ({
        url: ``,
        method: 'POST',
        body: { articleCode },
      }),
    }),
    getFavorites: builder.query<
      Favorites[],
      { page?: number; size?: number; sort?: [] }
    >({
      query: ({ page, size, sort }) => ({
        url: ``,
        method: 'GET',
        params: { page, size, sort },
      }),
    }),
    deleteFavorite: builder.mutation<any, { articleCode: string }>({
      query: ({ articleCode }) => ({
        url: `/${articleCode}`,
        method: 'DELETE',
      }),
    }),
  }),
});

export const {
  useAddFavoriteMutation,
  useDeleteFavoriteMutation,
  useGetFavoritesQuery,
} = favoritesApi;
