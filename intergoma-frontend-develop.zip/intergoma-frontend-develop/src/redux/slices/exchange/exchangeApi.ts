import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Login, LoggedUser, User } from '../../../interfaces/users';
import { ExchangeRate } from '../../../interfaces/exchange';
import { myPrepareSearchParams } from '../../../helpers/request';

const config = getConfig();

const { test } = config;

export const exchangeApi = createApi({
  reducerPath: 'exchange',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/exchange_rates`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: builder => ({
    createRate: builder.mutation<any, ExchangeRate>({
      query: ({ rate }) => ({
        url: ``,
        method: 'POST',
        body: { rate },
      }),
    }),
    getRate: builder.query<ExchangeRate, void>({
      query: () => ({
        url: ``,
        method: 'GET',
      }),
    }),
    updateRate: builder.mutation<any, ExchangeRate>({
      query: ({ id, rate }) => ({
        url: `/${id}`,
        method: 'PUT',
        params: { rate },
      }),
    }),
  }),
});

export const {
  useCreateRateMutation,
  useGetRateQuery,
  useLazyGetRateQuery,
  useUpdateRateMutation,
} = exchangeApi;
