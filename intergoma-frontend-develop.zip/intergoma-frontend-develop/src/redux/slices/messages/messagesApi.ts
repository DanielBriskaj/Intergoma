import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import {
  SendMessage,
  MessagesReturn,
  MessageQuery,
  Message,
  GetMessageNumberQuery,
} from '../../../interfaces/message';

const config = getConfig();

const { test } = config;

export const messagesApi = createApi({
  reducerPath: 'messages',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/messages`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: builder => ({
    sendMessages: builder.mutation<string, SendMessage>({
      query: ({ messageText, messageType, senderId }) => ({
        url: ``,
        method: 'POST',
        body: { messageText, messageType, senderId },
      }),
    }),
    fetchAllMessages: builder.query<MessagesReturn, MessageQuery>({
      query: ({
        page,
        size,
        sentDate,
        idSender,
        idReceiver,
        isRead,
        sort,
      }) => ({
        url: ``,
        method: 'GET',
        params: { page, size, sentDate, idSender, idReceiver, isRead, sort },
      }),
    }),
    fetchSingleMessage: builder.query<Message, { id: number }>({
      query: ({ id }) => ({
        url: `/${id}`,
        method: 'GET',
      }),
    }),
    markAsRead: builder.mutation<string, number>({
      query: messageId => ({
        url: `/read/${messageId}`,
        method: 'PUT',
      }),
    }),
    deleteMessage: builder.mutation<string, { id: number }>({
      query: ({ id }) => ({
        url: `/${id}`,
        method: 'DELETE',
      }),
    }),
    getMessageNumber: builder.query<{ number: number }, GetMessageNumberQuery>({
      query: ({ receiverId, isRead }) => ({
        url: `/number/${receiverId}`,
        method: 'GET',
        params: { isRead },
      }),
    }),
  }),
});

export const {
  useSendMessagesMutation,
  useFetchAllMessagesQuery,
  useDeleteMessageMutation,
  useFetchSingleMessageQuery,
  useMarkAsReadMutation,
  useLazyFetchSingleMessageQuery,
  useLazyFetchAllMessagesQuery,
  useGetMessageNumberQuery,
  useLazyGetMessageNumberQuery,
} = messagesApi;
