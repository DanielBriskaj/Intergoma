import Request, { myPrepareSearchParams } from '../../../helpers/request';
import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/dist/query/react';
import {
  OrderAgentReportItemsReturn,
  OrderAgentReportQuery,
  OrderArticleReportItemsReturn,
  OrderArticleReportQuery,
  OrderProps,
  OrdersApiReturn,
  OrdersQuery,
  ProcessOrderQuery,
} from '../../../interfaces/order';

const config = getConfig();

const { test } = config;

export const orderApi = {
  downloadPDF: (id: number) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/orders/proforma/${id}`,
      responseType: 'blob',
    }),
  orderArticleReport: (query: OrderArticleReportQuery) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/orders/order_article_report`,
      query: query || {},
      responseType: 'blob',
    }),

  orderAgentReport: (query: OrderArticleReportQuery) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/orders/total_order_report`,
      query: query || {},
      responseType: 'blob',
    }),
};

export const rtkqOrdersApi = createApi({
  reducerPath: 'rtkqOrders',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/orders`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),

  endpoints: builder => ({
    fetchAllOrders: builder.query<OrdersApiReturn, OrdersQuery>({
      query: ({ page, size, sort, clientCode, userId }) => ({
        url: `${myPrepareSearchParams({
          page,
          size,
          sort,
          clientCode,
          userId,
        })}`,
        method: 'GET',
      }),
    }),
    fetchSingleOrder: builder.query<OrderProps, number>({
      query: id => ({
        url: `/${id}`,
        method: 'GET',
      }),
    }),
    deleteOrder: builder.mutation<void, number>({
      query: id => ({
        url: `/${id}`,
        method: 'DELETE',
      }),
    }),

    processOrder: builder.mutation<OrderProps, ProcessOrderQuery>({
      query: ({ id, data }) => ({
        url: `/process/${id}`,
        method: 'PUT',
        body: data,
      }),
    }),
    orderArticleReportItems: builder.query<
      OrderArticleReportItemsReturn,
      OrderArticleReportQuery
    >({
      query: query => ({
        url: `/order_article_report_items${myPrepareSearchParams(query)}`,
        method: 'GET',
      }),
    }),

    createOrder: builder.mutation<OrderProps, any>({
      query: data => ({
        url: ``,
        method: 'POST',
        body: data,
      }),
    }),

    updateOrder: builder.mutation<OrderProps, any>({
      query: ({ id, data }) => ({
        url: `/${id}`,
        method: 'PUT',
        body: data,
      }),
    }),

    orderAgentReportItems: builder.query<
      Array<OrderAgentReportItemsReturn>,
      OrderAgentReportQuery
    >({
      query: query => ({
        url: `/total_order_report_items${myPrepareSearchParams(query)}`,
        method: 'GET',
      }),
    }),
  }),
});

export const {
  useFetchAllOrdersQuery,
  useLazyFetchAllOrdersQuery,
  useFetchSingleOrderQuery,
  useLazyFetchSingleOrderQuery,
  useDeleteOrderMutation,
  useProcessOrderMutation,
  useLazyOrderArticleReportItemsQuery,
  useOrderArticleReportItemsQuery,
  useCreateOrderMutation,
  useLazyOrderAgentReportItemsQuery,
  useOrderAgentReportItemsQuery,
  useUpdateOrderMutation,
} = rtkqOrdersApi;
