import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import notificationThrower from '../../../helpers/notificationThrower';
import {
  OrderAgentReportQuery,
  OrderArticleReportQuery,
} from '../../../interfaces/order';
import { RootState } from '../../store';
import { orderApi } from './orderApi';

interface OrderState {
  loading: boolean;
  error: string | null;
  openForm: number | null;
}

const initialState: OrderState = {
  loading: false,
  error: null,
  openForm: null,
};

export const downloadPDF = createAsyncThunk(
  'order/downloadPDF',
  async (id: number, { rejectWithValue }) => {
    try {
      const response = await orderApi.downloadPDF(id);
      const url = window.URL.createObjectURL(new Blob([response.payload.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Order ${id}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);

export const downloadOrderArticleReport = createAsyncThunk(
  'order/orderArticleReport',
  async (query: OrderArticleReportQuery, { rejectWithValue }) => {
    try {
      const response = await orderApi.orderArticleReport(query);
      const url = window.URL.createObjectURL(new Blob([response.payload.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Order_Article_Report.xlsx`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);

export const downloadOrderAgentReport = createAsyncThunk(
  'order/orderAgentReport',
  async (query: OrderAgentReportQuery, { rejectWithValue }) => {
    try {
      const response = await orderApi.orderAgentReport(query);
      const url = window.URL.createObjectURL(new Blob([response.payload.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute(
        'download',
        `${
          query?.detailed
            ? 'Detailed_Order_Agent_Report.xlsx'
            : 'Order_Agent_Report.xlsx'
        }`,
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error: any) {
      return rejectWithValue(error.response.data);
    }
  },
);

export const orderSlice = createSlice({
  name: 'order',
  initialState,
  reducers: {
    resetOrderState: () => initialState,
    openOrderForm: (state, action) => {
      return {
        ...state,
        openForm: action.payload,
      };
    },
  },
  extraReducers: builder => {
    builder
      .addCase(downloadPDF.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(downloadPDF.fulfilled, state => {
        return {
          ...state,
          loading: false,
        };
      })
      .addCase(downloadPDF.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Download Order!',
        });
        return {
          ...state,
          loading: false,
          error: action.error.message as string,
        };
      })
      .addCase(downloadOrderArticleReport.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(downloadOrderArticleReport.fulfilled, state => {
        return {
          ...state,
          loading: false,
        };
      })
      .addCase(downloadOrderArticleReport.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Download Report!',
        });
        return {
          ...state,
          loading: false,
          error: action.error.message as string,
        };
      })
      .addCase(downloadOrderAgentReport.pending, state => {
        return {
          ...state,
          loading: true,
        };
      })
      .addCase(downloadOrderAgentReport.fulfilled, state => {
        return {
          ...state,
          loading: false,
        };
      })
      .addCase(downloadOrderAgentReport.rejected, (state, action) => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Download Report!',
        });
        return {
          ...state,
          loading: false,
          error: action.error.message as string,
        };
      });
  },
});
export const { resetOrderState, openOrderForm } = orderSlice.actions;

export const selectOrder = (state: RootState) => state.order;
export const selectLoadingOrder = (state: RootState) => state.order.loading;
export const selectErrorOrder = (state: RootState) => state.order.error;
export default orderSlice.reducer;
