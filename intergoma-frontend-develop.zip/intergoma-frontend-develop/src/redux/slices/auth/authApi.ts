import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Login, LoggedUser, User } from '../../../interfaces/users';

const config = getConfig();

const { test } = config;

export const authApi = createApi({
  reducerPath: 'auth',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/auth`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: builder => ({
    login: builder.mutation<string, Login>({
      query: ({ userData }) => ({
        url: `/login`,
        method: 'POST',
        body: { ...userData },
      }),
    }),
    loggedUser: builder.query<LoggedUser, void>({
      query: () => ({
        url: `/logged_user`,
        method: 'GET',
      }),
    }),
    signUp: builder.mutation<string, User>({
      query: data => ({
        url: `/signup`,
        method: 'POST',
        body: data,
      }),
    }),
  }),
});

export const {
  useLoginMutation,
  useLoggedUserQuery,
  useSignUpMutation,
  useLazyLoggedUserQuery,
} = authApi;
