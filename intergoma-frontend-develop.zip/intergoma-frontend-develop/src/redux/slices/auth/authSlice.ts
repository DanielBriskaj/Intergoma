import { createSlice } from '@reduxjs/toolkit';
import { Warehouse } from '../../../interfaces/users';
import { RootState } from '../../store';

interface LoggedUser {
  username: string;
  userId: number;
  warehouse?: Warehouse;
  clientCode?: string;
}

const initialState: LoggedUser = {
  username: '',
  userId: 0,
};

export const loggedUserSlice = createSlice({
  name: 'loggedUser',
  initialState: initialState,
  reducers: {
    resetLoggedState: () => initialState,
    setLoggedUser: (state, action) => {
      return {
        ...state,
        username: action.payload.username,
        userId: action.payload.id,
        warehouse: action?.payload?.warehouse,
        clientCode: action?.payload?.clientCode,
      };
    },
  },
});

export const selectLoggedState = (state: RootState) => state.loggedUser;
export const { setLoggedUser, resetLoggedState } = loggedUserSlice.actions;
export default loggedUserSlice.reducer;
