import { createSlice } from '@reduxjs/toolkit';
import { RootState } from '../../store';

interface MiscellaneousState {
  searchItems: {
    tireSize?: string;
    brand?: string;
    season?: string;
    carType?: string;
    hasStock?: boolean;
  };
  messagesTabs: 'inbox' | 'outbox';
  messagesNumber: number;
}

const initialState: MiscellaneousState = {
  searchItems: {},
  messagesTabs: 'inbox',
  messagesNumber: 0,
};
export const miscellaneousSlice = createSlice({
  name: 'miscellaneous',
  initialState: initialState,
  reducers: {
    resetMiscellaneousState: () => initialState,
    addSearchArticles: (state, action) => {
      return {
        ...state,
        searchItems: action.payload,
      };
    },
    changeMessageTabs: (state, action) => {
      return {
        ...state,
        messagesTabs: action.payload,
      };
    },
    updateMessageNumber: (state, action) => {
      return {
        ...state,
        messagesNumber: action.payload,
      };
    },
  },
});

export const selectSearchItems = (state: RootState) =>
  state.miscellaneous.searchItems;
export const selectMessagesTabs = (state: RootState) =>
  state.miscellaneous.messagesTabs;
export const selectMessagesNumber = (state: RootState) =>
  state.miscellaneous.messagesNumber;

export const {
  resetMiscellaneousState,
  addSearchArticles,
  changeMessageTabs,
  updateMessageNumber,
} = miscellaneousSlice.actions;
export default miscellaneousSlice.reducer;
