import { createSlice } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { CartItemProps } from '../../../interfaces/cart';
import { getCart } from '../../../helpers/getCart';
import notificationThrower from '../../../helpers/notificationThrower';

interface CartState {
  cartItems: Array<CartItemProps>;
}
const cartOnStorage: CartItemProps[] = getCart();

const initialState: CartState = {
  cartItems: cartOnStorage,
};
export const cartSlice = createSlice({
  name: 'cart',
  initialState: initialState,
  reducers: {
    resetCartState: () => initialState,
    addItemToCart: (state, action) => {
      const id = action.payload.item.id;
      const itemExists = state.cartItems.find(item => item.id === id);

      const price = action.payload.item.price;
      if (itemExists) {
        notificationThrower({
          type: 'info',
          title: 'Item is already in cart!',
          toastId: id,
        });
      } else {
        state.cartItems.push({
          id: id,
          brand: action.payload.item.brand,
          description: action.payload.item.description,
          radial: action.payload.item.radial,
          quantity: action.payload.quantity,
          price: price,
          available: action.payload.item.available,
          totalPrice: Number((price * action.payload.quantity).toFixed(2)),
          season: action.payload.item.season,
          car: action.payload.item.car,
          size: action.payload.item.size,
          favorite: action.payload.item.favorite,
          year: action.payload?.item?.year,
          sap: action.payload?.item?.sap,
        });
        notificationThrower({
          type: 'success',
          title: 'Item added to cart successfully!',
        });
        localStorage.setItem('cart', JSON.stringify(state.cartItems));
      }
    },
    removeItemFromCart: (state, action) => {
      state.cartItems = state.cartItems.filter(
        cartItem => cartItem.id !== action.payload.cartItemId,
      );
      localStorage.setItem('cart', JSON.stringify(state.cartItems));
    },
    changeQuantityOnCart: (state, action) => {
      const id = action.payload.item.id;
      state.cartItems = state.cartItems.map(item => {
        if (item.id === id) {
          return {
            ...item,
            quantity: action.payload.quantity,
            totalPrice: Number(
              (action.payload.item.price * action.payload.quantity).toFixed(1),
            ),
          };
        }
        return item;
      });
      localStorage.setItem('cart', JSON.stringify(state.cartItems));
    },
  },
});

export const selectTotalCartPrice = (state: RootState) => {
  return state.cart.cartItems.reduce((total, cartItem) => {
    return Number((cartItem.totalPrice + total).toFixed(1));
  }, 0);
};
export const selectCartItems = (state: RootState) => state.cart.cartItems;
export const {
  addItemToCart,
  removeItemFromCart,
  resetCartState,
  changeQuantityOnCart,
} = cartSlice.actions;
export default cartSlice.reducer;
