import Request from '../../../helpers/request';
import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Tire } from '../../../interfaces/tires';

const config = getConfig();

const { test } = config;

export const articlesApi = {
  fetchArticles: () =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/articles`,
    }),
  fetchSingleArticle: (code: string) =>
    Request.doRequest({
      method: 'get',
      url: `${test.baseUrl}/articles/${code}`,
    }),
};

export const articleApi = createApi({
  reducerPath: 'article',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/articles`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: builder => ({
    fetchAllArticles: builder.query<Tire[], string | void>({
      query: () => ({
        url: ``,
        method: 'GET',
      }),
    }),
    fetchSingleArticle: builder.query<Tire, { code: string }>({
      query: ({ code }) => ({
        url: `/${code}`,
        method: 'GET',
      }),
    }),

    fetchArticleWarehouseInfo: builder.query<Tire[], { code: string }>({
      query: ({ code }) => ({
        url: `/quantity`,
        method: 'GET',
        params: { code },
      }),
    }),
  }),
});

export const {
  useFetchAllArticlesQuery,
  useLazyFetchAllArticlesQuery,
  useFetchSingleArticleQuery,
  useLazyFetchSingleArticleQuery,
  useFetchArticleWarehouseInfoQuery,
  useLazyFetchArticleWarehouseInfoQuery,
} = articleApi;
