import { createSlice } from '@reduxjs/toolkit';
import { RootState } from '../../store';

interface UserState {
  modalOpen: boolean;
  userId: number | null;
}

const initialState: UserState = {
  modalOpen: false,
  userId: null,
};

export const usersSlice = createSlice({
  name: 'user',
  initialState: initialState,
  reducers: {
    resetUserState: () => initialState,
    openModal: (state, action) => {
      return {
        ...state,
        modalOpen: action.payload.isOpen,
        userId: action.payload.userId,
      };
    },
  },
});

export const selectUserState = (state: RootState) => state.user;
export const { openModal, resetUserState } = usersSlice.actions;
export default usersSlice.reducer;
