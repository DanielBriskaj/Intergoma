import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { User, UsersQuery, UsersReturn } from '../../../interfaces/users';
import { myPrepareSearchParams } from '../../../helpers/request';

const config = getConfig();

const { test } = config;

export const usersApi = createApi({
  reducerPath: 'users',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/users`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: builder => ({
    fetchAllUsers: builder.query<UsersReturn, UsersQuery>({
      query: ({ page, size, username, sort }) => ({
        url: `${myPrepareSearchParams({ page, size, username, sort })}`,
        method: 'GET',
      }),
    }),
    fetchSingleUser: builder.query<any, { id: number }>({
      query: ({ id }) => ({
        url: `/${id}`,
        method: 'GET',
      }),
    }),
    updateUser: builder.mutation<string, User>({
      query: ({
        firstName,
        lastName,
        email,
        role,
        id,
        warehouse,
        clientCode,
      }) => ({
        url: `/${id}`,
        method: 'PUT',
        body: { firstName, lastName, email, role, warehouse, clientCode },
      }),
    }),
    deleteUser: builder.mutation<string, { id: number }>({
      query: ({ id }) => ({
        url: `/${id}`,
        method: 'DELETE',
      }),
    }),
  }),
});

export const {
  useDeleteUserMutation,
  useFetchAllUsersQuery,
  useFetchSingleUserQuery,
  useUpdateUserMutation,
  useLazyFetchAllUsersQuery,
  useLazyFetchSingleUserQuery,
} = usersApi;
