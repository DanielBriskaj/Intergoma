import getConfig from '../../../helpers/config';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { ClientsProps, LightClientProps } from '../../../interfaces/clients';

const config = getConfig();

const { test } = config;

export const clientApi = createApi({
  reducerPath: 'clients',
  baseQuery: fetchBaseQuery({
    baseUrl: test.baseUrl + `/clients`,
    prepareHeaders(headers) {
      const token = localStorage.getItem('idToken');
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  endpoints: builder => ({
    fetchAllClients: builder.query<ClientsProps[], number | void>({
      query: () => ({
        url: ``,
        method: 'GET',
      }),
    }),
    fetchSingleClient: builder.query<ClientsProps, { code: string }>({
      query: ({ code }) => ({
        url: `/${code}`,
        method: 'GET',
      }),
    }),
    fetchLightSingleClient: builder.query<LightClientProps, { code: string }>({
      query: ({ code }) => ({
        url: `/light/${code}`,
        method: 'GET',
      }),
    }),
  }),
});

export const {
  useFetchAllClientsQuery,
  useFetchSingleClientQuery,
  useLazyFetchAllClientsQuery,
  useLazyFetchSingleClientQuery,
  useFetchLightSingleClientQuery,
  useLazyFetchLightSingleClientQuery,
} = clientApi;
