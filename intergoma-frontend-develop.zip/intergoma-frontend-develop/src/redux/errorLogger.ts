import { isRejectedWithValue } from '@reduxjs/toolkit';
import type { MiddlewareAPI, Middleware } from '@reduxjs/toolkit';
import notificationThrower from '../helpers/notificationThrower';

/**
 * Log a warning and show a toast!
 */
export const rtkQueryErrorLogger: Middleware =
  (api: MiddlewareAPI) => next => action => {
    if (isRejectedWithValue(action)) {
      if (
        action?.payload?.data?.message === 'Token has expired!' ||
        action?.payload?.message === 'Token has expired!'
      ) {
        notificationThrower({
          type: 'error',
          title: 'Session has expired! Please log in again!',
        });
      }
    }

    return next(action);
  };
