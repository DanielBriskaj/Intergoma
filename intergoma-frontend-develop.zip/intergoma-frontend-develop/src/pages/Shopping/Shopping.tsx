import { Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { ColumnTypes, ShoppingColumns } from './tableData';
import {
  EditableCell,
  EditableRow,
} from '../../components/EditableCell/EditableCell';
import { ShoppingData } from '../../interfaces/shopping';
import { articleDataTransformer } from '../../helpers/dataTransformers/articleDataTransformer';
import { useFetchAllArticlesQuery } from '../../redux/slices/articles/articlesApi';
import notificationThrower from '../../helpers/notificationThrower';

export const Shopping: React.FunctionComponent = () => {
  const [tableData, setTableData] = useState([] as ShoppingData[]);

  const { data, isFetching, error } = useFetchAllArticlesQuery();

  useEffect(() => {
    if (error) {
      notificationThrower({
        type: 'error',
        title: 'Something Went Wrong',
      });
    }
  }, [error]);

  useEffect(() => {
    setTableData([]);
    if (data) {
      data.map((article, index) => {
        if (article.KLASIF) {
          const objectValue = articleDataTransformer(article, index);
          setTableData(state => [objectValue, ...state]);
        }
      });
    }
  }, [data]);

  const handleSave = (row: ShoppingData) => {
    const newData = [...tableData];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, { ...item, ...row });
    setTableData(newData);
  };

  const components = {
    body: {
      row: EditableRow,
      cell: EditableCell,
    },
  };

  const columns = ShoppingColumns();

  const tableColumns = columns.map(col => {
    if (!col.editable) {
      return col;
    }
    return {
      ...col,
      onCell: (record: ShoppingData) => ({
        record,
        editable: col.editable,
        dataIndex: col.dataIndex,
        title: col.title,
        handleSave: handleSave,
      }),
    };
  });

  return (
    <div className="shopping-container">
      <Table
        components={components}
        dataSource={tableData}
        columns={tableColumns as ColumnTypes}
        loading={isFetching}
      />
    </div>
  );
};
