export { Shopping as default } from './Shopping';
