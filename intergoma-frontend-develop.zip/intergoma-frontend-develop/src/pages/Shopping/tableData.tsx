import { Spin, Tooltip } from 'antd';
import Quantity from '../../components/QuantityForm';
import { getColumnSearchProps } from '../../helpers/tableSearch';
import React from 'react';
import { getUserRole } from '../../helpers/getUserInfo';
import { ReactComponent as Star } from '../../assets/svgIcons/star.svg';
import { ReactComponent as StarFill } from '../../assets/svgIcons/star-fill.svg';
import { ReactComponent as Info } from '../../assets/svgIcons/info-circle-fill.svg';

import {
  useAddFavoriteMutation,
  useDeleteFavoriteMutation,
} from '../../redux/slices/favorites/favoritesApi';
import notificationThrower from '../../helpers/notificationThrower';
import {
  useLazyFetchAllArticlesQuery,
  useLazyFetchArticleWarehouseInfoQuery,
} from '../../redux/slices/articles/articlesApi';
import { ROLES } from '../../constants/enums/roles';
import Table from 'antd/lib/table';

const role = getUserRole();
type EditableTableProps = Parameters<typeof Table>[0];
export type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>;

export function ShoppingColumns() {
  const [addFavorite] = useAddFavoriteMutation();
  const [deleteFavorite] = useDeleteFavoriteMutation();
  const [getAll] = useLazyFetchAllArticlesQuery();
  const [
    getWarehouseInfo,
    { isFetching: warehouseLoading, data: warehouseData },
  ] = useLazyFetchArticleWarehouseInfoQuery();

  const getFavoriteStarIcon = (type: 'fill' | 'no-fill') => {
    if (type === 'fill') {
      return StarFill;
    }

    return Star;
  };

  const getFavoriteStarComponent = (
    action: 'add' | 'remove',
    recordId: string,
  ) => {
    const Star = getFavoriteStarIcon(action === 'add' ? 'no-fill' : 'fill');

    return (
      <Tooltip
        placement="topLeft"
        title={action === 'add' ? `Add Favorite` : 'Remove Favorite'}
      >
        <Star
          fill="#014e9e"
          style={{ cursor: 'pointer' }}
          onClick={() => {
            handleFavorite(action, recordId);
          }}
        />
      </Tooltip>
    );
  };

  const handleFavorite = async (type: string, articleCode: string) => {
    switch (type) {
      case 'add':
        addFavorite({ articleCode })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Item Added To Favorites Successfully',
            });
            getAll();
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Add Item To Favorites',
            });
          });
        break;
      case 'remove':
        deleteFavorite({ articleCode })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Item Removed From Favorites Successfully',
            });
            getAll();
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Remove Item From Favorites',
            });
          });
        break;
    }
  };

  const handleGetWarehouse = (record: any) => {
    getWarehouseInfo({ code: record?.kod }, true)
      .unwrap()
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Get Warehouse Info',
        });
      });
  };

  const shoppingColumns: (ColumnTypes[number] & {
    editable?: boolean;
    dataIndex?: string;
  })[] = [
    {
      title: 'CODE',
      dataIndex: 'kod',
      key: 'kod',
      width: '10%',
      ...getColumnSearchProps('kod', 'Code'),
      ellipsis: {
        showTitle: false,
      },
      render: (kod: string) => (
        <Tooltip placement="topLeft" title={kod}>
          {kod}
        </Tooltip>
      ),
    },
    {
      title: 'SAP',
      dataIndex: 'sap',
      key: 'sap',
      width: '10%',
      ...getColumnSearchProps('sap', 'SAP Code'),
      ellipsis: {
        showTitle: false,
      },
      render: (sap: string) => (
        <Tooltip placement="topLeft" title={sap}>
          {sap}
        </Tooltip>
      ),
    },
    {
      title: 'BRAND',
      dataIndex: 'brand',
      key: 'brand',
      width: '10%',
      ...getColumnSearchProps('brand', 'Brand'),
      ellipsis: {
        showTitle: false,
      },
      render: (brand: string) => (
        <Tooltip placement="topLeft" title={brand}>
          {brand}
        </Tooltip>
      ),
    },
    {
      title: 'RADIAL',
      dataIndex: 'radial',
      key: 'radial',
      width: '8%',
      ...getColumnSearchProps('radial', 'Radial'),
      ellipsis: {
        showTitle: false,
      },
      render: (radial: string) => (
        <Tooltip placement="topLeft" title={radial}>
          {radial}
        </Tooltip>
      ),
    },
    {
      title: 'DESCRIPTION',
      dataIndex: 'description',
      key: 'description',
      width: '20%',
      ...getColumnSearchProps('description', 'Description'),
      ellipsis: {
        showTitle: false,
      },
      render: (description: string) => (
        <Tooltip placement="topLeft" title={description}>
          {description}
        </Tooltip>
      ),
    },

    {
      title: 'SIZE',
      dataIndex: 'size',
      key: 'size',
      width: '8%',
      ...getColumnSearchProps('size', 'Size'),
      ellipsis: {
        showTitle: false,
      },
      render: (size: string) => (
        <Tooltip placement="topLeft" title={size}>
          {size}
        </Tooltip>
      ),
    },

    {
      title: 'SEASON',
      dataIndex: 'season',
      key: 'season',
      width: '10%',
      ...getColumnSearchProps('season', 'Season'),
      ellipsis: {
        showTitle: false,
      },
      render: (season: string) => (
        <Tooltip placement="topLeft" title={season}>
          {season}
        </Tooltip>
      ),
    },
    {
      title: 'CAR TYPE',
      dataIndex: 'car',
      key: 'car',
      width: '8%',
      ...getColumnSearchProps('car', 'Car Type'),
      ellipsis: {
        showTitle: false,
      },
      render: (car: string) => (
        <Tooltip placement="topLeft" title={car}>
          {car}
        </Tooltip>
      ),
    },
    {
      title: ' YEAR',
      dataIndex: 'year',
      key: 'year',
      width: '8%',
      ...getColumnSearchProps('year', 'Year'),
      ellipsis: {
        showTitle: false,
      },
      render: (year: string) => (
        <Tooltip placement="topLeft" title={year}>
          {year}
        </Tooltip>
      ),
    },
    {
      title: 'PRICE',
      dataIndex: 'price',
      key: 'price',
      align: 'right' as const,
      width: '8%',
      sorter: (a: any, b: any) => a.price - b.price,
      ellipsis: {
        showTitle: false,
      },
      editable: role === 'Agent',
      render: (numbers: number) => (
        <Tooltip placement="topLeft" title={numbers}>
          € {numbers?.toLocaleString('en-US')}
        </Tooltip>
      ),
    },
    {
      title: 'STOCK',
      key: 'stock',
      align: 'right' as const,
      defaultSortOrder: 'descend',
      width: '8%',
      sorter: (a: any, b: any) => a.available - b.available,
      ellipsis: {
        showTitle: false,
      },
      render: (record: any) =>
        role === ROLES.RESELLER ? (
          record?.available >= 2 ? (
            '2+'
          ) : (
            record?.available
          )
        ) : (
          <div className="stock">
            {record?.available?.toLocaleString('en-US')}
            <Tooltip
              trigger="click"
              placement="topLeft"
              title={
                warehouseLoading ? (
                  <Spin />
                ) : (
                  warehouseData?.map((article, index) => {
                    return (
                      <div className="warehouseInfo" key={index}>
                        <div className="name">{article?.KMAG} : </div>
                        <div className="amount">{article?.GJENDJE}</div>
                      </div>
                    );
                  })
                )
              }
            >
              <Info
                className="info-svg"
                onClick={() => handleGetWarehouse(record)}
              />
            </Tooltip>
          </div>
        ),
    },
    role !== ROLES.ADMIN
      ? {
          title: 'ACTIONS',
          key: 'actions',
          align: 'center' as const,
          width: '180px',
          render: (record: any) => <Quantity item={record} />,
        }
      : {},
    {
      title: '',
      key: 'favorites',
      width: '5%',
      render: (record: any) => {
        return getFavoriteStarComponent(
          record?.favorite ? 'remove' : 'add',
          record.id,
        );
      },
    },
  ];
  return shoppingColumns;
}
