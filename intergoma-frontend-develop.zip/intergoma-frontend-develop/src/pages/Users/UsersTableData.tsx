import { Modal, Tooltip } from 'antd';
import React from 'react';
import { getColumnSearchProps } from '../../helpers/tableSearch';
import { ReactComponent as Edit } from '../../assets/svgIcons/pencil-square.svg';
import { ReactComponent as Delete } from '../../assets/svgIcons/trash-fill.svg';
import {
  useDeleteUserMutation,
  useLazyFetchAllUsersQuery,
} from '../../redux/slices/users/usersApi';
import { useDispatch, useSelector } from 'react-redux';
import { openModal } from '../../redux/slices/users/usersSlice';
import notificationThrower from '../../helpers/notificationThrower';
import { geUserStatusLabel } from '../../helpers/order/orderStatusLabel';
import { UserRoles } from '../../interfaces/users';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';

export function UsersTableData({ query }: any) {
  const dispatch = useDispatch();
  const loggedUser = useSelector(selectLoggedState);
  const { userId } = loggedUser;
  const { confirm } = Modal;
  const [deleteUser] = useDeleteUserMutation();
  const [getAllUsers] = useLazyFetchAllUsersQuery();

  const handleDeleteUser = async (id: number) => {
    deleteUser({ id })
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: 'User Deleted Successfully',
        });
        getAllUsers(query);
      })
      .catch(error => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Delete User',
        });
      });
  };

  const showConfirm = (id: number, username: string) => {
    confirm({
      title: `Are you sure you want to delete ${username}?`,
      centered: true,
      maskClosable: true,
      onOk() {
        handleDeleteUser(id);
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const handleOpenModal = (userId: number) => {
    dispatch(openModal({ isOpen: true, userId }));
  };

  const userColumns = [
    {
      title: 'FIRSTNAME',
      dataIndex: 'firstName',
      key: 'firstName',
      ellipsis: {
        showTitle: false,
      },
      render: (firstName: string) => (
        <Tooltip placement="topLeft" title={firstName}>
          {firstName}
        </Tooltip>
      ),
    },
    {
      title: 'LASTNAME',
      dataIndex: 'lastName',
      key: 'lastName',
      ellipsis: {
        showTitle: false,
      },
      render: (lastName: string) => (
        <Tooltip placement="topLeft" title={lastName}>
          {lastName}
        </Tooltip>
      ),
    },
    {
      title: 'USERNAME',
      dataIndex: 'username',
      key: 'username',
      ...getColumnSearchProps('username', 'Username'),
      ellipsis: {
        showTitle: false,
      },
      render: (username: string) => (
        <Tooltip placement="topLeft" title={username}>
          {username}
        </Tooltip>
      ),
    },
    {
      title: 'EMAIL',
      dataIndex: 'email',
      key: 'email',
      ellipsis: {
        showTitle: false,
      },
      render: (email: string) => (
        <Tooltip placement="topLeft" title={email}>
          {email}
        </Tooltip>
      ),
    },
    {
      title: 'ROLE',
      dataIndex: 'role',
      key: 'role',
      ellipsis: {
        showTitle: false,
      },
      render: (role: UserRoles) => (
        <Tooltip placement="topLeft" title={role}>
          {geUserStatusLabel(role)}
        </Tooltip>
      ),
    },
    {
      title: 'ACTIONS',
      key: 'actions',
      width: '120px',
      render: (record: any) => (
        <div className="actions">
          <Edit
            fill="#014e9e"
            className="edit-svg"
            onClick={() => handleOpenModal(record?.id)}
          />
          <button
            className="delete-btn"
            onClick={() => showConfirm(record?.id, record?.username)}
            disabled={record?.id === userId}
          >
            <Delete fill="#014e9e" className="delete-svg" />
          </button>
        </div>
      ),
    },
  ];
  return userColumns;
}
