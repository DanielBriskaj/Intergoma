import { Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import UserModal from '../../components/UserModal';
import notificationThrower from '../../helpers/notificationThrower';
import { User } from '../../interfaces/users';
import { useFetchAllUsersQuery } from '../../redux/slices/users/usersApi';
import {
  openModal,
  selectUserState,
} from '../../redux/slices/users/usersSlice';
import { UsersTableData } from './UsersTableData';
import { ReactComponent as Plus } from '../../assets/svgIcons/plus.svg';

export const Users: React.FC = () => {
  const dispatch = useDispatch();
  const [tableData, setTableData] = useState<Array<User>>([]);
  const [page, setPage] = useState<number>(0);
  const [size, setSize] = useState<number>(10);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [searchUser, setSearchUser] = useState<string[] | null>(null);
  const userState = useSelector(selectUserState);
  const { modalOpen } = userState;

  const query = {
    page,
    size,
    username: searchUser ? searchUser[0] : null,
  };
  const { data, isFetching, isSuccess, error } = useFetchAllUsersQuery(query);

  const handleOpenModal = () => {
    dispatch(openModal({ isOpen: true, userId: null }));
  };

  useEffect(() => {
    if (isSuccess) {
      setTableData(
        data?.users?.map(user => ({
          key: user?.id,
          ...user,
        })),
      );
      setTotalItems(data?.totalItems ?? 0);
    }
  }, [data]);

  useEffect(() => {
    if (error) {
      notificationThrower({
        type: 'error',
        title: 'Something Went Wrong',
      });
    }
  }, [error]);

  const handlePageChange = (page: any, pageSize: any) => {
    setPage(page - 1);
    setSize(pageSize);
  };

  const handleShowSizeChange = (size: number) => {
    setSize(size);
  };

  const handleTableChange = (newPagination: any, filters: any, sorter: any) => {
    setSearchUser(filters?.username);
  };

  const userColumns = UsersTableData({ query });
  return (
    <div className="users-container">
      {modalOpen && <UserModal query={query} />}
      <div className="header">
        <button className="btn-primary" onClick={handleOpenModal}>
          Add User
          <Plus className="plus-svg" />
        </button>
      </div>
      <Table
        dataSource={tableData}
        columns={userColumns}
        loading={isFetching}
        pagination={{
          total: totalItems,
          onChange: handlePageChange,
          onShowSizeChange: handleShowSizeChange,
          showSizeChanger: true,
        }}
        onChange={handleTableChange}
      />
    </div>
  );
};
