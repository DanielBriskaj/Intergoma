import React from 'react';
import { useNavigate } from 'react-router';
import Progress from '../assets/images/work-in-progress.png';

const UnderDevelopment: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="under-dev-container">
      <img src={Progress} alt="Page Under Construction" />
      <h1>Page Under Construction</h1>
      <button className="btn-primary" onClick={() => navigate(-1)}>
        Back
      </button>
    </div>
  );
};
export default UnderDevelopment;
