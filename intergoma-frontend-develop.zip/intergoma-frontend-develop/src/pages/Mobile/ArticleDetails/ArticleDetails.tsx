import React, { useEffect, useState } from 'react';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { useNavigate, useParams } from 'react-router';
import { ROLES } from '../../../constants/enums/roles';
import { getUserRole } from '../../../helpers/getUserInfo';
import { useDispatch, useSelector } from 'react-redux';
import {
  addItemToCart,
  selectCartItems,
} from '../../../redux/slices/cart/cartSlice';
import Spinner from '../../../components/Spinner';
import notificationThrower from '../../../helpers/notificationThrower';
import {
  useLazyFetchArticleWarehouseInfoQuery,
  useLazyFetchSingleArticleQuery,
} from '../../../redux/slices/articles/articlesApi';
import { articleDataTransformer } from '../../../helpers/dataTransformers/articleDataTransformer';
import { TireCardsProps } from '../../../interfaces/shopping';
import { ReactComponent as Star } from '../../../assets/svgIcons/star.svg';
import { ReactComponent as StarFill } from '../../../assets/svgIcons/star-fill.svg';
import { FormProvider, useForm } from 'react-hook-form';
import InputFormItem from '../../../components/InputFormItem';
import {
  useAddFavoriteMutation,
  useDeleteFavoriteMutation,
} from '../../../redux/slices/favorites/favoritesApi';

export const ArticleDetails: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const role = getUserRole();
  const { id } = useParams();
  const cartItems = useSelector(selectCartItems);
  const [tireInfo, setTireInfo] = useState<TireCardsProps>();
  const [favorite2, setFavorite2] = useState<boolean>();
  const [warehouseInfo, setWarehouseInfo] =
    useState<Array<{ warehouse: string; qty: number }>>();
  const [quantity2, setQuantity2] = useState<number>(
    tireInfo?.available === 0 ? 0 : 1,
  );

  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  const [getSingleArticle, { isFetching }] = useLazyFetchSingleArticleQuery();
  const [getWarehouseInfo] = useLazyFetchArticleWarehouseInfoQuery();
  const [addFavorite] = useAddFavoriteMutation();
  const [deleteFavorite] = useDeleteFavoriteMutation();

  const handleAddToCart = () => {
    if (tireInfo) {
      if (
        tireInfo?.available > 0 &&
        quantity2 > 0 &&
        quantity2 <= tireInfo?.available
      ) {
        dispatch(addItemToCart({ item: tireInfo, quantity: quantity2 }));
      } else if (tireInfo?.available > 0 && quantity2 < 1) {
        notificationThrower({
          type: 'warning',
          title: 'Amount must be higher than 0',
          toastId: id,
        });
      } else if (tireInfo?.available < 1) {
        notificationThrower({
          type: 'info',
          title: 'Item not in stock',
          toastId: id,
        });
      } else if (quantity2 > tireInfo?.available) {
        notificationThrower({
          type: 'warning',
          title: 'Amount is higher than available stock',
        });
        role !== ROLES.RESELLER && setQuantity2(tireInfo?.available);
      }
    }
  };

  const handleFavorite = async (type: string, articleCode: string) => {
    switch (type) {
      case 'add':
        addFavorite({ articleCode })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Item Added To Favorites Successfully',
            });
            setFavorite2(!favorite2);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Add Item To Favorites',
            });
          });
        break;
      case 'remove':
        deleteFavorite({ articleCode })
          .unwrap()
          .then(() => {
            notificationThrower({
              type: 'success',
              title: 'Item Removed From Favorites Successfully',
            });
            setFavorite2(!favorite2);
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Remove Item From Favorites',
            });
          });
        break;
    }
  };

  useEffect(() => {
    if (id) {
      getSingleArticle({ code: id })
        .unwrap()
        .then(payload => {
          setTireInfo(articleDataTransformer(payload, 1));
          setFavorite2(payload?.favourite);
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Tire Data',
          });
        });
      role !== ROLES.RESELLER &&
        getWarehouseInfo({ code: id })
          .unwrap()
          .then(payload => {
            setWarehouseInfo(
              payload?.map(article => ({
                warehouse: article?.KMAG,
                qty: article?.GJENDJE,
              })),
            );
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Get Warehouse Data',
            });
          });
    }
  }, [id]);

  return (
    <div className="article-details-container">
      <div className="article-details-header">
        <div className="title">
          <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
          <span>Article Details</span>
        </div>
        <div className="icon-container">
          <div className="home">
            <Home className="home-svg" onClick={() => navigate('/')} />
          </div>
          {role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN && (
            <div className="cart" onClick={() => navigate('/cart')}>
              <Cart className="cart-svg" />
              <div className="badge">{cartItems.length}</div>
            </div>
          )}
        </div>
      </div>
      <div className="details-wrapper">
        {isFetching ? (
          <Spinner wrapperStyle={{ height: '80vh' }} />
        ) : !isFetching && !tireInfo?.id ? (
          <div className="no-data">No Data</div>
        ) : (
          tireInfo && (
            <>
              <section className="top-section">
                <div className="head">#{tireInfo?.id}</div>
                <div className="row">
                  <article className="brand">
                    <span>Brand:</span> {tireInfo?.brand}
                  </article>
                  <article className="sap">
                    <span>SAP Code:</span>
                    {tireInfo?.sap}
                  </article>
                </div>
                <article className="description">
                  <span>Description:</span> {tireInfo?.description}
                </article>
                <div className="row">
                  <article className="season">
                    <span>Season:</span> {tireInfo?.season}
                  </article>
                  <article className="type">
                    <span>Car Type:</span> {tireInfo?.car}
                  </article>
                </div>
              </section>
              <section className="middle-section">
                <div className="row">
                  <article className="size">
                    <span>Size:</span> {tireInfo?.size}
                  </article>
                  <article className="radial">
                    <span>Radial:</span>
                    {tireInfo?.radial}
                  </article>
                </div>
                <div className="row">
                  <article className="year">
                    <span>Year:</span> {tireInfo?.year}
                  </article>
                  <article className="price">
                    <span>Price:</span> € {tireInfo?.price}
                  </article>
                  <article className="stock">
                    <span>Stock: {'  '}</span>{' '}
                    {role !== ROLES.RESELLER
                      ? tireInfo?.available
                      : tireInfo?.available > 2
                      ? '2+'
                      : tireInfo?.available}
                  </article>
                </div>
              </section>

              {role !== ROLES.RESELLER && (
                <section className="warehouse-section">
                  <div className="head">Warehouse</div>
                  <div className="row">
                    {warehouseInfo?.map((article, index) => {
                      return (
                        <article key={index} className="warehouse">
                          <span>{article?.warehouse}: </span> {article?.qty}
                        </article>
                      );
                    })}
                  </div>
                </section>
              )}

              {role !== ROLES.ADMIN && (
                <section className="quantity-section">
                  <FormProvider {...formConfig}>
                    <div className="quantity">
                      <span>Order Quantity</span>

                      <InputFormItem
                        name="quantity"
                        type="number"
                        className="quantity-input"
                        min="1"
                        max={
                          role !== ROLES.RESELLER ? tireInfo?.available : null
                        }
                        value={quantity2}
                        onChange={(e: any) =>
                          setQuantity2(Math.abs(e.target.value))
                        }
                      />
                    </div>
                  </FormProvider>
                </section>
              )}

              {role !== ROLES.ADMIN && (
                <section className="bottom-section">
                  <button className="add-cart" onClick={handleAddToCart}>
                    Add To Cart
                  </button>
                  {favorite2 ? (
                    <StarFill
                      className="favorite-svg"
                      onClick={() => {
                        handleFavorite('remove', tireInfo?.id);
                      }}
                    />
                  ) : (
                    <Star
                      className="favorite-svg"
                      onClick={() => {
                        handleFavorite('add', tireInfo?.id);
                      }}
                    />
                  )}
                </section>
              )}
            </>
          )
        )}
      </div>
    </div>
  );
};
