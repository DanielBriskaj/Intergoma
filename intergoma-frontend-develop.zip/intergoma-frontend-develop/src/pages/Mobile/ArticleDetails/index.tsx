export { ArticleDetails as default } from './ArticleDetails';
