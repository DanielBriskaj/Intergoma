import React, { useEffect, useState } from 'react';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { useNavigate } from 'react-router';
import TireCards from '../../../components/TireCards';
import { articleDataTransformer } from '../../../helpers/dataTransformers/articleDataTransformer';
import { useFetchAllArticlesQuery } from '../../../redux/slices/articles/articlesApi';
import notificationThrower from '../../../helpers/notificationThrower';
import { useSelector } from 'react-redux';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import { TireCardsProps } from '../../../interfaces/shopping';
import InfiniteScroll from 'react-infinite-scroller';
import Spinner from '../../../components/Spinner';
import { delay } from '../../../helpers/delay';
import { ROLES } from '../../../constants/enums/roles';
import { getUserRole } from '../../../helpers/getUserInfo';
import _ from 'lodash';

export const MobileShopping: React.FC = () => {
  const navigate = useNavigate();
  const role = getUserRole();
  const searching = localStorage.getItem('searchArticles');
  const searchArticles = JSON.parse(searching!);

  const cartItems = useSelector(selectCartItems);
  const [allItems, setAllItems] = useState([] as TireCardsProps[]);
  const [tableData, setTableData] = useState([] as TireCardsProps[]);
  const [offset, setOffset] = useState<number>(0);
  const [limit, setLimit] = useState<number>(10);
  const [loading, setLoading] = useState<boolean>(true);
  const [hasMore, setHasMore] = useState<boolean>(true);

  const {
    data: articleData = [],
    isFetching,
    error,
  } = useFetchAllArticlesQuery();

  useEffect(() => {
    if (error) {
      notificationThrower({
        type: 'error',
        title: 'Something Went Wrong',
      });
    }
  }, [error]);

  useEffect(() => {
    if (articleData.length > 0) {
      const items = articleData?.filter(
        item =>
          (searchArticles?.hasStock ? item.GJENDJE > 0 : item) &&
          (searchArticles?.brand
            ? item.KLASIF === searchArticles?.brand?.toUpperCase()
            : item) &&
          (searchArticles?.carType
            ? item?.KLASIF5 === searchArticles?.carType
            : item) &&
          (searchArticles?.tireSize
            ? item?.KLASIF3 === searchArticles?.tireSize
            : item) &&
          (searchArticles?.season
            ? item?.KLASIF4 === searchArticles?.season
            : item),
      );

      items.map((article, index) => {
        if (article.KLASIF2) {
          const objectValue = articleDataTransformer(article, index);

          setAllItems(state => [objectValue, ...state]);
        }
      });
      setLoading(false);
    }
  }, [articleData]);

  const loadMore = async (e: any) => {
    if (hasMore) {
      setLoading(true);
      if (allItems.length > 0) {
        await delay();
        const sortItems = _.orderBy(allItems, ['available'], ['desc']);
        setTableData([...tableData, ...sortItems.slice(offset, limit)]);
        if (allItems.length <= limit) {
          setHasMore(false);
        } else {
          setOffset(offset + 10);
          setLimit(limit + 10);
        }
        setLoading(false);
      } else if (allItems.length == 0) {
        setHasMore(false);
        setLoading(false);
      } else {
        setLoading(false);
      }
    }
  };

  return (
    <div className="mobile-shopping-container">
      <div className="shopping-wrapper">
        <div className="shopping-header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Shopping</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home
                className="home-svg"
                onClick={() => {
                  navigate('/');
                  localStorage.removeItem('searchArticles');
                }}
              />
            </div>
            {role !== ROLES.ADMIN && (
              <div className="cart" onClick={() => navigate('/cart')}>
                <Cart className="cart-svg" />
                <div className="badge">{cartItems.length}</div>
              </div>
            )}
          </div>
        </div>
        <div className="shopping-items">
          <InfiniteScroll
            initialLoad
            pageStart={0}
            loadMore={e => loadMore(e)}
            hasMore={!loading && hasMore}
            loader={
              <div className="loader" key={0}>
                <Spinner wrapperStyle={{ height: '50px' }} />
              </div>
            }
            style={{ marginTop: '30px' }}
          >
            {isFetching ? (
              <></>
            ) : allItems?.length === 0 ? (
              <div className="no-items">No items available !</div>
            ) : (
              tableData?.map((item, index) => {
                return <TireCards key={index} {...item} />;
              })
            )}
          </InfiniteScroll>
          {loading && (
            <Spinner
              wrapperStyle={{
                height: tableData?.length == 0 ? '70vh' : '50px',
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
