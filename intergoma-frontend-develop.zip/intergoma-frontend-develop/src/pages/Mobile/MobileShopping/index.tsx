export { MobileShopping as default } from './MobileShopping';
