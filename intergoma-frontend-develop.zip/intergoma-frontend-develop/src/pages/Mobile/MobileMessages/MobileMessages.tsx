import React, { useState } from 'react';
import { useLazyFetchAllMessagesQuery } from '../../../redux/slices/messages/messagesApi';
import notificationThrower from '../../../helpers/notificationThrower';
import { Tabs } from 'antd';
import MessageCard from '../../../components/MessageCard';
import { ReactComponent as Plus } from '../../../assets/svgIcons/plus-circle-fill.svg';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import InfiniteScroll from 'react-infinite-scroller';
import { Message, MessageQuery } from '../../../interfaces/message';
import NewMessage from '../../../components/NewMessage';
import Spinner from '../../../components/Spinner';
import { useDispatch, useSelector } from 'react-redux';
import { selectLoggedState } from '../../../redux/slices/auth/authSlice';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import { useNavigate } from 'react-router';
import { ROLES } from '../../../constants/enums/roles';
import { getUserRole } from '../../../helpers/getUserInfo';
import {
  changeMessageTabs,
  selectMessagesTabs,
} from '../../../redux/slices/miscellaneous/miscellaneousSlice';
import { delay } from '../../../helpers/delay';

export const MobileMessages: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const role = getUserRole();
  const cartItems = useSelector(selectCartItems);
  const currentTab = useSelector(selectMessagesTabs);
  const user = useSelector(selectLoggedState);
  const { userId } = user;
  const { TabPane } = Tabs;
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [messageArray, setMessageArray] = useState<Message[]>([]);
  const [createMessage, setCreateMessage] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const [getAll, { isFetching }] = useLazyFetchAllMessagesQuery();

  const query: MessageQuery = {};
  query.page = currentPage;
  currentTab === 'inbox'
    ? (query.idReceiver = Number(userId))
    : (query.idSender = Number(userId));

  const handleMessageClick = (id: number) => {
    navigate(`/messages/read/${id}`);
  };

  const onTabChange = (key: string) => {
    dispatch(changeMessageTabs(key));
    setMessageArray([]);
    setCurrentPage(0);
    setHasMore(true);
  };

  const resetMessage = () => {
    setCurrentPage(0);
    setMessageArray([]);
    setHasMore(true);
  };

  const loadMore = async (e: number) => {
    if (hasMore) {
      setLoading(true);
      getAll(query)
        .unwrap()
        .then(async payload => {
          await delay();
          setMessageArray([...messageArray, ...payload?.messages]);
          if (payload?.totalPages <= currentPage + 1) {
            setHasMore(false);
          } else {
            setCurrentPage(currentPage + 1);
          }
          setLoading(false);
        })
        .catch(error => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Messages',
          });
          setLoading(false);
          setHasMore(false);
        });
    }
  };

  return (
    <div className="mobile-messages-container">
      <div className="messages-wrapper">
        <div className="messages-header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Messages</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home className="home-svg" onClick={() => navigate('/')} />
            </div>
            {role !== ROLES.BACK_OFFICE && (
              <div className="cart" onClick={() => navigate('/cart')}>
                <Cart className="cart-svg" />
                <div className="badge">{cartItems.length}</div>
              </div>
            )}
          </div>
        </div>
        {userId ? (
          <div className="body">
            <Tabs defaultActiveKey={currentTab} onChange={onTabChange}>
              <TabPane tab="Inbox" key="inbox">
                <InfiniteScroll
                  initialLoad
                  pageStart={0}
                  loadMore={e => loadMore(e)}
                  hasMore={!loading && hasMore}
                  loader={
                    <div className="loader" key={0}>
                      <Spinner wrapperStyle={{ height: '50px' }} />
                    </div>
                  }
                >
                  {isFetching && messageArray?.length == 0 ? (
                    <></>
                  ) : !loading && messageArray?.length == 0 ? (
                    <div className="no-msg">No Messages</div>
                  ) : (
                    messageArray?.map((message, index) => {
                      return (
                        <MessageCard
                          {...message}
                          key={index}
                          handleMessageClick={handleMessageClick}
                          openMsg={null}
                        />
                      );
                    })
                  )}
                </InfiniteScroll>
                {loading && (
                  <Spinner
                    wrapperStyle={{
                      height: messageArray?.length == 0 ? '70vh' : '50px',
                    }}
                  />
                )}
              </TabPane>
              <TabPane tab="Outbox" key="outbox">
                <InfiniteScroll
                  initialLoad
                  pageStart={0}
                  loadMore={e => loadMore(e)}
                  hasMore={!loading && hasMore}
                  loader={
                    <div className="loader" key={0}>
                      <Spinner wrapperStyle={{ height: '50px' }} />
                    </div>
                  }
                >
                  {isFetching && messageArray?.length == 0 ? (
                    <></>
                  ) : !loading && messageArray?.length == 0 ? (
                    <div className="no-msg">No Messages</div>
                  ) : (
                    messageArray?.map((message, index) => {
                      return (
                        <MessageCard
                          {...message}
                          key={index}
                          handleMessageClick={handleMessageClick}
                          openMsg={null}
                        />
                      );
                    })
                  )}
                  {loading && (
                    <Spinner
                      wrapperStyle={{
                        height: messageArray?.length == 0 ? '70vh' : '50px',
                      }}
                    />
                  )}
                </InfiniteScroll>
              </TabPane>
            </Tabs>
            <div className="button-container">
              <Plus
                className="plus-svg"
                onClick={() => setCreateMessage(true)}
              />
            </div>
          </div>
        ) : (
          <Spinner />
        )}
      </div>
      {userId !== 0 && (
        <NewMessage
          createMessage={createMessage}
          setCreateMessage={setCreateMessage}
          resetMessage={resetMessage}
        />
      )}
    </div>
  );
};
