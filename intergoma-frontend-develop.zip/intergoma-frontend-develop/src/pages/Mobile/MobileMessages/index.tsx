export { MobileMessages as default } from './MobileMessages';
