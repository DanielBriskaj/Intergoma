import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useSelector } from 'react-redux';
import {
  useDeleteUserMutation,
  useLazyFetchSingleUserQuery,
  useUpdateUserMutation,
} from '../../../redux/slices/users/usersApi';
import { yupResolver } from '@hookform/resolvers/yup';
import { userSchema } from '../../../helpers/yupSchemas/signUpSchema';
import notificationThrower from '../../../helpers/notificationThrower';
import InputFormItem from '../../../components/InputFormItem';
import SingleSelect from '../../../components/SingleSelect';
import {
  RoleOptions,
  WarehouseOptions,
} from '../../../components/UserModal/UserModal';
import Spinner from '../../../components/Spinner';
import { useNavigate, useParams } from 'react-router';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { Modal } from 'antd';
import { selectLoggedState } from '../../../redux/slices/auth/authSlice';

type UserInfo =
  | 'firstName'
  | 'lastName'
  | 'username'
  | 'email'
  | 'password'
  | 'warehouse'
  | 'role';

export const MobileEditUser: React.FC = () => {
  const navigate = useNavigate();
  const loggeduser = useSelector(selectLoggedState);
  const { username } = loggeduser;
  const { id } = useParams();
  const { confirm } = Modal;

  const [updateUser, { isLoading }] = useUpdateUserMutation();
  const [deleteUser, { isLoading: deleteLoading }] = useDeleteUserMutation();
  const [getSingleUser, { data: singleUser, isFetching }] =
    useLazyFetchSingleUserQuery();

  const [initialValues, setInitialValues] = useState(() => {
    return {
      firstName: null,
      lastName: null,
      username: null,
      email: null,
      password: null,
      role: null,
      warehouse: null,
      clientCode: null,
    };
  });

  const form = useForm({
    reValidateMode: 'onSubmit',
    resolver: yupResolver(userSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const showConfirm = () => {
    confirm({
      title: `Are you sure you want to delete ${singleUser?.username}?`,
      centered: true,
      wrapClassName: 'mobile-confirm-modal',
      maskClosable: true,
      className: 'animate__animated  animate__fadeInUp',
      transitionName: '',
      maskTransitionName: '',
      onOk() {
        handleDeleteUser();
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const handleDeleteUser = async () => {
    deleteUser({ id: Number(id) })
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: 'User Deleted Successfully',
        });
        navigate(-1);
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Delete User',
        });
      });
  };

  const handleSubmit = async (data: any) => {
    const transformedData = {
      id: id,
      ...data,
      warehouse:
        data?.role === 'AGENT'
          ? data?.warehouse
          : data?.role === 'RESELLER'
          ? 'MQ'
          : null,
    };
    updateUser(transformedData)
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: 'User Updated Successfully',
        });
      })
      .catch(error => {
        if (error?.data === 'Client code was not found in F5') {
          form.setError(
            'clientCode',
            { type: 'focus', message: 'Client Code Not Found!' },
            { shouldFocus: true },
          );
        }
        notificationThrower({
          type: 'error',
          title: 'Failed To Update User',
        });
      });
  };

  useEffect(() => {
    if (id) {
      getSingleUser({ id: Number(id) });
    }
  }, [id]);

  const value = (options: any, value: any, name: UserInfo) => {
    if (value != null) {
      form.setValue(name, value);
      return options.find((option: any) => option.value === value);
    }
    return null;
  };

  useEffect(() => {
    if (singleUser) {
      setInitialValues(() => {
        return {
          firstName: singleUser?.firstName,
          lastName: singleUser?.lastName,
          username: singleUser?.username,
          email: singleUser?.email,
          role: singleUser?.role,
          password: null,
          warehouse: singleUser?.warehouse,
          clientCode: singleUser?.clientCode,
        };
      });
    }
  }, [singleUser]);

  return (
    <div className="mobile-edit-user-container">
      <div className="user-header">
        <div className="title">
          <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
          <span>User Details</span>
        </div>
        <div className="icon-container">
          <div className="home">
            <Home className="home-svg" onClick={() => navigate('/')} />
          </div>
        </div>
      </div>
      <div className="user-wrapper">
        {isFetching ? (
          <Spinner wrapperStyle={{ height: '85vh' }} />
        ) : (
          <FormProvider {...form}>
            <form
              className="user-form"
              onSubmit={form.handleSubmit(handleSubmit)}
              autoComplete="off"
            >
              <InputFormItem
                name="firstName"
                placeholder="Firstname"
                defaultValue={initialValues?.firstName}
              />
              <InputFormItem
                name="lastName"
                placeholder="Lastname"
                defaultValue={initialValues?.lastName}
              />
              <InputFormItem
                name="email"
                placeholder="Email"
                defaultValue={initialValues?.email}
              />
              <InputFormItem
                name="username"
                placeholder="Username"
                disabled={true}
                defaultValue={initialValues?.username}
              />
              <SingleSelect
                name="role"
                options={RoleOptions}
                placeholder="Role"
                controlledValue={value(
                  RoleOptions,
                  initialValues?.role,
                  'role',
                )}
                onChange={(e: any) => {
                  setInitialValues((oldInitialValues: any) => {
                    return {
                      ...oldInitialValues,
                      role: e.value,
                    };
                  });
                }}
                isSearchable={false}
                disabled={initialValues?.username === username}
              />
              {initialValues?.role === 'AGENT' && (
                <SingleSelect
                  name="warehouse"
                  options={WarehouseOptions}
                  placeholder="Warehouse"
                  controlledValue={value(
                    WarehouseOptions,
                    initialValues?.warehouse,
                    'warehouse',
                  )}
                  onChange={(e: any) => {
                    setInitialValues((oldInitialValues: any) => {
                      return {
                        ...oldInitialValues,
                        warehouse: e.value,
                      };
                    });
                  }}
                  isSearchable={false}
                />
              )}
              {initialValues?.role === 'RESELLER' && (
                <InputFormItem
                  name="clientCode"
                  placeholder="Client Code"
                  defaultValue={initialValues?.clientCode}
                />
              )}
            </form>
          </FormProvider>
        )}
        <div className="form-footer">
          <button
            className="btn-delete"
            type="button"
            disabled={deleteLoading || initialValues?.username === username}
            onClick={showConfirm}
          >
            Delete
          </button>
          <button
            className="btn-save"
            type="submit"
            disabled={isLoading}
            onClick={form.handleSubmit(handleSubmit)}
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};
