import React, { useEffect, useState } from 'react';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { useNavigate } from 'react-router';
import TireCards from '../../../components/TireCards';
import { articleDataTransformer } from '../../../helpers/dataTransformers/articleDataTransformer';
import { useLazyFetchAllArticlesQuery } from '../../../redux/slices/articles/articlesApi';
import notificationThrower from '../../../helpers/notificationThrower';
import { useSelector } from 'react-redux';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import { TireCardsProps } from '../../../interfaces/shopping';
import InfiniteScroll from 'react-infinite-scroller';
import Spinner from '../../../components/Spinner';
import { delay } from '../../../helpers/delay';
import { getUserRole } from '../../../helpers/getUserInfo';
import { ROLES } from '../../../constants/enums/roles';
import _ from 'lodash';

export const MobileFavorites: React.FC = () => {
  const navigate = useNavigate();
  const role = getUserRole();
  const cartItems = useSelector(selectCartItems);
  const [allItems, setAllItems] = useState([] as TireCardsProps[]);
  const [tableData, setTableData] = useState([] as TireCardsProps[]);
  const [offset, setOffset] = useState<number>(0);
  const [limit, setLimit] = useState<number>(10);
  const [loading, setLoading] = useState<boolean>(true);
  const [hasMore, setHasMore] = useState<boolean>(true);

  const [getFavorites, { isFetching }] = useLazyFetchAllArticlesQuery();

  useEffect(() => {
    getFavorites()
      .unwrap()
      .then(articleData => {
        articleData.map((article, index) => {
          if (article.favourite) {
            const objectValue = articleDataTransformer(article, index);
            setAllItems(state => [objectValue, ...state]);
          }
        });
        setLoading(false);
      })
      .catch(error => {
        notificationThrower({
          type: 'error',
          title: 'Something Went Wrong',
        });
      });
  }, []);

  const loadMore = async (e: any) => {
    if (hasMore) {
      setLoading(true);
      if (allItems.length > 0) {
        await delay();
        const sortItems = _.orderBy(allItems, ['available'], ['desc']);
        setTableData([...tableData, ...sortItems.slice(offset, limit)]);
        if (allItems.length <= limit) {
          setHasMore(false);
        } else {
          setOffset(offset + 10);
          setLimit(limit + 10);
        }
        setLoading(false);
      } else if (allItems.length == 0) {
        setHasMore(false);
        setLoading(false);
      } else {
        setLoading(false);
      }
    }
  };

  return (
    <div className="mobile-shopping-container">
      <div className="shopping-wrapper">
        <div className="shopping-header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Favorites</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home className="home-svg" onClick={() => navigate('/')} />
            </div>
            {role !== ROLES.ADMIN && (
              <div className="cart" onClick={() => navigate('/cart')}>
                <Cart className="cart-svg" />
                <div className="badge">{cartItems.length}</div>
              </div>
            )}
          </div>
        </div>

        <div className="shopping-items">
          <InfiniteScroll
            initialLoad
            pageStart={0}
            loadMore={e => loadMore(e)}
            hasMore={!loading && hasMore}
            loader={
              <div className="loader" key={0}>
                <Spinner wrapperStyle={{ height: '50px' }} />
              </div>
            }
            style={{ marginTop: '30px' }}
          >
            {isFetching ? (
              <></>
            ) : allItems?.length === 0 ? (
              <div className="no-items">No items available !</div>
            ) : (
              tableData?.map((item, index) => {
                return <TireCards key={index} {...item} />;
              })
            )}
          </InfiniteScroll>
          {loading && (
            <Spinner
              wrapperStyle={{
                height: tableData?.length == 0 ? '70vh' : '50px',
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
