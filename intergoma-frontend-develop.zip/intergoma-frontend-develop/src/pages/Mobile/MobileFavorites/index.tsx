export { MobileFavorites as default } from './MobileFavorites';
