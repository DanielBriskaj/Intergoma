import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router';
import Spinner from '../../../components/Spinner';
import { getUserRole } from '../../../helpers/getUserInfo';
import { selectLoggedState } from '../../../redux/slices/auth/authSlice';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as Trash } from '../../../assets/svgIcons/trash-fill.svg';
import { ROLES } from '../../../constants/enums/roles';
import {
  useDeleteMessageMutation,
  useLazyFetchSingleMessageQuery,
  useMarkAsReadMutation,
} from '../../../redux/slices/messages/messagesApi';
import notificationThrower from '../../../helpers/notificationThrower';
import { format, parseISO } from 'date-fns';
import { Modal } from 'antd';
import { selectMessagesTabs } from '../../../redux/slices/miscellaneous/miscellaneousSlice';

export const ReadMessages: React.FC = () => {
  const navigate = useNavigate();
  const params = useParams();
  const role = getUserRole();
  const cartItems = useSelector(selectCartItems);
  const currentTab = useSelector(selectMessagesTabs);
  const user = useSelector(selectLoggedState);
  const { userId } = user;
  const { id: messageId } = params;
  const { confirm } = Modal;

  const [getSingleMessage, { data, isFetching, isError }] =
    useLazyFetchSingleMessageQuery();
  const [deleteMessage] = useDeleteMessageMutation();
  const [markRead] = useMarkAsReadMutation();

  useEffect(() => {
    getSingleMessage({ id: Number(messageId) })
      .unwrap()
      .then(message => {
        if (currentTab === 'inbox' && !message?.isRead) {
          markRead(message?.id)
            .unwrap()
            .catch(error => {
              notificationThrower({
                type: 'error',
                title: `Failed To Mark Message As Read`,
              });
            });
        }
      })
      .catch(error => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Read Message',
        });
      });
  }, [messageId]);

  const handleDeleteMessage = async (id: number) => {
    const response: any = await deleteMessage({ id });
    if (response?.error?.originalStatus === 200) {
      notificationThrower({
        type: 'success',
        title: 'Message Deleted Successfully',
      });
      navigate(-1);
    } else {
      notificationThrower({
        type: 'error',
        title: 'Failed To Delete Message',
      });
    }
  };

  const showConfirm = () => {
    confirm({
      title: 'Are you sure you want to delete this message?',
      centered: true,
      wrapClassName: 'mobile-confirm-modal',
      maskClosable: true,
      className: 'animate__animated  animate__fadeInUp',
      transitionName: '',
      maskTransitionName: '',
      onOk() {
        handleDeleteMessage(Number(messageId));
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  return (
    <div className="read-messages-container">
      <div className="messages-wrapper">
        <div className="messages-header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Messages</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home className="home-svg" onClick={() => navigate('/')} />
            </div>
            {role !== ROLES.BACK_OFFICE && (
              <div className="cart" onClick={() => navigate('/cart')}>
                <Cart className="cart-svg" />
                <div className="badge">{cartItems.length}</div>
              </div>
            )}
          </div>
        </div>
        {userId ? (
          <div className="body">
            {!isFetching && !isError ? (
              <div className="message-data">
                <div className="details">
                  <div className="date">
                    <span>Date Sent: </span>
                    {data && format(parseISO(data?.sentDate), 'dd-MM-yyyy')}
                  </div>
                  <div className="date">
                    <span>Date Read: </span>
                    {data?.readAt
                      ? format(parseISO(data?.readAt), 'dd-MM-yyyy')
                      : 'Unread'}
                  </div>
                  <div className="sender">
                    <span> Sent By: </span> {data?.sender?.username}
                  </div>
                </div>
                <div className="text">{data?.messageText}</div>
                <div className="footer">
                  <span style={{ cursor: 'pointer' }} onClick={showConfirm}>
                    <Trash className="delete-svg" fill="#014e9e" />
                    Delete
                  </span>
                </div>
              </div>
            ) : isError ? (
              <div className="no-data">No Data</div>
            ) : (
              <Spinner />
            )}
          </div>
        ) : (
          <Spinner />
        )}
      </div>
    </div>
  );
};
