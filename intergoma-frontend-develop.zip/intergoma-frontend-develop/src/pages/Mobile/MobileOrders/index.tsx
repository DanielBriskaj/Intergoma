export { MobileOrders as default } from './MobileOrder';
