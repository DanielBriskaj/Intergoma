import React, { useState, useEffect } from 'react';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { useNavigate } from 'react-router';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import { useSelector } from 'react-redux';
import { getUserRole } from '../../../helpers/getUserInfo';
import { ROLES } from '../../../constants/enums/roles';
import { FormProvider, useForm } from 'react-hook-form';
import InputFormItem from '../../../components/InputFormItem';
import OrderCard from '../../../components/OrderCard';
import { useLazyFetchAllOrdersQuery } from '../../../redux/slices/order/orderApi';
import { selectLoggedState } from '../../../redux/slices/auth/authSlice';
import notificationThrower from '../../../helpers/notificationThrower';
import InfiniteScroll from 'react-infinite-scroller';
import Spinner from '../../../components/Spinner';
import { OrderProps, OrdersQuery } from '../../../interfaces/order';
import { debounce } from 'lodash';
import { useLazyFetchAllClientsQuery } from '../../../redux/slices/clients/clientsApi';
import { delay } from '../../../helpers/delay';
import { ClientOptions } from '../../Reports/orderArticleReports';
import SingleSelect from '../../../components/SingleSelect';
import clientDataTransformer from '../../../helpers/order/clientDataTransformer';

export const MobileOrders: React.FC = () => {
  const navigate = useNavigate();
  const role = getUserRole();

  const cartItems = useSelector(selectCartItems);
  const loggedUser = useSelector(selectLoggedState);
  const { userId } = loggedUser;

  const [clientCode, setClientCode] = useState<string>('');
  const [clientOptions, setClientOptions] = useState<ClientOptions[]>([]);
  const [orderArray, setOrderArray] = useState<OrderProps[]>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [page, setPage] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [getAllOrders] = useLazyFetchAllOrdersQuery();
  const [getAllClients, { isFetching: loadingClients }] =
    useLazyFetchAllClientsQuery();

  const query: OrdersQuery = {
    page: page,
    size: 10,
    clientCode: clientCode ? clientCode : null,
    userId: role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN ? userId : null,
  };

  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  useEffect(() => {
    role !== ROLES.RESELLER &&
      getAllClients(0, true)
        .unwrap()
        .then(payload => {
          setClientOptions(clientDataTransformer(payload));
        });
    setPage(0);
    setHasMore(true);
    setOrderArray([]);

    if (orderArray.length === 0) {
      loadMore(0);
    }
  }, [userId, clientCode]);

  const loadMore = async (e: number) => {
    if (hasMore) {
      setIsLoading(true);
      userId !== 0 &&
        getAllOrders(query)
          .unwrap()
          .then(async payload => {
            await delay();
            setOrderArray([...orderArray, ...payload?.orders]);
            if (payload?.totalPages <= page + 1) {
              setHasMore(false);
            } else {
              setPage(page + 1);
            }
            setIsLoading(false);
          })
          .catch(error => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Get Orders',
            });
            setIsLoading(false);
            setHasMore(false);
          });
    }
  };

  return (
    <div className="mobile-orders-container">
      <div className="orders-wrapper">
        <div className="orders-header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Orders</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home className="home-svg" onClick={() => navigate('/')} />
            </div>
            {role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN && (
              <div className="cart" onClick={() => navigate('/cart')}>
                <Cart className="cart-svg" />
                <div className="badge">{cartItems.length}</div>
              </div>
            )}
          </div>
        </div>
        <div className="order-items">
          {role !== ROLES.RESELLER && (
            <FormProvider {...formConfig}>
              <div className="search">
                <SingleSelect
                  placeholder="Select Client"
                  name="clientCode"
                  options={clientOptions}
                  isLoading={loadingClients}
                  isClearable={true}
                  onChange={(option: ClientOptions) => {
                    setPage(0);
                    setClientCode(option?.value);
                  }}
                />
              </div>
            </FormProvider>
          )}
          <InfiniteScroll
            initialLoad
            pageStart={0}
            loadMore={e => loadMore(e)}
            hasMore={!isLoading && hasMore}
            style={{ marginTop: '20px' }}
            loader={
              <div className="loader" key={0}>
                <Spinner wrapperStyle={{ height: '50px' }} />
              </div>
            }
          >
            {orderArray?.length !== 0 ? (
              orderArray?.map((order: OrderProps, index: number) => {
                return <OrderCard key={index} {...order} />;
              })
            ) : !isLoading && orderArray?.length === 0 ? (
              <div className="no-orders">No Orders</div>
            ) : (
              <></>
            )}
          </InfiniteScroll>
          {isLoading && (
            <Spinner
              wrapperStyle={{
                height: orderArray?.length == 0 ? '70vh' : '50px',
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
