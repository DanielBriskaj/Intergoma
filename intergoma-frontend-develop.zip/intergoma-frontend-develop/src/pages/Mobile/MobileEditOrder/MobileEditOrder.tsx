import React, { useEffect, useState } from 'react';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { useNavigate, useParams } from 'react-router';
import { ROLES } from '../../../constants/enums/roles';
import { getUserRole } from '../../../helpers/getUserInfo';
import { useDispatch, useSelector } from 'react-redux';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import Spinner from '../../../components/Spinner';
import getTotalPrice from '../../../helpers/order/getTotalPrice';
import { useLazyFetchAllClientsQuery } from '../../../redux/slices/clients/clientsApi';
import { format, parseISO } from 'date-fns';
import { Modal } from 'antd';
import getOrderStatusLabel from '../../../helpers/order/orderStatusLabel';
import { ORDER_STATUS } from '../../../constants/enums/orders';
import {
  useDeleteOrderMutation,
  useLazyFetchSingleOrderQuery,
  useProcessOrderMutation,
} from '../../../redux/slices/order/orderApi';
import notificationThrower from '../../../helpers/notificationThrower';
import { OrderProps } from '../../../interfaces/order';
import { downloadPDF } from '../../../redux/slices/order/orderSlice';

export const MobileEditOrder: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const role = getUserRole();
  const { id } = useParams();
  const { confirm } = Modal;
  const cartItems = useSelector(selectCartItems);
  const [singleOrder, setSingleOrder] = useState<OrderProps>();

  const [getSingleOrder, { isFetching }] = useLazyFetchSingleOrderQuery();
  const [deleteOrder] = useDeleteOrderMutation();
  const [processOrder] = useProcessOrderMutation();

  const showConfirm = () => {
    confirm({
      title: `Are you sure you want to delete Order ${singleOrder?.id}?`,
      centered: true,
      wrapClassName: 'mobile-confirm-modal',
      maskClosable: true,
      className: 'animate__animated  animate__fadeInUp',
      transitionName: '',
      maskTransitionName: '',
      onOk() {
        handleDeleteOrder();
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  useEffect(() => {
    getSingleOrder(Number(id), true)
      .unwrap()
      .then(payload => {
        setSingleOrder(payload);
      })
      .catch(error => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Get Order!',
        });
      });
  }, [id]);

  const handleDeleteOrder = () => {
    deleteOrder(Number(id))
      .unwrap()
      .then(payload => {
        notificationThrower({
          type: 'success',
          title: 'Order Deleted Successfully!',
        });
        navigate(-1);
      })
      .catch(error => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Delete Order!',
        });
      });
  };

  const handleProcessOrder = () => {
    const data = {
      orderStatus: ORDER_STATUS.CONFIRMED,
    };
    processOrder({ id: Number(id), data })
      .unwrap()
      .then(payload => {
        setSingleOrder(payload);
        notificationThrower({
          type: 'success',
          title: 'Order Processed Successfully!',
        });
      })
      .catch(error => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Process Order',
        });
      });
  };

  const handleDownloadPDF = () => {
    dispatch(downloadPDF(Number(id)));
  };

  return (
    <div className="mobile-edit-order-container">
      <div className="order-header">
        <div className="title">
          <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
          <span>Order Details</span>
        </div>
        <div className="icon-container">
          <div className="home">
            <Home className="home-svg" onClick={() => navigate('/')} />
          </div>
          {role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN && (
            <div className="cart" onClick={() => navigate('/cart')}>
              <Cart className="cart-svg" />
              <div className="badge">{cartItems.length}</div>
            </div>
          )}
        </div>
      </div>
      <div className="order-wrapper">
        {isFetching ? (
          <Spinner />
        ) : !isFetching && !singleOrder?.id ? (
          <div className="no-data">No Data</div>
        ) : (
          singleOrder && (
            <>
              <div className="order-details">
                <div className="info">
                  <div className="head">
                    <div className="order-nr">Order #{id}</div>
                    <div className="status">
                      {getOrderStatusLabel(singleOrder?.orderStatus)}
                    </div>
                  </div>
                  <article className="client-name">
                    <span> Client : </span>
                    {singleOrder?.f5Client?.PERSHKRIM +
                      ' - ' +
                      singleOrder?.clientCode}
                  </article>
                  <div className="row">
                    <article className="created">
                      <span> Agent: </span>
                      {singleOrder?.user?.username}
                    </article>
                    <article className="total">
                      <span> Order Total: </span>€{' '}
                      {getTotalPrice(
                        singleOrder?.orderArticles?.map(
                          article => article?.quantity * article?.sellingPrice,
                        ),
                      )?.toLocaleString('en-US')}
                    </article>
                  </div>
                  <div className="row">
                    <article className="date">
                      <span> Date: </span>
                      {format(
                        parseISO(singleOrder?.documentDate),
                        'dd-MM-yyyy',
                      )}
                    </article>

                    <article className="warehouse">
                      <span> Warehouse: </span>
                      {singleOrder?.magazineCode}
                    </article>
                  </div>

                  <article className="place">
                    <span> Delivery Place : </span>
                    {singleOrder?.deliveryPlace}
                  </article>
                </div>
                <div className="order-items">
                  {singleOrder?.orderArticles?.map((article, index) => {
                    return (
                      <div className="item-wrapper" key={index}>
                        <div className="item">
                          {article?.productCode} - {article?.productType}
                        </div>
                        <div className="arcticle-info">
                          <div className="quantity">
                            <span> Quantity:</span> {article?.quantity}
                          </div>
                          <div className="selling">
                            <span>Price: € </span>{' '}
                            {article?.sellingPrice?.toLocaleString('en-US')}
                          </div>
                          <div className="total">
                            <span>Total: € </span>{' '}
                            {(
                              article?.quantity * article?.sellingPrice
                            )?.toLocaleString('en-US')}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="notes">
                  <span>Notes: </span>
                  {singleOrder?.note}
                </div>
              </div>
              <div className="order-footer">
                <button
                  className="delete"
                  onClick={showConfirm}
                  disabled={
                    role !== ROLES.BACK_OFFICE &&
                    singleOrder?.orderStatus !== ORDER_STATUS.CREATED
                  }
                >
                  Delete
                </button>

                <button className="export" onClick={handleDownloadPDF}>
                  Export
                </button>

                {role === ROLES.BACK_OFFICE &&
                  singleOrder?.orderStatus === ORDER_STATUS.CREATED && (
                    <button className="process" onClick={handleProcessOrder}>
                      Process
                    </button>
                  )}
              </div>
            </>
          )
        )}
      </div>
    </div>
  );
};
