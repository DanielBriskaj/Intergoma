import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import { selectLoggedState } from '../../../redux/slices/auth/authSlice';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { ReactComponent as PersonPlus } from '../../../assets/svgIcons/person-plus-fill.svg';
import InfiniteScroll from 'react-infinite-scroller';
import { User } from '../../../interfaces/users';
import { delay } from '../../../helpers/delay';
import notificationThrower from '../../../helpers/notificationThrower';
import Spinner from '../../../components/Spinner';
import { FormProvider, useForm } from 'react-hook-form';
import InputFormItem from '../../../components/InputFormItem';
import { debounce } from 'lodash';
import { useLazyFetchAllUsersQuery } from '../../../redux/slices/users/usersApi';
import UserCard from '../../../components/UserCard';
import {
  openModal,
  selectUserState,
} from '../../../redux/slices/users/usersSlice';
import UserModal from '../../../components/UserModal';

export const MobileUsers: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const loggedUser = useSelector(selectLoggedState);
  const userState = useSelector(selectUserState);
  const { modalOpen } = userState;
  const { userId } = loggedUser;

  const [usersArray, setUsersArray] = useState<User[]>([]);
  const [searchUser, setSearchUser] = useState<string>('');
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [page, setPage] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const [getAllUsers] = useLazyFetchAllUsersQuery();

  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  const query = {
    page: page,
    size: 10,
    username: searchUser ? searchUser : null,
  };

  useEffect(() => {
    setPage(0);
    setHasMore(true);
    setUsersArray([]);

    if (usersArray.length === 0) {
      loadMore(0);
    }
  }, [userId, searchUser]);

  const handleResetUsers = () => {
    setPage(0);
    setUsersArray([]);
    setHasMore(true);
  };

  const loadMore = async (e: number) => {
    if (hasMore) {
      setIsLoading(true);
      userId !== 0 &&
        getAllUsers(query)
          .unwrap()
          .then(async payload => {
            await delay();
            setUsersArray([...usersArray, ...payload?.users]);
            if (payload?.totalPages <= page + 1) {
              setHasMore(false);
            } else {
              setPage(page + 1);
            }
            setIsLoading(false);
          })
          .catch(error => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Get Users',
            });
            setIsLoading(false);
            setHasMore(false);
          });
    }
  };

  const searchUsername = (value: string) => {
    setSearchUser(value);
  };

  const debounceSearchUsername = debounce(searchUsername, 500);

  const handleOpenModal = () => {
    dispatch(openModal({ isOpen: true, userId: null }));
  };

  return (
    <div className="mobile-users-container">
      <div className="users-wrapper">
        <div className="users-header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Users</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home className="home-svg" onClick={() => navigate('/')} />
            </div>
          </div>
        </div>
        <div
          className="users"
          style={{ paddingBottom: isLoading ? '10px' : '65px' }}
        >
          <FormProvider {...formConfig}>
            <div className="search">
              <InputFormItem
                name="searchUsername"
                placeholder="Search Username"
                className="users-search"
                onChange={(e: React.FormEvent<HTMLInputElement>) =>
                  debounceSearchUsername(e.currentTarget.value)
                }
              />
            </div>
          </FormProvider>
          <InfiniteScroll
            initialLoad
            pageStart={0}
            loadMore={e => loadMore(e)}
            hasMore={!isLoading && hasMore}
            style={{ marginTop: '20px' }}
            loader={
              <div className="loader" key={0}>
                <Spinner wrapperStyle={{ height: '50px' }} />
              </div>
            }
          >
            {usersArray?.length !== 0 ? (
              usersArray?.map((user: User, index: number) => {
                return <UserCard key={index} {...user} />;
              })
            ) : !isLoading && usersArray?.length === 0 ? (
              <div className="no-users">No Users</div>
            ) : (
              <></>
            )}
          </InfiniteScroll>
          {isLoading && (
            <Spinner
              wrapperStyle={{
                height: usersArray?.length == 0 ? '70vh' : '50px',
              }}
            />
          )}
        </div>
        <div className="button-container">
          <PersonPlus className="plus-svg" onClick={handleOpenModal} />
        </div>
        {modalOpen && (
          <UserModal query={query} handleResetUsers={handleResetUsers} />
        )}
      </div>
    </div>
  );
};
