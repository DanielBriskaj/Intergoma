import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { ReactComponent as CartAdd } from '../../../assets/svgIcons/cart-plus.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import CartForm from '../../../components/CartForm';
import TireCards from '../../../components/TireCards';
import {
  selectCartItems,
  selectTotalCartPrice,
} from '../../../redux/slices/cart/cartSlice';

export const MobileCart: React.FC = () => {
  const navigate = useNavigate();
  const cartItems = useSelector(selectCartItems);
  const totalCartPrice = useSelector(selectTotalCartPrice);

  return (
    <div className="mobile-cart-container">
      <div className="wrapper">
        <div className="header">
          <div className="title">
            <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
            <span>Cart</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home
                className="home-svg"
                onClick={() => {
                  navigate('/');
                  localStorage.removeItem('searchArticles');
                }}
              />
            </div>
          </div>
        </div>
        <div className="body">
          {cartItems?.length === 0 ? (
            <div className="cart-empty">
              <span>Your cart is empty.</span>
              <span>Once you add something it will appear here!</span>
              <button
                className="btn-primary"
                onClick={() => {
                  navigate('/shopping-search');
                }}
              >
                Start Shopping <CartAdd className="cart-add-svg" />
              </button>
            </div>
          ) : (
            <div className="cart-items">
              {cartItems?.map((item, index) => {
                return <TireCards key={index} {...item} />;
              })}
              <div className="total">
                {' '}
                TOTAL : € {totalCartPrice?.toLocaleString('en-US')}
              </div>
              <div className="cart-footer">
                <CartForm cartItems={cartItems} />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
