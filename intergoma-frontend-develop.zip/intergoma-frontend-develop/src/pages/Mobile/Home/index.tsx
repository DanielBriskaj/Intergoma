export { MobileHomeView as default } from './MobileHome';
