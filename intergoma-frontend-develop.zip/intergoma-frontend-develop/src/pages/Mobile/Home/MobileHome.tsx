import React from 'react';
import { useNavigate } from 'react-router-dom';
import { getUsername, getUserRole } from '../../../helpers/getUserInfo';
import MobileHeader from '../../../layouts/Header';
import { ReactComponent as Avatar } from '../../../assets/svgIcons/person-circle.svg';
import { ReactComponent as ArrowRight } from '../../../assets/svgIcons/chevron-right.svg';
import { ReactComponent as Logo } from '../../../assets/svgIcons/logo.svg';
import renderRoutesOnRole from '../../../helpers/renderRoutesOnRole';
import { useDispatch, useSelector } from 'react-redux';
import { resetCartState } from '../../../redux/slices/cart/cartSlice';
import { resetLoggedState } from '../../../redux/slices/auth/authSlice';
import {
  resetMiscellaneousState,
  selectMessagesNumber,
} from '../../../redux/slices/miscellaneous/miscellaneousSlice';
import { articleApi } from '../../../redux/slices/articles/articlesApi';

export const MobileHomeView: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const userName = getUsername();
  const role = getUserRole();
  const links = renderRoutesOnRole(role, true);
  const messagesNumber = useSelector(selectMessagesNumber);

  const handleLogOut = () => {
    localStorage.clear();
    dispatch(resetCartState());
    dispatch(resetLoggedState());
    dispatch(resetMiscellaneousState());
    dispatch(articleApi.util.resetApiState());
    navigate('/login');
  };

  return (
    <>
      <MobileHeader />
      <div className="mobile-home-container">
        <div className="mobile-home-wrapper">
          <div className="header">
            <div className="user" onClick={() => navigate('/account')}>
              <Avatar className="avatar-svg" /> {userName}
            </div>
            <div className="logout" onClick={handleLogOut}>
              LogOut
            </div>
          </div>
          <div className="image-wrap"></div>

          <div className="mobile-navbar">
            {links?.map((link, index) => {
              return (
                <div
                  key={index}
                  className="route"
                  onClick={() => navigate(link?.link)}
                >
                  <div className="label">
                    <p>{link?.label?.toUpperCase()}</p>
                    {link?.label === 'Messages' ? (
                      <div className="badge">{messagesNumber}</div>
                    ) : (
                      ''
                    )}
                  </div>
                  <ArrowRight className="arrow" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};
