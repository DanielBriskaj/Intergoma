import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { ReactComponent as Cart } from '../../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../../assets/svgIcons/arrow-left.svg';
import { ReactComponent as Car } from '../../../assets/svgIcons/car.svg';
import { ReactComponent as FWD } from '../../../assets/svgIcons/4x4Car.svg';
import { ReactComponent as Van } from '../../../assets/svgIcons/van.svg';
import { ReactComponent as Truck } from '../../../assets/svgIcons/truck.svg';
import { ReactComponent as Sun } from '../../../assets/svgIcons/sun.svg';
import { ReactComponent as Snowflake } from '../../../assets/svgIcons/snowflake.svg';
import { ReactComponent as Logo } from '../../../assets/svgIcons/logo.svg';
import InputFormItem from '../../../components/InputFormItem';
import { FormProvider, useForm } from 'react-hook-form';
import { useSelector } from 'react-redux';
import { selectCartItems } from '../../../redux/slices/cart/cartSlice';
import { Checkbox } from 'antd';
import { CarType, SeasonType } from '../../../interfaces/shopping';
import { ROLES } from '../../../constants/enums/roles';
import { getUserRole } from '../../../helpers/getUserInfo';

export const ShoppingSearch: React.FC = () => {
  const navigate = useNavigate();
  const role = getUserRole();
  const cartItems = useSelector(selectCartItems);
  const searching = localStorage.getItem('searchArticles');
  const searchArticles = JSON.parse(searching!);

  const [carType, setCarType] = useState<CarType>(searchArticles?.carType);
  const [season, setSeason] = useState<SeasonType>(searchArticles?.season);
  const [tireSize, setTireSize] = useState<string>(searchArticles?.tireSize);
  const [brand, setBrand] = useState<string>(searchArticles?.brand);
  const [hasStock, setHasStock] = useState<boolean>(true);

  const handleSearchTire = (e: any) => {
    setTireSize(e.target.value);
  };

  const handleBrandSearch = (e: any) => {
    setBrand(e.target.value);
  };

  const handleSubmitSearch = () => {
    const search = { season, carType, tireSize, brand, hasStock };
    localStorage.setItem('searchArticles', JSON.stringify(search));
    navigate('/shopping');
  };

  const formConfig = useForm({
    reValidateMode: 'onBlur',
    mode: 'onChange',
  });

  const handleSetCarType = (type: CarType) => {
    if (carType === type) {
      setCarType(undefined);
    } else {
      setCarType(type);
    }
  };

  const handleSetSeasonType = (type: SeasonType) => {
    if (season === type) {
      setSeason(undefined);
    } else {
      setSeason(type);
    }
  };
  return (
    <div className="shopping-search-container">
      <div className="shopping-wrapper">
        <div className="shopping-header">
          <div className="title">
            <ArrowLeft
              className="arrow-svg"
              onClick={() => {
                navigate(-1);
                localStorage.removeItem('searchArticles');
              }}
            />
            <span>Shopping</span>
          </div>
          <div className="icon-container">
            <div className="home">
              <Home
                className="home-svg"
                onClick={() => {
                  navigate('/');
                  localStorage.removeItem('searchArticles');
                }}
              />
            </div>
            {role !== ROLES.ADMIN && (
              <div className="cart" onClick={() => navigate('/cart')}>
                <Cart className="cart-svg" />
                <div className="badge">{cartItems.length}</div>
              </div>
            )}
          </div>
        </div>

        <div className="shopping-search">
          <FormProvider {...formConfig}>
            <div className="size">
              <span> Search By Size</span>

              <InputFormItem
                name="size"
                placeholder="2454018"
                className="size-search"
                onChange={handleSearchTire}
              />
            </div>
            <div className="car-type">
              <span>Vehicle Type</span>
              <div className="svg-container">
                <span>
                  <Car
                    className="car-svg"
                    style={{
                      background: carType === 'Veture' ? '#ffd50a' : 'white',
                    }}
                    onClick={() => handleSetCarType('Veture')}
                  />
                  PCR
                </span>
                <span>
                  <FWD
                    className="car-svg"
                    style={{
                      background: carType === '4x4' ? '#ffd50a' : 'white',
                    }}
                    onClick={() => handleSetCarType('4x4')}
                  />
                  4x4
                </span>
                <span>
                  <Van
                    className="car-svg"
                    style={{
                      background: carType === 'Furgon' ? '#ffd50a' : 'white',
                    }}
                    onClick={() => handleSetCarType('Furgon')}
                  />
                  LT
                </span>
                <span>
                  <Truck
                    className="car-svg"
                    style={{
                      background: carType === 'Kamion' ? '#ffd50a' : 'white',
                    }}
                    onClick={() => handleSetCarType('Kamion')}
                  />
                  TRUCK
                </span>
              </div>
            </div>
            <div className="season-type">
              <span>Season</span>
              <div className="svg-container">
                <span>
                  <Sun
                    className="season-svg"
                    style={{
                      background: season === 'Vere' ? '#ffd50a' : 'white',
                    }}
                    onClick={() => handleSetSeasonType('Vere')}
                  />
                </span>
                <span>
                  <Snowflake
                    className="season-svg"
                    style={{
                      background: season === 'Dimer' ? '#ffd50a' : 'white',
                    }}
                    onClick={() => handleSetSeasonType('Dimer')}
                  />
                </span>
                <span
                  className="all-season"
                  style={{
                    background: season === '4Stinet' ? '#ffd50a' : 'white',
                  }}
                  onClick={() => handleSetSeasonType('4Stinet')}
                >
                  ALL SEASON
                </span>
              </div>
            </div>
            <div className="brand-search">
              <span> Brand</span>

              <InputFormItem
                name="brand"
                placeholder="Enter Brand"
                className="size-search"
                onChange={handleBrandSearch}
              />
            </div>

            <div className="available">
              <Checkbox
                defaultChecked={hasStock}
                onChange={e => {
                  setHasStock(e?.target?.checked);
                }}
              >
                Stock Available
              </Checkbox>
            </div>

            <div className="footer">
              <button
                type="button"
                className="btn-secondary"
                onClick={handleSubmitSearch}
              >
                Search
              </button>
            </div>
          </FormProvider>
        </div>
        <div className="logo-container">
          <Logo className="logo" />
        </div>
      </div>
    </div>
  );
};
