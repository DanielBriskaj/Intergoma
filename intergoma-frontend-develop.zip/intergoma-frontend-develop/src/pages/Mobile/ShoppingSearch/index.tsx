export { ShoppingSearch as default } from './ShoppingSearch';
