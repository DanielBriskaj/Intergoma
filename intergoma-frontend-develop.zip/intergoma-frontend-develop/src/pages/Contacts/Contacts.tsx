import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { ReactComponent as Cart } from '../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../assets/svgIcons/arrow-left.svg';
import { useSelector } from 'react-redux';
import { selectCartItems } from '../../redux/slices/cart/cartSlice';
import { FormProvider, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { contactsSchema } from '../../helpers/yupSchemas/contactsSchema';
import InputFormItem from '../../components/InputFormItem';
import TextArea from '../../components/TextArea';
import { ReactComponent as Facebook } from '../../assets/svgIcons/facebook.svg';
import { ReactComponent as Whatsapp } from '../../assets/svgIcons/whatsapp.svg';
import { ReactComponent as Instagram } from '../../assets/svgIcons/instagram.svg';
import { ReactComponent as Logo } from '../../assets/svgIcons/logo.svg';
import notificationThrower from '../../helpers/notificationThrower';

export const Contacts: React.FC = () => {
  const navigate = useNavigate();
  const cartItems = useSelector(selectCartItems);
  const token = localStorage.getItem('idToken');

  const [initialValues] = useState(() => {
    return {
      firstName: null,
      lastName: null,
      companyName: null,
      email: null,
      phone: null,
    };
  });

  const form = useForm({
    reValidateMode: 'onChange',
    resolver: yupResolver(contactsSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  const handleSubmit = (data: any) => {
    console.log(data);
    notificationThrower({
      type: 'success',
      title: 'Message Sent Successfully',
    });
    form.reset();
  };
  return (
    <div className="contacts-container">
      <div className="header">
        <div className="title">
          <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
          <span>Contacts</span>
        </div>
        {token ? (
          <div className="icon-container">
            <div className="home">
              <Home className="home-svg" onClick={() => navigate('/')} />
            </div>
            <div className="cart" onClick={() => navigate('/cart')}>
              <Cart className="cart-svg" />
              <div className="badge">{cartItems.length}</div>
            </div>
          </div>
        ) : (
          ''
        )}
      </div>
      <div className="body">
        <p>
          Reach out to our team by filling the form and we will get back to you
          as soon as possible!
        </p>
        <FormProvider {...form}>
          <form
            className="contacts-form"
            onSubmit={form.handleSubmit(handleSubmit)}
            autoComplete="off"
          >
            <InputFormItem name="firstName" placeholder="First Name" />
            <InputFormItem name="lastName" placeholder="Last Name" />
            <InputFormItem name="email" placeholder="Email" />
            <InputFormItem name="companyName" placeholder="Company Name" />
            <InputFormItem name="phone" placeholder="Phone Number" />
            <TextArea name="message" placeholder="Note / Questions" />
            <div className="form-footer">
              <button type="submit" className="btn-primary">
                Send
              </button>
            </div>
          </form>
        </FormProvider>
        <div className="contact-info">
          <a className="email" href="mailto:info@intergoma.al">
            Email: info@intergoma.al
          </a>
          <a href="tel:+355694333336">Phone: +355 69 43 33 336</a>
          <div className="icons">
            <Facebook className="icon" />
            <a href="https://wa.me/355694333336">
              <Whatsapp className="icon" />
            </a>
            <Instagram className="icon" />
          </div>
        </div>
        <div className="footer">
          <Logo className="logo" />
        </div>
      </div>
    </div>
  );
};
