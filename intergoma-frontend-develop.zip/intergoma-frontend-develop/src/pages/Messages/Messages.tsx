import React, { useRef, useState } from 'react';
import { useLazyFetchAllMessagesQuery } from '../../redux/slices/messages/messagesApi';
import { Tabs } from 'antd';
import MessageCard from '../../components/MessageCard';
import { ReactComponent as Plus } from '../../assets/svgIcons/plus-circle-fill.svg';
import OpenMessage from '../../components/OpenMessage';
import Logo from '../../assets/images/logo.png';
import InfiniteScroll from 'react-infinite-scroller';
import { Message, MessageQuery } from '../../interfaces/message';
import NewMessage from '../../components/NewMessage';
import Spinner from '../../components/Spinner';
import { useDispatch, useSelector } from 'react-redux';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';
import {
  changeMessageTabs,
  selectMessagesTabs,
} from '../../redux/slices/miscellaneous/miscellaneousSlice';

export const Messages: React.FC = () => {
  const dispatch = useDispatch();
  const user = useSelector(selectLoggedState);
  const { userId } = user;
  const { TabPane } = Tabs;
  const currentTab = useSelector(selectMessagesTabs);
  const [openMsg, setOpenMsg] = useState<number | null>(null);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [messageArray, setMessageArray] = useState<Message[]>([]);
  const [createMessage, setCreateMessage] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const inboxRef = useRef(null);
  const outboxRef = useRef(null);

  const query: MessageQuery = {};
  query.page = currentPage;
  currentTab === 'inbox'
    ? (query.idReceiver = Number(userId))
    : (query.idSender = Number(userId));

  const [getAll] = useLazyFetchAllMessagesQuery();

  const handleMessageClick = (id: number) => {
    setOpenMsg(id);
  };

  const onTabChange = (key: string) => {
    dispatch(changeMessageTabs(key));
    setOpenMsg(null);
    setMessageArray([]);
    setCurrentPage(0);
    setHasMore(true);
  };

  const resetMessage = () => {
    setCurrentPage(0);
    setMessageArray([]);
    setHasMore(true);
  };

  const loadMore = async (e: number) => {
    if (hasMore) {
      setLoading(true);
      const response: any = await getAll(query);

      if (response?.data) {
        setMessageArray([...messageArray, ...response?.data?.messages]);
        if (response?.data?.totalPages <= currentPage + 1) {
          setHasMore(false);
        } else {
          setCurrentPage(currentPage + 1);
        }
        setLoading(false);
      } else if (response?.data?.totalPages == 0) {
        setHasMore(false);
        setLoading(false);
      } else {
        setLoading(false);
      }
    }
  };

  return (
    <div className="messages-container">
      {userId ? (
        <>
          <div className="messages-wrapper">
            <Tabs defaultActiveKey="inbox" onChange={onTabChange}>
              <TabPane tab="Inbox" key="inbox">
                <div className="card-container">
                  <div className="cards" ref={inboxRef}>
                    <InfiniteScroll
                      initialLoad
                      pageStart={0}
                      loadMore={e => loadMore(e)}
                      hasMore={!loading && hasMore}
                      loader={
                        <div className="loader" key={0}>
                          <Spinner />
                        </div>
                      }
                      getScrollParent={() => inboxRef.current}
                      useWindow={false}
                    >
                      {!loading && messageArray?.length == 0 ? (
                        <div className="no-msg">No Messages</div>
                      ) : (
                        messageArray?.map((message, index) => {
                          return (
                            <MessageCard
                              {...message}
                              key={index}
                              handleMessageClick={handleMessageClick}
                              openMsg={openMsg}
                            />
                          );
                        })
                      )}
                    </InfiniteScroll>
                  </div>
                  <div className="open-msg">
                    {openMsg ? (
                      <OpenMessage
                        openMsg={openMsg}
                        setOpenMsg={setOpenMsg}
                        query={query}
                        setMessagesArray={setMessageArray}
                        messagesArray={messageArray}
                      />
                    ) : (
                      <div className="no-open-msg">
                        Click on a message to open it
                        <img src={Logo} alt="logo" />
                      </div>
                    )}
                  </div>
                </div>
              </TabPane>
              <TabPane tab="Outbox" key="outbox">
                <div className="card-container">
                  <div className="cards" ref={outboxRef}>
                    <InfiniteScroll
                      initialLoad
                      pageStart={0}
                      loadMore={e => loadMore(e)}
                      hasMore={!loading && hasMore}
                      loader={
                        <div className="loader" key={0}>
                          <Spinner />
                        </div>
                      }
                      getScrollParent={() => outboxRef.current}
                      useWindow={false}
                    >
                      <div>
                        {!loading && messageArray?.length == 0 ? (
                          <div className="no-msg">No Messages</div>
                        ) : (
                          messageArray?.map((message, index) => {
                            return (
                              <MessageCard
                                {...message}
                                key={index}
                                handleMessageClick={handleMessageClick}
                                openMsg={openMsg}
                              />
                            );
                          })
                        )}
                      </div>
                    </InfiniteScroll>
                  </div>
                  <div className="open-msg">
                    {openMsg ? (
                      <OpenMessage
                        openMsg={openMsg}
                        setOpenMsg={setOpenMsg}
                        query={query}
                        setMessagesArray={setMessageArray}
                        messagesArray={messageArray}
                      />
                    ) : (
                      <div className="no-open-msg">
                        Click on a message to open it
                        <img src={Logo} alt="logo" />
                      </div>
                    )}
                  </div>
                </div>
              </TabPane>
            </Tabs>
            <div className="button-container">
              <Plus
                className="plus-svg"
                onClick={() => setCreateMessage(true)}
              />
            </div>
          </div>
          <NewMessage
            createMessage={createMessage}
            setCreateMessage={setCreateMessage}
            resetMessage={resetMessage}
          />
        </>
      ) : (
        <Spinner />
      )}
    </div>
  );
};
