import { yupResolver } from '@hookform/resolvers/yup';
import React, { useEffect, useState } from 'react';
import { useForm, FormProvider } from 'react-hook-form';
import { useSelector } from 'react-redux';
import InputFormItem from '../../components/InputFormItem';
import Spinner from '../../components/Spinner';
import notificationThrower from '../../helpers/notificationThrower';
import { userSchema } from '../../helpers/yupSchemas/signUpSchema';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';
import { useLazyFetchSingleUserQuery } from '../../redux/slices/users/usersApi';
import { ReactComponent as ArrowBack } from '../../assets/svgIcons/arrow-left.svg';
import { useNavigate } from 'react-router';

export const MyProfile: React.FC = () => {
  const navigate = useNavigate();
  const loggedUser = useSelector(selectLoggedState);
  const { userId } = loggedUser;
  const [getSingleUser] = useLazyFetchSingleUserQuery();
  const [initialValues, setInitialValues] = useState<any>(null);

  const form = useForm({
    reValidateMode: 'onSubmit',
    resolver: yupResolver(userSchema),
    mode: 'onSubmit',
    defaultValues: initialValues,
  });

  useEffect(() => {
    if (userId) {
      getSingleUser({ id: Number(userId) })
        .unwrap()
        .then(user => setInitialValues(user))
        .catch(error =>
          notificationThrower({
            type: 'error',
            title: 'Something Went Wrong',
          }),
        );
    }
  }, [userId]);

  return (
    <div className="my-profile-container">
      <div className="wrapper">
        <div className="header">
          <ArrowBack className="back-svg" onClick={() => navigate(-1)} />
          <span>My Profile</span>
        </div>
        {initialValues ? (
          <div className="info">
            <FormProvider {...form}>
              <form className="user-form" autoComplete="off">
                <InputFormItem
                  name="firstName"
                  label="Firstname"
                  placeholder="Firstname"
                  disabled={true}
                  defaultValue={initialValues?.firstName}
                />
                <InputFormItem
                  name="lastName"
                  label="Lastname"
                  placeholder="Lastname"
                  disabled={true}
                  defaultValue={initialValues?.lastName}
                />
                <InputFormItem
                  name="email"
                  label="Email"
                  placeholder="Email"
                  disabled={true}
                  defaultValue={initialValues?.email}
                />
                <InputFormItem
                  name="username"
                  label="Username"
                  placeholder="Username"
                  disabled={true}
                  defaultValue={initialValues?.username}
                />
              </form>
            </FormProvider>
          </div>
        ) : (
          <Spinner wrapperStyle={{ height: '75vh', width: '80vw' }} />
        )}
      </div>
    </div>
  );
};
