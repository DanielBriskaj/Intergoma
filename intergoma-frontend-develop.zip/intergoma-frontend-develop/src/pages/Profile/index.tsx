export { MyProfile as default } from './MyProfile';
