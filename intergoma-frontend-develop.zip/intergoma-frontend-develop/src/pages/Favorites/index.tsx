export { Favorites as default } from './Favorites';
