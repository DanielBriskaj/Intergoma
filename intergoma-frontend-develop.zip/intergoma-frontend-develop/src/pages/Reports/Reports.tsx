import React, { useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useNavigate } from 'react-router';
import SingleSelect from '../../components/SingleSelect';
import { OrderArticleReport } from './orderArticleReports';
import { ReactComponent as Cart } from '../../assets/svgIcons/cart.svg';
import { ReactComponent as Home } from '../../assets/svgIcons/house-fill.svg';
import { ReactComponent as ArrowLeft } from '../../assets/svgIcons/arrow-left.svg';
import { ROLES } from '../../constants/enums/roles';
import { useSelector } from 'react-redux';
import { selectCartItems } from '../../redux/slices/cart/cartSlice';
import { getUserRole } from '../../helpers/getUserInfo';
import Logo from '../../assets/images/logo.png';
import { OrderAgentReport } from './orderAgentReport';
import { OrderResellerReport } from './orderResellerReport';

const reportOptions = [
  { value: 'OrderArticleReport', label: 'Order Article Report' },
  { value: 'OrderAgentReport', label: 'Order Agent Report' },
  { value: 'OrderResellerReport', label: 'Order Reseller Report' },
];
export const Reports: React.FC = () => {
  const navigate = useNavigate();
  const [selectedReport, setSelectedReport] = useState<string>();
  const cartItems = useSelector(selectCartItems);
  const role = getUserRole();
  const form = useForm();

  const displaySelectedReport = () => {
    switch (selectedReport) {
      case 'OrderArticleReport':
        return <OrderArticleReport />;
      case 'OrderAgentReport':
        return <OrderAgentReport />;
      case 'OrderResellerReport':
        return <OrderResellerReport />;
      default:
        break;
    }
  };

  return (
    <div className="reports-container">
      <div className="reports-header">
        <div className="title">
          <ArrowLeft className="arrow-svg" onClick={() => navigate(-1)} />
          <span>Reports</span>
        </div>
        <div className="icon-container">
          <div className="home">
            <Home className="home-svg" onClick={() => navigate('/')} />
          </div>
          {role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN && (
            <div className="cart" onClick={() => navigate('/cart')}>
              <Cart className="cart-svg" />
              <div className="badge">{cartItems.length}</div>
            </div>
          )}
        </div>
      </div>

      <FormProvider {...form}>
        <form className="report-form">
          <div className="report-selector">
            <SingleSelect
              placeholder="Select Report"
              name="report"
              options={reportOptions}
              onChange={(e: any) => setSelectedReport(e?.value)}
              isSearchable={false}
            />
          </div>
        </form>
      </FormProvider>
      {!selectedReport ? (
        <div className="no-open-reports">
          Select A Report To Continue
          <img src={Logo} alt="logo" />
        </div>
      ) : (
        displaySelectedReport()
      )}
    </div>
  );
};
