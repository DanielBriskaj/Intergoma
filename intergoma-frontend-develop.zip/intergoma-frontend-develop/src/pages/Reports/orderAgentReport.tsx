import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import InputFormItem from '../../components/InputFormItem';
import {
  downloadOrderAgentReport,
  selectLoadingOrder,
} from '../../redux/slices/order/orderSlice';
import { format, parseISO } from 'date-fns';
import { debounce } from 'lodash';
import { ReactComponent as Excel } from '../../assets/svgIcons/file-excel.svg';
import { Table } from 'antd';
import { orderAgentReportColumns } from './tableColumns';
import { useLazyOrderAgentReportItemsQuery } from '../../redux/slices/order/orderApi';
import { OrderAgentReportItemsReturn } from '../../interfaces/order';
import notificationThrower from '../../helpers/notificationThrower';

export const OrderAgentReport: React.FC = () => {
  const dispatch = useDispatch();
  const date = new Date();
  const today = format(date, 'yyyy-MM-dd');
  const weekBefore = format(
    new Date(date.getFullYear(), date.getMonth(), date.getDate() - 7),
    'yyyy-MM-dd',
  );
  const { innerWidth: width } = window;
  const downloadLoading = useSelector(selectLoadingOrder);

  const [startDate, setStartDate] = useState<string>(weekBefore);
  const [endDate, setEndDate] = useState<string>(today);
  const [tableData, setTableData] = useState<OrderAgentReportItemsReturn[]>([]);

  const query = {
    startDate: startDate && format(parseISO(startDate), 'dd-MM-yyyy'),
    endDate: startDate && format(parseISO(endDate), 'dd-MM-yyyy'),
    detailed: false,
  };

  const [getAgentReportItems, { isFetching }] =
    useLazyOrderAgentReportItemsQuery();

  useEffect(() => {
    width > 840 &&
      getAgentReportItems(query)
        .unwrap()
        .then(payload => {
          setTableData(
            payload?.map(item => {
              return {
                key: item?.userId,
                userId: item?.userId,
                username: item?.username,
                total: item?.total,
                quantity: item?.quantity,
              };
            }),
          );
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Report Items',
          });
        });
  }, [startDate, endDate]);

  const form = useForm();

  const handleDownload = () => {
    dispatch(downloadOrderAgentReport(query));
  };

  const handleDetailedDownload = () => {
    const detailedQuery = {
      ...query,
      detailed: true,
    };
    dispatch(downloadOrderAgentReport(detailedQuery));
  };

  const handleSearchByStartDate = (e: React.ChangeEvent<HTMLInputElement>) => {
    setStartDate(e?.target?.value);
  };
  const debounceSearchByStartDate = debounce(handleSearchByStartDate, 500);

  const handleSearchByEndDate = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEndDate(e?.target?.value);
  };
  const debounceSearchByEndDate = debounce(handleSearchByEndDate, 500);

  return (
    <>
      <div className="order-agent-reports-container">
        <FormProvider {...form}>
          <form className="filters">
            <div className="two-items">
              <div className="item">
                <InputFormItem
                  name="startDate"
                  placeholder="Start Date"
                  type="date"
                  label="Start Date"
                  defaultValue={weekBefore}
                  onChange={debounceSearchByStartDate}
                  max={today}
                />
              </div>
              <div className="item">
                <InputFormItem
                  name="endDate"
                  placeholder="End Date"
                  type="date"
                  label="End Date"
                  defaultValue={today}
                  onChange={debounceSearchByEndDate}
                  max={today}
                />
              </div>
            </div>
            <div className="button-container">
              <button
                type="button"
                className={`${width > 840 ? 'btn-primary' : 'btn-secondary'}`}
                onClick={handleDownload}
                disabled={isFetching || downloadLoading}
              >
                Export{' '}
                <Excel
                  className="excel-svg"
                  fill={`${width > 840 ? 'white' : 'black'}`}
                />
              </button>
              <button
                type="button"
                className={`${width > 840 ? 'btn-secondary' : 'btn-primary'}`}
                onClick={handleDetailedDownload}
                disabled={isFetching || downloadLoading}
              >
                Detailed
                <Excel
                  className="excel-svg"
                  fill={`${width > 840 ? 'black' : 'white'}`}
                />
              </button>
            </div>
          </form>
        </FormProvider>
        {width > 840 && (
          <Table
            className="reports-table"
            dataSource={tableData}
            columns={orderAgentReportColumns}
            loading={isFetching || downloadLoading}
          />
        )}
      </div>
    </>
  );
};
