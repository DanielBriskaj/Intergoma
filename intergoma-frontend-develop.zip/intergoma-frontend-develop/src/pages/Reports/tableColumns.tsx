import { Tooltip } from 'antd';
import React from 'react';

export const orderArticleReportColumns = [
  {
    title: 'AGENT',
    dataIndex: 'agent',
    key: 'agent',
    ellipsis: {
      showTitle: false,
    },
    render: (agent: string) => (
      <Tooltip placement="topLeft" title={agent}>
        {agent}
      </Tooltip>
    ),
  },
  {
    title: 'CLIENT CODE',
    dataIndex: 'clientCode',
    key: 'clientCode',
    ellipsis: {
      showTitle: false,
    },
    render: (clientCode: string) => (
      <Tooltip placement="topLeft" title={clientCode}>
        {clientCode}
      </Tooltip>
    ),
  },
  {
    title: 'CLIENT NAME',
    dataIndex: 'clientName',
    key: 'clientName',
    ellipsis: {
      showTitle: false,
    },
    render: (clientName: string) => (
      <Tooltip placement="topLeft" title={clientName}>
        {clientName}
      </Tooltip>
    ),
  },
  {
    title: 'ARTICLE CODE',
    dataIndex: 'articleCode',
    key: 'articleCode',
    ellipsis: {
      showTitle: false,
    },
    render: (articleCode: string) => (
      <Tooltip placement="topLeft" title={articleCode}>
        {articleCode}
      </Tooltip>
    ),
  },
  {
    title: 'ARTICLE NAME',
    dataIndex: 'articleName',
    key: 'articleName',
    ellipsis: {
      showTitle: false,
    },
    render: (articleName: string) => (
      <Tooltip placement="topLeft" title={articleName}>
        {articleName}
      </Tooltip>
    ),
  },

  {
    title: 'RADIAL',
    dataIndex: 'radial',
    key: 'radial',
    ellipsis: {
      showTitle: false,
    },
    render: (radial: string) => (
      <Tooltip placement="topLeft" title={radial}>
        {radial}
      </Tooltip>
    ),
  },

  {
    title: 'SIZE',
    dataIndex: 'size',
    key: 'size',
    ellipsis: {
      showTitle: false,
    },
    render: (size: string) => (
      <Tooltip placement="topLeft" title={size}>
        {size}
      </Tooltip>
    ),
  },

  {
    title: 'ORDER DATE',
    dataIndex: 'orderDate',
    key: 'orderDate',
    ellipsis: {
      showTitle: false,
    },
    render: (orderDate: string) => (
      <Tooltip placement="topLeft" title={orderDate}>
        {orderDate}
      </Tooltip>
    ),
  },
  {
    title: 'QUANTITY',
    dataIndex: 'quantity',
    key: 'quantity',
    align: 'right' as const,
    ellipsis: {
      showTitle: false,
    },
    render: (quantity: number) => (
      <Tooltip placement="topLeft" title={quantity}>
        {quantity}
      </Tooltip>
    ),
  },
  {
    title: 'PRICE',
    dataIndex: 'price',
    key: 'price',
    align: 'right' as const,
    ellipsis: {
      showTitle: false,
    },
    render: (price: number) => (
      <Tooltip placement="topLeft" title={price}>
        € {price?.toLocaleString('en-US')}
      </Tooltip>
    ),
  },
  {
    title: 'TOTAL',
    dataIndex: 'amount',
    key: 'amount',
    align: 'right' as const,
    ellipsis: {
      showTitle: false,
    },
    render: (amount: number) => (
      <Tooltip placement="topLeft" title={amount}>
        € {amount?.toLocaleString('en-US')}
      </Tooltip>
    ),
  },
];

export const orderAgentReportColumns = [
  {
    title: 'AGENT',
    dataIndex: 'username',
    key: 'username',
    ellipsis: {
      showTitle: false,
    },
    align: 'center' as const,
    render: (username: string) => (
      <Tooltip placement="topLeft" title={username}>
        {username}
      </Tooltip>
    ),
  },
  {
    title: 'QUANTITY',
    dataIndex: 'quantity',
    key: 'quantity',
    ellipsis: {
      showTitle: false,
    },
    align: 'right' as const,
    render: (quantity: string) => (
      <Tooltip placement="topLeft" title={quantity}>
        {quantity}
      </Tooltip>
    ),
  },
  {
    title: 'AMOUNT',
    dataIndex: 'total',
    key: 'total',
    ellipsis: {
      showTitle: false,
    },
    align: 'right' as const,
    render: (total: number) => (
      <Tooltip placement="topLeft" title={total}>
        € {total?.toLocaleString('en-US')}
      </Tooltip>
    ),
  },
];

export const orderResellerReportColumns = [
  {
    title: 'RESELLER',
    dataIndex: 'username',
    key: 'username',
    ellipsis: {
      showTitle: false,
    },
    align: 'center' as const,
    render: (username: string) => (
      <Tooltip placement="topLeft" title={username}>
        {username}
      </Tooltip>
    ),
  },
  {
    title: 'QUANTITY',
    dataIndex: 'quantity',
    key: 'quantity',
    ellipsis: {
      showTitle: false,
    },
    align: 'right' as const,
    render: (quantity: string) => (
      <Tooltip placement="topLeft" title={quantity}>
        {quantity}
      </Tooltip>
    ),
  },
  {
    title: 'AMOUNT',
    dataIndex: 'total',
    key: 'total',
    ellipsis: {
      showTitle: false,
    },
    align: 'right' as const,
    render: (total: number) => (
      <Tooltip placement="topLeft" title={total}>
        € {total?.toLocaleString('en-US')}
      </Tooltip>
    ),
  },
];
