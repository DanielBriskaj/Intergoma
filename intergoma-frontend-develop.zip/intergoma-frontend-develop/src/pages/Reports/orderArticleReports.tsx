import { Table } from 'antd';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import InputFormItem from '../../components/InputFormItem';
import SingleSelect from '../../components/SingleSelect';
import notificationThrower from '../../helpers/notificationThrower';
import { clientNameOptions } from '../../helpers/order/clientDataTransformer';
import { useLazyFetchAllClientsQuery } from '../../redux/slices/clients/clientsApi';
import { downloadOrderArticleReport } from '../../redux/slices/order/orderSlice';
import { orderArticleReportColumns } from './tableColumns';
import { format, parseISO } from 'date-fns';
import { useLazyOrderArticleReportItemsQuery } from '../../redux/slices/order/orderApi';
import { OrderArticleReportItem } from '../../interfaces/order';
import { debounce } from 'lodash';
import articleReportItemTransformer from '../../helpers/dataTransformers/orderArticleReportItem';
import { ReactComponent as Excel } from '../../assets/svgIcons/file-excel.svg';
export interface ClientOptions {
  label: string;
  value: string;
}

export const OrderArticleReport: React.FC = () => {
  const dispatch = useDispatch();
  const date = new Date();
  const today = format(date, 'yyyy-MM-dd');
  const weekBefore = format(
    new Date(date.getFullYear(), date.getMonth(), date.getDate() - 7),
    'yyyy-MM-dd',
  );
  const { innerWidth: width } = window;

  const [tableData, setTableData] = useState<OrderArticleReportItem[]>([]);
  const [clientOptions, setClientOptions] = useState<ClientOptions[]>([]);
  const [clientName, setClientName] = useState<string>();
  const [articleName, setArticleName] = useState<string>();
  const [radial, setRadial] = useState<string>();
  const [tireSize, setTireSize] = useState<string>();
  const [startDate, setStartDate] = useState<string>(weekBefore);
  const [endDate, setEndDate] = useState<string>(today);
  const [page, setPage] = useState<number>(0);
  const [size, setSize] = useState<number>(10);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [username, setUsername] = useState<string>('');

  const query = {
    page,
    size,
    articleName,
    clientName,
    startDate: startDate && format(parseISO(startDate), 'dd-MM-yyyy'),
    endDate: startDate && format(parseISO(endDate), 'dd-MM-yyyy'),
    radial,
    articleSize: tireSize,
    username,
  };

  const form = useForm();

  const [getAllClients, { isFetching: loadingClients }] =
    useLazyFetchAllClientsQuery();
  const [getOrderArticleReportItems, { isFetching }] =
    useLazyOrderArticleReportItemsQuery();

  useEffect(() => {
    getAllClients(0, true)
      .unwrap()
      .then(payload => {
        setClientOptions(clientNameOptions(payload));
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Get Client Data',
        });
      });
  }, []);

  useEffect(() => {
    width > 840 && handleSearch();
  }, [
    page,
    size,
    articleName,
    clientName,
    startDate,
    endDate,
    radial,
    tireSize,
    username,
  ]);

  const handleSearch = () => {
    getOrderArticleReportItems(query)
      .unwrap()
      .then(payload => {
        setTableData(articleReportItemTransformer(payload?.orderArticles));
        setTotalItems(payload?.totalItems);
      })
      .catch(() => {
        notificationThrower({
          type: 'error',
          title: 'Failed To Get Article Data',
        });
      });
  };

  const handleDownload = () => {
    dispatch(downloadOrderArticleReport(query));
  };

  const handlePageChange = (page: number, pageSize: number) => {
    setPage(page - 1);
    setSize(pageSize);
  };

  const handleShowSizeChange = (size: number) => {
    setSize(size);
  };

  const handleSearchArticleName = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(0);
    setArticleName(e?.target?.value);
  };
  const debounceSearchArticleName = debounce(handleSearchArticleName, 500);

  const handleSearchByStartDate = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(0);
    setStartDate(e?.target?.value);
  };
  const debounceSearchByStartDate = debounce(handleSearchByStartDate, 500);

  const handleSearchByEndDate = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(0);
    setEndDate(e?.target?.value);
  };
  const debounceSearchByEndDate = debounce(handleSearchByEndDate, 500);

  const handleSearchRadial = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(0);
    setRadial(e?.target?.value);
  };
  const debounceSearchRadial = debounce(handleSearchRadial, 500);

  const handleSearchTireSize = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(0);
    setTireSize(e?.target?.value);
  };
  const debounceSearchTireSize = debounce(handleSearchTireSize, 500);

  const handleSearchAgent = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPage(0);
    setUsername(e?.target?.value);
  };
  const debounceSearchAgent = debounce(handleSearchAgent, 500);

  return (
    <>
      <div className="order-article-reports-container">
        <FormProvider {...form}>
          <form className="filters">
            <div className="select">
              <label>Client</label>
              <SingleSelect
                placeholder="Select Client"
                name="clientName"
                options={clientOptions}
                isLoading={loadingClients}
                isClearable={true}
                onChange={(option: ClientOptions) => {
                  setPage(0);
                  setClientName(option?.value);
                }}
              />
            </div>
            <div className="item">
              <InputFormItem
                name="username"
                placeholder="Agent"
                label="Agent"
                onChange={debounceSearchAgent}
              />
            </div>
            <div className="item">
              <InputFormItem
                name="articleName"
                placeholder="Article"
                label="Article Name"
                onChange={debounceSearchArticleName}
              />
            </div>
            <div className="item">
              <InputFormItem
                name="startDate"
                placeholder="Start Date"
                type="date"
                label="Start Date"
                defaultValue={weekBefore}
                onChange={debounceSearchByStartDate}
                max={today}
              />
            </div>
            <div className="item">
              <InputFormItem
                name="endDate"
                placeholder="End Date"
                type="date"
                label="End Date"
                defaultValue={today}
                onChange={debounceSearchByEndDate}
                max={today}
              />
            </div>
            <div className="item">
              <InputFormItem
                name="radial"
                placeholder="Radial"
                label="Radial"
                onChange={debounceSearchRadial}
              />
            </div>
            <div className="item">
              <InputFormItem
                name="size"
                placeholder="Size"
                label="Size"
                onChange={debounceSearchTireSize}
              />
            </div>
            <div className="button-container">
              <button
                type="button"
                className={`${width > 840 ? 'btn-primary' : 'btn-secondary'}`}
                onClick={handleDownload}
                disabled={isFetching}
              >
                Export
                <Excel
                  className="excel-svg"
                  fill={`${width > 840 ? 'white' : 'black'}`}
                />
              </button>
            </div>
          </form>
        </FormProvider>
        {width > 840 && (
          <Table
            className="reports-table"
            dataSource={tableData}
            loading={isFetching}
            columns={orderArticleReportColumns}
            pagination={{
              total: totalItems,
              onChange: handlePageChange,
              onShowSizeChange: handleShowSizeChange,
              showSizeChanger: true,
              current: page + 1,
            }}
          />
        )}
      </div>
    </>
  );
};
