import React, { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';

export const Home: React.FC = () => {
  const role = getUserRole();
  const navigate = useNavigate();

  useEffect(() => {
    if (role !== ROLES.BACK_OFFICE) {
      navigate('/shopping');
    } else {
      navigate('/orders');
    }
  }, []);

  return <div></div>;
};
