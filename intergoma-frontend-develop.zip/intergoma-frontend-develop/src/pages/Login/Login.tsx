import React, { useState } from 'react';
import Form from '../../components/Form';
import InputFormItem from '../../components/InputFormItem';
import { ReactComponent as Eye } from '../../assets/svgIcons/eye.svg';
import { ReactComponent as EyeSlash } from '../../assets/svgIcons/eye-slash.svg';
import { useNavigate } from 'react-router';
import MobileHeader from '../../layouts/Header';
import {
  useLazyLoggedUserQuery,
  useLoginMutation,
} from '../../redux/slices/auth/authApi';
import { loginSchema } from '../../helpers/yupSchemas/loginSchema';
import jwt_decode from 'jwt-decode';
import { ROLES } from '../../constants/enums/roles';
import { useDispatch } from 'react-redux';
import { setLoggedUser } from '../../redux/slices/auth/authSlice';
import notificationThrower from '../../helpers/notificationThrower';
import { useLazyGetMessageNumberQuery } from '../../redux/slices/messages/messagesApi';
import { updateMessageNumber } from '../../redux/slices/miscellaneous/miscellaneousSlice';
import { NavLink } from 'react-router-dom';
import Spinner from '../../components/Spinner';

export const Login: React.FunctionComponent = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { innerWidth: width, innerHeight: height } = window;
  const [viewPass, setViewPass] = useState<boolean>(false);
  const [requestFailed, setRequestFailed] = useState<boolean>(false);

  const initialValues = {
    username: null,
    password: null,
  };

  const [login, { isLoading, error }] = useLoginMutation<any>();
  const [getLoggedUser] = useLazyLoggedUserQuery();
  const [getMsgNumber] = useLazyGetMessageNumberQuery();

  const handleLogin = async (data: any) => {
    setRequestFailed(false);

    login({ userData: data })
      .unwrap()
      .then((payload: any) => {
        const token = payload?.jwt;
        const decoded: any = token && jwt_decode(token);
        const role = decoded?.role[0];
        localStorage.setItem('idToken', token);
        getLoggedUser()
          .unwrap()
          .then(payload => {
            dispatch(setLoggedUser(payload));
            role !== ROLES.ADMIN &&
              role !== ROLES.RESELLER &&
              getMsgNumber({ receiverId: payload?.id, isRead: false })
                .unwrap()
                .then(payload => dispatch(updateMessageNumber(payload?.number)))
                .catch(() => {
                  notificationThrower({
                    type: 'error',
                    title: 'Failed To Get Messages Count',
                  });
                });
            if (width > 840) {
              if (role === ROLES.BACK_OFFICE) {
                navigate('/orders');
              } else {
                navigate('/shopping');
              }
            } else {
              navigate('/');
            }
          })
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Something Went Wrong',
            });
          });
      })
      .catch(() => {
        setRequestFailed(true);
        notificationThrower({
          type: 'error',
          title: 'Failed To Login',
        });
      });
  };

  return (
    <div>
      {width < 840 && <MobileHeader />}
      {isLoading && !requestFailed && <Spinner fullScreen={true} />}
      <div className="login-container">
        <div className="login-wrapper">
          <div className="title">
            <h2>Login</h2>
          </div>
          <Form
            onHandleSuccess={handleLogin}
            schema={loginSchema}
            initialValues={initialValues}
          >
            <div className="section">
              <InputFormItem name="username" placeholder="Username" />
              <div className="password-container">
                <InputFormItem
                  name="password"
                  placeholder="Password"
                  type={viewPass ? 'text' : 'password'}
                />
                {viewPass ? (
                  <EyeSlash
                    className="eye-svg"
                    onClick={() => setViewPass(!viewPass)}
                  />
                ) : (
                  <Eye
                    className="eye-svg"
                    onClick={() => setViewPass(!viewPass)}
                  />
                )}
              </div>
              {error && error?.status === 404 && (
                <div className="login-error">
                  Username or Password Incorrect
                </div>
              )}
              <button
                className="btn-primary"
                disabled={isLoading && !requestFailed}
              >
                Login
              </button>
            </div>
          </Form>
          <div className="contact">
            Questions?
            <NavLink to={'/contacts'}>Contact Us</NavLink>
          </div>
        </div>
      </div>
    </div>
  );
};
