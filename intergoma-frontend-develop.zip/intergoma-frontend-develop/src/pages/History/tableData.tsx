import { Modal, Tooltip } from 'antd';
import React from 'react';
import OrderButton from '../../components/HistoryViewButton';
import { EditOrder } from '../../components/HistoryViewButton/EditOrderBtn';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';
import { ReactComponent as Delete } from '../../assets/svgIcons/trash-fill.svg';
import { getColumnSearchProps } from '../../helpers/tableSearch';
import getOrderStatusLabel, {
  OrderType,
} from '../../helpers/order/orderStatusLabel';
import { HistoryData } from '../../interfaces/order';
import { ORDER_STATUS } from '../../constants/enums/orders';
import {
  useDeleteOrderMutation,
  useLazyFetchAllOrdersQuery,
} from '../../redux/slices/order/orderApi';
import notificationThrower from '../../helpers/notificationThrower';

export function HistoryTableData(query: any) {
  const role = getUserRole();
  const { confirm } = Modal;
  const [deleteOrder] = useDeleteOrderMutation();
  const [getAllOrders] = useLazyFetchAllOrdersQuery();

  const handleDeleteOrder = (id: number) => {
    deleteOrder(id)
      .unwrap()
      .then(() => {
        notificationThrower({
          type: 'success',
          title: 'Order Deleted Successfully',
        });
        getAllOrders(query)
          .unwrap()
          .catch(() => {
            notificationThrower({
              type: 'error',
              title: 'Failed To Get Updated Order List',
            });
          });
      });
  };
  const showConfirm = (id: number) => {
    confirm({
      title: `Are you sure you want to delete Order ${id}?`,
      centered: true,
      maskClosable: true,
      onOk() {
        handleDeleteOrder(id);
      },
      okText: 'Yes',
      cancelText: 'No',
    });
  };

  const columns = [
    {
      title: 'SERIAL NUMBER',
      dataIndex: 'serial',
      key: 'serial',
      sorter: true,
      ellipsis: {
        showTitle: false,
      },
      render: (serial: string) => (
        <Tooltip placement="topLeft" title={serial}>
          {serial}
        </Tooltip>
      ),
    },
    {
      title: 'CLIENT CODE',
      dataIndex: 'client',
      key: 'client',
      ellipsis: {
        showTitle: false,
      },
      render: (client: string) => (
        <Tooltip placement="topLeft" title={client}>
          {client}
        </Tooltip>
      ),
    },
    {
      title: 'CLIENT NAME',
      dataIndex: 'clientName',
      key: 'clientName',
      ellipsis: {
        showTitle: false,
      },
      render: (clientName: string) => (
        <Tooltip placement="topLeft" title={clientName}>
          {clientName}
        </Tooltip>
      ),
    },
    {
      title: 'DATE',
      dataIndex: 'date',
      key: 'date',
      ellipsis: {
        showTitle: false,
      },
      render: (date: string) => (
        <Tooltip placement="topLeft" title={date}>
          {date}
        </Tooltip>
      ),
    },

    {
      title: 'AGENT',
      dataIndex: 'agent',
      key: 'agent',
      ellipsis: {
        showTitle: false,
      },
      render: (agent: string) => (
        <Tooltip placement="topLeft" title={agent}>
          {agent}
        </Tooltip>
      ),
    },
    {
      title: 'WAREHOUSE',
      dataIndex: 'magazine',
      key: 'magazine',
      ellipsis: {
        showTitle: false,
      },
      render: (magazine: string) => (
        <Tooltip placement="topLeft" title={magazine}>
          {magazine}
        </Tooltip>
      ),
    },
    {
      title: 'ITEMS',
      dataIndex: 'items',
      key: 'items',
      align: 'right' as const,
      ellipsis: {
        showTitle: false,
      },
      render: (items: string) => (
        <Tooltip placement="topLeft" title={items}>
          {items}
        </Tooltip>
      ),
    },
    {
      title: 'TOTAL',
      dataIndex: 'total',
      key: 'total',
      align: 'right' as const,
      ellipsis: {
        showTitle: false,
      },
      render: (total: number) => (
        <Tooltip placement="topLeft" title={total}>
          € {total?.toLocaleString('en-US')}
        </Tooltip>
      ),
    },
    {
      title: 'STATUS',
      dataIndex: 'status',
      key: 'status',
      width: '120px',
      ellipsis: {
        showTitle: false,
      },
      render: (status: OrderType) => (
        <Tooltip placement="topLeft" title={status}>
          {getOrderStatusLabel(status)}
        </Tooltip>
      ),
    },
    {
      title: 'ACTIONS',
      key: 'actions',
      width: '120px',
      render: (record: HistoryData) => (
        <div className="actions">
          <OrderButton record={record} />
          <EditOrder record={record} />
          <button
            className="delete-btn"
            onClick={() => showConfirm(record?.key)}
            disabled={
              role !== ROLES.BACK_OFFICE &&
              role !== ROLES.ADMIN &&
              record?.status !== ORDER_STATUS.CREATED
            }
          >
            <Delete className="delete-svg" />
          </button>
        </div>
      ),
    },
  ];
  return columns;
}
