import { Table } from 'antd';
import { format, parseISO } from 'date-fns';
import React, { useEffect, useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import OrderForm from '../../components/OrderForm';
import SingleSelect from '../../components/SingleSelect';
import { ROLES } from '../../constants/enums/roles';
import { getUserRole } from '../../helpers/getUserInfo';
import notificationThrower from '../../helpers/notificationThrower';
import clientDataTransformer from '../../helpers/order/clientDataTransformer';
import getTotalPrice from '../../helpers/order/getTotalPrice';
import { HistoryData } from '../../interfaces/order';
import { selectLoggedState } from '../../redux/slices/auth/authSlice';
import { useLazyFetchAllClientsQuery } from '../../redux/slices/clients/clientsApi';
import { useLazyFetchAllOrdersQuery } from '../../redux/slices/order/orderApi';
import {
  resetOrderState,
  selectOrder,
} from '../../redux/slices/order/orderSlice';
import { HistoryTableData } from './tableData';

interface ClientOptions {
  label: string;
  value: string;
}

export const History: React.FC = () => {
  const dispatch = useDispatch();
  const form = useForm();
  const role = getUserRole();
  const total = useSelector(selectOrder);
  const { openForm } = total;
  const loggedUser = useSelector(selectLoggedState);
  const { userId } = loggedUser;

  const [tableData, setTableData] = useState([] as HistoryData[]);
  const [page, setPage] = useState<number>(0);
  const [size, setSize] = useState<number>(10);
  const [totalItems, setTotalItems] = useState<number>(0);
  const [sort, setSort] = useState<string[] | null>();
  const [clientCode, setClientCode] = useState<string | null>(null);
  const [clientOptions, setClientOptions] = useState<ClientOptions[]>([]);

  const [getAllClients, { isFetching: loadingClients }] =
    useLazyFetchAllClientsQuery();
  const [getAllOrders, { data, isFetching }] = useLazyFetchAllOrdersQuery();

  const query = {
    page,
    size,
    clientCode,
    sort,
    userId: role !== ROLES.BACK_OFFICE && role !== ROLES.ADMIN ? userId : null,
  };
  useEffect(() => {
    setTableData([]);

    getAllOrders(query);
  }, [page, size, clientCode, sort, userId]);

  useEffect(() => {
    if (data && data?.orders?.length > 0 && total) {
      setTableData(
        data?.orders?.map(order => ({
          key: order?.id,
          serial: order?.id,
          type: order?.documentType,
          date: format(parseISO(order?.documentDate), 'dd-MM-yyyy'),
          client: order?.clientCode,
          clientName: order?.f5Client?.PERSHKRIM,
          agent: order?.user?.username,
          magazine: order?.magazineCode,
          status: order?.orderStatus,
          items: order?.orderArticles
            .map(article => {
              let total = 0;
              total += article?.quantity;
              return total;
            })
            .reduce((a, b) => a + b, 0),
          total: getTotalPrice(
            order?.orderArticles?.map(
              article => article?.quantity * article?.sellingPrice,
            ),
          ),
        })),
      );
    }
    setTotalItems(data?.totalItems ?? 0);
  }, [data]);

  useEffect(() => {
    role !== ROLES.RESELLER &&
      getAllClients(0, true)
        .unwrap()
        .then(payload => {
          setClientOptions(clientDataTransformer(payload));
        })
        .catch(() => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Client Data',
          });
        });

    return () => {
      dispatch(resetOrderState());
    };
  }, []);

  const handlePageChange = (page: any, pageSize: any) => {
    setPage(page - 1);
    setSize(pageSize);
  };

  const handleShowSizeChange = (size: number) => {
    setSize(size);
  };

  const handleTableChange = (newPagination: any, filters: any, sorter: any) => {
    if (sorter?.column?.key === 'serial') {
      if (sorter?.order === 'ascend') {
        setSort(['id', 'asc']);
      } else {
        setSort(['id', 'desc']);
      }
    } else {
      setSort(null);
    }
    setClientCode(filters?.client);
  };

  const columns = HistoryTableData(query);

  return (
    <div className="history-container">
      {role !== ROLES.RESELLER && (
        <FormProvider {...form}>
          <form className="filters">
            <div className="select">
              <SingleSelect
                placeholder="Select Client"
                name="clientName"
                options={clientOptions}
                isLoading={loadingClients}
                isClearable={true}
                onChange={(option: ClientOptions) => {
                  setPage(0);
                  setClientCode(option?.value);
                }}
              />
            </div>
          </form>
        </FormProvider>
      )}
      <Table
        dataSource={tableData}
        columns={columns}
        loading={isFetching}
        pagination={{
          total: totalItems,
          onChange: handlePageChange,
          onShowSizeChange: handleShowSizeChange,
          showSizeChanger: true,
        }}
        onChange={handleTableChange}
      />
      {openForm && <OrderForm query={query} />}
    </div>
  );
};
