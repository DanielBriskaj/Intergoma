export interface LoggedUser {
  id: number;
  username: string;
  warehouse?: Warehouse;
}

export interface Login {
  userData: {
    username: string;
    password: string;
  };
}
export type UserRoles = 'AGENT' | 'BACK_OFFICE' | 'ADMIN' | 'RESELLER';
export type Warehouse = 'MQ' | 'ML' | 'MC' | 'MSH';
export interface User {
  id: number;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  role: UserRoles;
  warehouse: Warehouse;
  clientCode: string;
}
export interface UsersReturn {
  currentPage: number;
  users: User[];
  totalItems: number;
  totalPages: number;
}

export interface UsersQuery {
  page?: number;
  size?: number;
  username?: any;
  sort?: Array<string>;
}
export interface SignUp {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  role: string;
  password: string;
}
