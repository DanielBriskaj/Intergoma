import { OrderType } from '../helpers/order/orderStatusLabel';
import { UserRoles } from './users';

export interface OrderArticle {
  id: number;
  order: string;
  productCode: string;
  productType: string;
  quantity: number;
  sellingPrice: number;
  vatPercent: number;
  discountPercent: number;
  barcode: string;
  radial: string;
  size: string;
}
export interface OrderProps {
  id: number;
  documentType: string;
  note: string;
  currencyCode: string;
  documentDate: string;
  deliveryPlace: string;
  clientCode: string;
  f5Client: {
    ADRESA1: string;
    KOD: string;
    LLOGARIBANKE: string;
    NIPT: string;
    PERSHKRIM: string;
  };
  magazineCode: string;
  discountPrice: number;
  rate: number;
  serialNumber: number;
  runAs: string;
  orderArticles: Array<OrderArticle>;
  orderStatus: 'CREATED' | 'CONFIRMED';
  user: {
    id: number;
    username: string;
  };
}

export interface OrdersApiReturn {
  orders: OrderProps[];
  totalItems: number;
  currentPage: number;
  totalPages: number;
}

export interface OrdersQuery {
  page?: number;
  size?: number;
  clientCode?: string | null;
  sort?: string[] | null;
  userId?: number | null;
}

export interface ProcessOrderQuery {
  id: number;
  data: {
    orderStatus: OrderType;
  };
}

export interface HistoryData {
  key: number;
  serial: number;
  type: string;
  date: string;
  client: string;
  magazine: string;
  status: string;
  items: number;
}

export interface OrderArticleReportQuery {
  startDate?: string;
  endDate?: string;
  articleName?: string;
  clientName?: string;
  page?: number;
  size?: number;
  radial?: string;
  articleSize?: string;
}

export interface OrderArticleReportItem {
  key?: number | string;
  amount: number;
  articleCode: string;
  articleName: string;
  clientCode: string;
  clientName: string;
  currency: string;
  orderDate: string;
  price: number;
  quantity: number;
  unit?: string;
  size?: string;
  radial?: string;
  username?: string;
}
export interface OrderArticleReportItemsReturn {
  orderArticles: OrderArticleReportItem[];
  totalItems: number;
  currentPage: number;
  totalPages: number;
}

export interface OrderAgentReportItemsReturn {
  username: string;
  userId: number;
  quantity: number;
  total: number;
}

export interface OrderAgentReportQuery {
  startDate?: string;
  endDate?: string;
  detailed?: boolean;
  userRole?: UserRoles;
  userName?: string | null;
}
