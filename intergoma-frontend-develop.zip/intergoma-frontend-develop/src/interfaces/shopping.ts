export interface ShoppingData {
  key: string | number;
  id: string | number;
  brand: string;
  radial: string;
  price: number;
  description: string;
  quantity?: number;
  totalPrice?: number;
}

export type CarType = 'Veture' | '4x4' | 'Furgon' | 'Kamion' | undefined;
export type SeasonType = 'Vere' | 'Dimer' | '4Stinet' | undefined;
export interface TireCardsProps {
  id: string;
  brand: string;
  radial: string;
  price: number;
  available: number;
  description: string;
  size: string;
  favorite: boolean;
  quantity?: number;
  season: SeasonType | string;
  car: CarType | string;
  year: string;
  sap: string;
}
