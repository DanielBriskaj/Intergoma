export interface CartProps {
  title?: any;
  toggle?: any;
  visible?: boolean;
}

export interface CartItemProps {
  id: string;
  brand: string;
  quantity: number;
  price: number;
  totalPrice: number;
  description: string;
  radial: string;
  season: string;
  car: string;
  available: number;
  size: string;
  favorite: boolean;
  year: string;
  sap: string;
}
