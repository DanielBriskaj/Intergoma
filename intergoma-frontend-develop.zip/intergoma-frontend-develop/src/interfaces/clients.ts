export interface ClientsProps {
  NRRENDOR: number;
  KOD: string;
  PERSHKRIM: string;
  NIPT: string;
  NRLICENCE: string;
  PERFAQESUES: string;
  ADRESA1: string;
  ADRESA2: string;
  ADRESA3: string;
  TELEFON1: string;
  TELEFON2: string;
  FAX: string;
  KODPOSTAR: string;
  LLOGARIBANKE: string;
  KLASIFIKIM1: string;
  KLASIFIKIM2: string;
  email: string;
  internet: string;
  GRUP: string;
  KATEGORI: string;
  VENDNDODHJE: string;
  RAJON: string;
  AGJENTSHITJE: string;
  KMON: string;
  KREDI: string;
  LLOGARI: string;
  PERDORUES: string;
  FJALEKALIM: string;
  DETYRIMKLIENT: string;
}

export interface LightClientProps {
  ADRESA1: string;
  KOD: string;
  LLOGARIBANKE: string;
  NIPT: string;
  PERSHKRIM: string;
}
