export interface SendMessage {
  messageText: string;
  messageType: string;
  senderId: number;
}

export interface Message {
  id: number;
  messageText: string;
  messageType: string;
  isRead: boolean;
  receiver: { id: number; username: string };
  sender: { id: number; username: string };
  sentDate: string;
  readAt: string;
}

export interface MessagesReturn {
  currentPage: number;
  messages: Message[];
  totalItems: number;
  totalPages: number;
}

export interface MessageQuery {
  page?: number;
  size?: number;
  sentDate?: Date;
  idSender?: number;
  idReceiver?: number;
  isRead?: boolean;
  sort?: Array<string>;
}

export interface GetMessageNumberQuery {
  receiverId: number;
  isRead: boolean;
}
