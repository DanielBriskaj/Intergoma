export interface ExchangeRate {
  id?: number;
  currency?: string;
  rate: number;
}
