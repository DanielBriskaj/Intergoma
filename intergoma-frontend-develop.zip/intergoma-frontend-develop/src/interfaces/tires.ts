export interface Tire {
  favourite: boolean;
  KOD: string;
  PERSHKRIM: string;
  KLASIF: string;
  KLASIF2: string;
  KLASIF3: string;
  KLASIF4: string;
  KLASIF5: string;
  KLASIF6: string;
  CMSH19: number;
  GJENDJE: number;
  KMAG: string;
  GJENDJE2: number;
  BC: number;
  ORG: string;
}
