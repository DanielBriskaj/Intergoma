export const getCart = () => {
  return localStorage.getItem('cart')
    ? JSON.parse(localStorage.getItem('cart') as string)
    : [];
};
