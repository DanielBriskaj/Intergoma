import { ClientsProps } from '../../interfaces/clients';

const clientDataTransformer = (array: Array<ClientsProps>) => {
  return array.map(data => {
    return {
      value: data?.KOD,
      label: data?.PERSHKRIM,
      address: data?.ADRESA1,
    };
  });
};

export default clientDataTransformer;

export const clientNameOptions = (array: Array<ClientsProps>) => {
  return array.map(data => {
    return {
      value: data?.PERSHKRIM,
      label: data?.PERSHKRIM,
    };
  });
};
