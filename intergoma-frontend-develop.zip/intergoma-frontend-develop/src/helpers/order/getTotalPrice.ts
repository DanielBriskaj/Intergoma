export default function getTotalPrice(pricesArray: number[]) {
  const totalPrice = pricesArray
    ?.map(price => {
      let sum = 0;
      sum += price;
      return sum;
    })
    .reduce((a, b) => a + b, 0);

  return totalPrice;
}
