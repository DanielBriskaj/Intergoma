import { CartItemProps } from '../../interfaces/cart';
import { Warehouse } from '../../interfaces/users';

export const orderDataTransformer = (
  data: any,
  articles: Array<CartItemProps>,
  userId: number,
  warehouse?: Warehouse,
) => {
  const date = new Date();
  return {
    documentType: 'FSH',
    note: data.note,
    currencyCode: 'EUR',
    documentDate: date,
    clientCode: data.clientCode,
    user: {
      id: userId,
    },
    magazineCode: warehouse,
    discountPrice: 0,
    rate: 0,
    serialNumber: 0,
    runAs: 'admin',
    orderArticles: articles.map(item => {
      const article = {
        productCode: item.id,
        productType: item.brand,
        quantity: item.quantity,
        sellingPrice: item.price,
        vatPercent: 0,
        discountPercent: 0,
        barcode: 0,
        size: item?.size,
        radial: item?.radial,
      };
      return article;
    }),
    orderStatus: 'CREATED',
    deliveryPlace: data.deliveryPlace,
  };
};
