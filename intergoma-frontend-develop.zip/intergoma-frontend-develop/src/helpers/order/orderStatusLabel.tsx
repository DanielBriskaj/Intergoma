import React from 'react';
import { UserRoles } from '../../interfaces/users';

export type OrderType = 'CREATED' | 'CONFIRMED';

const getOrderStatusLabel = (status: OrderType) => {
  const map = {
    CREATED: {
      bg: '#ffd50a',
      text: 'CREATED',
      color: '#00316c',
    },
    CONFIRMED: {
      bg: '#4CAF50',
      text: 'CONFIRMED',
      color: '#fff',
    },
    DEFAULT: {
      bg: '#ffd50a',
      text: status,
      color: '#00316c',
    },
  };

  const { text, bg, color } = map[status] || map.DEFAULT;

  return (
    <span className="order-status" style={{ background: bg, color: color }}>
      {text}
    </span>
  );
};

export default getOrderStatusLabel;

export const geUserStatusLabel = (status: UserRoles) => {
  const map = {
    AGENT: {
      bg: '#ffd50a',
      text: 'AGENT',
      color: '#00316c',
    },
    ADMIN: {
      bg: '#4CAF50',
      text: 'ADMIN',
      color: '#fff',
    },
    BACK_OFFICE: {
      bg: '#1890ff',
      text: 'BACK OFFICE',
      color: '#fff',
    },
    RESELLER: {
      bg: '#014e9e',
      text: 'RESELLER',
      color: '#ffd50a',
    },
    DEFAULT: {
      bg: '#ffd50a',
      text: status,
      color: '#00316c',
    },
  };

  const { text, bg, color } = map[status] || map.DEFAULT;

  return (
    <span className="user-status" style={{ background: bg, color: color }}>
      {text}
    </span>
  );
};
