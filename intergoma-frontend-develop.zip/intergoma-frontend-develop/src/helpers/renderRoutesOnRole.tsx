import { NavLink } from 'react-router-dom';
import { ROLES } from '../constants/enums/roles';
import React from 'react';

const renderRoutesOnRole = (role: string, isMobile?: boolean) => {
  switch (role) {
    case ROLES.ADMIN:
      return [
        {
          label: 'Shopping',
          link: isMobile ? '/shopping-search' : '/shopping',
        },
        { label: 'Orders', link: '/orders' },
        { label: 'News', link: '/news' },
        { label: 'Favorites', link: '/favorites' },
        { label: 'Users', link: '/users' },
        { label: 'Reports', link: '/reports' },
        { label: 'Contacts', link: '/contacts' },
      ];
    case ROLES.AGENT:
      return [
        {
          label: 'Shopping',
          link: isMobile ? '/shopping-search' : '/shopping',
        },
        { label: 'Orders', link: '/orders' },
        { label: 'Messages', link: '/messages' },
        { label: 'News', link: '/news' },
        { label: 'Favorites', link: '/favorites' },
        { label: 'Contacts', link: '/contacts' },
      ];
    case ROLES.BACK_OFFICE:
      return [
        { label: 'Orders', link: '/orders' },
        { label: 'Messages', link: '/messages' },
        { label: 'News', link: '/news' },
        { label: 'Reports', link: '/reports' },
        { label: 'Contacts', link: '/contacts' },
      ];
    case ROLES.RESELLER:
      return [
        {
          label: 'Shopping',
          link: isMobile ? '/shopping-search' : '/shopping',
        },
        { label: 'Orders', link: '/orders' },
        { label: 'News', link: '/news' },
        { label: 'Favorites', link: '/favorites' },
        { label: 'Contacts', link: '/contacts' },
      ];
    default:
      return [];
  }
};
export default renderRoutesOnRole;

export const renderFooterLinks = (role: ROLES) => {
  switch (role) {
    case ROLES.ADMIN:
      return (
        <>
          <div className="three-routes">
            <NavLink to="/shopping" className={'footer-link'}>
              Shopping
            </NavLink>
            <NavLink to="/orders" className={'footer-link'}>
              Orders
            </NavLink>
            <NavLink to="/news" className={'footer-link'}>
              News
            </NavLink>
          </div>
          <div className="three-routes">
            <NavLink to="/favorites" className={'footer-link'}>
              Favorites
            </NavLink>
            <NavLink to="/users" className={'footer-link'}>
              Users
            </NavLink>
            <NavLink to="/reports" className={'footer-link'}>
              Reports
            </NavLink>
          </div>
        </>
      );
    case ROLES.AGENT:
      return (
        <>
          <div className="three-routes">
            <NavLink to="/shopping" className={'footer-link'}>
              Shopping
            </NavLink>
            <NavLink to="/orders" className={'footer-link'}>
              Orders
            </NavLink>
            <NavLink to="/messages" className={'footer-link'}>
              Messages
            </NavLink>
          </div>
          <div className="three-routes">
            <NavLink to="/news" className={'footer-link'}>
              News
            </NavLink>
            <NavLink to="/favorites" className={'footer-link'}>
              Favorites
            </NavLink>
          </div>
        </>
      );
    case ROLES.BACK_OFFICE:
      return (
        <>
          <div className="three-routes">
            <NavLink to="/orders" className={'footer-link'}>
              Orders
            </NavLink>
            <NavLink to="/messages" className={'footer-link'}>
              Messages
            </NavLink>
          </div>
          <div className="three-routes">
            <NavLink to="/news" className={'footer-link'}>
              News
            </NavLink>
            <NavLink to="/reports" className={'footer-link'}>
              Reports
            </NavLink>
          </div>
        </>
      );
    case ROLES.RESELLER:
      return (
        <>
          <div className="three-routes">
            <NavLink to="/shopping" className={'footer-link'}>
              Shopping
            </NavLink>
            <NavLink to="/orders" className={'footer-link'}>
              Orders
            </NavLink>
          </div>
          <div className="three-routes">
            <NavLink to="/news" className={'footer-link'}>
              News
            </NavLink>
            <NavLink to="/favorites" className={'footer-link'}>
              Favorites
            </NavLink>
          </div>
        </>
      );
    default:
      break;
  }
};
