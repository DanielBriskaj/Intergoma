import { Input, Space, Button } from 'antd';
import React from 'react';
import { ReactComponent as Search } from '../assets/svgIcons/search.svg';

let searchColumns = '';
export const getColumnSearchProps = (
  dataIndex: string,
  placeholder: string,
) => ({
  filterDropdown: ({
    setSelectedKeys,
    selectedKeys,
    confirm,
    clearFilters,
  }: any) => (
    <div style={{ padding: 8 }}>
      <Input
        placeholder={`Search ${placeholder}`}
        value={selectedKeys[0]}
        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
        onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
        style={{ marginBottom: 8, display: 'block' }}
      />
      <Space>
        <Button
          type="primary"
          onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
          size="small"
          style={{ width: 90 }}
        >
          Search
        </Button>
        <Button
          onClick={() => handleReset(clearFilters, confirm)}
          size="small"
          style={{ width: 90 }}
        >
          Reset
        </Button>
      </Space>
    </div>
  ),
  filterIcon: (filtered: boolean) => (
    <Search
      style={{
        width: '15px',
        height: '15px',
        color: filtered ? '#1890ff' : undefined,
      }}
    />
  ),
  onFilter: (value: any, record: any) =>
    record[dataIndex]
      ? record[dataIndex].toString().toLowerCase().includes(value.toLowerCase())
      : '',
  render: (text: any) => (searchColumns === dataIndex ? text : text),
});

const handleSearch = (
  selectedKeys: string,
  confirm: any,
  dataIndex: string,
) => {
  confirm();
  searchColumns = dataIndex;
};

const handleReset = (clearFilters: any, confirm: any) => {
  clearFilters();
  confirm();
};
