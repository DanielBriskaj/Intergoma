import * as yup from 'yup';

export const settingsSchema = yup.object().shape({
  rate: yup.number().nullable().required('Enter Rate'),
});
