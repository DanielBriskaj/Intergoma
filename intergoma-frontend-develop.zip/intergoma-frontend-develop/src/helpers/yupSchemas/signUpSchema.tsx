import * as yup from 'yup';

export const signUpSchema = yup.object().shape({
  firstName: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, `Firstname shouldn't contain special characters`)
    .matches(/^\S+$/, `Firstname shouldn't contain spaces`)
    .max(250, `250 characters max`)
    .required('Enter Firstname'),
  lastName: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, `Lastname shouldn't contain special characters`)
    .matches(/^\S+$/, `Lastname shouldn't contain spaces`)
    .max(250, `250 characters max`)
    .required('Enter Lastname'),
  email: yup
    .string()
    .nullable()
    .matches(/^\S+$/, `Email shouldn't contain spaces`)
    .email(`Email must be in format "email@example.com"`)
    .required(`Enter Email`),
  username: yup
    .string()
    .nullable()
    .min(4, `Username must be at least 4 characters`)
    .matches(/^\S+$/, `Username shouldn't contain spaces`)
    .max(20, `Username must be 20 characters maximum`)
    .required(`Enter Username`),
  password: yup
    .string()
    .nullable()
    .min(4, `Password must be at least 4 characters`)
    .max(250, '250 characters max')
    .required('Enter Password'),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref('password'), null], `Passwords don't match`)
    .required('Confirm Password'),
  role: yup.string().nullable().required('Select Role'),
  warehouse: yup.string().when('role', {
    is: 'AGENT',
    then: yup.string().nullable().required('Select Warehouse'),
    otherwise: yup.string().nullable(),
  }),
  clientCode: yup.string().when('role', {
    is: 'RESELLER',
    then: yup.string().nullable().required('Enter Client Code'),
    otherwise: yup.string().nullable(),
  }),
});

export const userSchema = yup.object().shape({
  firstName: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, `Firstname shouldn't contain special characters`)
    .matches(/^\S+$/, `Firstname shouldn't contain spaces`)
    .max(250, `250 characters max`)
    .required('Enter Firstname'),
  lastName: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, `Lastname shouldn't contain special characters`)
    .matches(/^\S+$/, `Lastname shouldn't contain spaces`)
    .max(250, `250 characters max`)
    .required('Enter Lastname'),
  email: yup
    .string()
    .nullable()
    .matches(/^\S+$/, `Email shouldn't contain spaces`)
    .email(`Email must be in format "email@example.com"`)
    .required(`Enter Email`),
  username: yup
    .string()
    .nullable()
    .min(4, `Username must be at least 4 characters`)
    .matches(/^\S+$/, `Username shouldn't contain spaces`)
    .max(20, `Username must be 20 characters maximum`)
    .required(`Enter Username`),
  role: yup.string().nullable().required('Select Role'),
  warehouse: yup.string().when('role', {
    is: 'AGENT',
    then: yup.string().nullable().required('Select Warehouse'),
    otherwise: yup.string().nullable(),
  }),
  clientCode: yup.string().when('role', {
    is: 'RESELLER',
    then: yup.string().nullable().required('Enter Client Code'),
    otherwise: yup.string().nullable(),
  }),
});
