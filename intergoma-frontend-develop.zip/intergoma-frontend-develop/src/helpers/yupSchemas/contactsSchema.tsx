import * as yup from 'yup';

export const contactsSchema = yup.object().shape({
  firstName: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, `Firstname shouldn't contain special characters`)
    .matches(/^\S+$/, `Firstname shouldn't contain spaces`)
    .max(250, `250 characters max`)
    .required('Enter Firstname'),
  lastName: yup
    .string()
    .nullable()
    .matches(/^[A-Za-z ]*$/, `Lastname shouldn't contain special characters`)
    .matches(/^\S+$/, `Lastname shouldn't contain spaces`)
    .max(250, `250 characters max`)
    .required('Enter Lastname'),
  email: yup
    .string()
    .nullable()
    .matches(/^\S+$/, `Email shouldn't contain spaces`)
    .email(`Email must be in format "email@example.com"`)
    .required(`Enter Email`),
  companyName: yup
    .string()
    .nullable()
    .max(250, `Username must be 250 characters maximum`)
    .required(`Enter Company Name`),
  phone: yup
    .string()
    .nullable()
    .matches(new RegExp('[0-9]'), `Numbers Only`)
    .min(10, 'Phone Number Too Short')
    .required('Enter Phone Number'),
  message: yup
    .string()
    .nullable()
    .max(4000, `4000 characters maximum`)
    .required(`Enter Reason Of Contact`),
});
