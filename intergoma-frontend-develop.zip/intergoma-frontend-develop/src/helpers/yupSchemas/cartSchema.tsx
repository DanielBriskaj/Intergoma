import * as yup from 'yup';

export const cartSchema = yup.object().shape({
  note: yup.string().nullable(),
  clientCode: yup.string().nullable().required('Please Select A Client'),
  deliveryPlace: yup
    .string()
    .nullable()
    .required('Please Enter The Delivery Address'),
});
