import * as yup from 'yup';

export const loginSchema = yup.object().shape({
  username: yup.string().nullable().required('Enter Username'),
  password: yup.string().nullable().required('Enter Password'),
});
