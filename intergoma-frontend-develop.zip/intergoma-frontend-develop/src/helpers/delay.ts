export const delay = () => new Promise(resolve => setTimeout(resolve, 200));
