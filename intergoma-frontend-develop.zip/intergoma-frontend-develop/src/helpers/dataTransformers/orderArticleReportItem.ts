import { OrderArticleReportItem } from '../../interfaces/order';
import { format, parseISO } from 'date-fns';

const articleReportItemTransformer = (array: Array<OrderArticleReportItem>) => {
  return array.map((item, index) => {
    return {
      key: index,
      amount: item?.amount,
      articleCode: item?.articleCode,
      articleName: item?.articleName,
      clientCode: item?.clientCode,
      clientName: item?.clientName,
      size: item?.size,
      radial: item?.radial,
      quantity: item?.quantity,
      price: item?.price,
      orderDate: format(parseISO(item?.orderDate), 'dd-MM-yyyy'),
      currency: item?.currency,
      agent: item?.username,
    };
  });
};

export default articleReportItemTransformer;
