import { Tire } from '../../interfaces/tires';

export const articleDataTransformer = (article: Tire, index: number) => {
  return {
    key: index,
    kod: article?.KOD,
    id: article?.KOD,
    brand: article?.KLASIF,
    radial: article?.KLASIF2,
    size: article?.KLASIF3 ? article?.KLASIF3 : 'N/A',
    price: article?.CMSH19 ? article?.CMSH19 : 0,
    description: article?.PERSHKRIM,
    season: article?.KLASIF4 ? article?.KLASIF4 : 'N/A',
    car: article?.KLASIF5 ? article?.KLASIF5 : 'N/A',
    available: article?.GJENDJE < 0 ? 0 : article?.GJENDJE,
    favorite: article?.favourite,
    year: article?.KLASIF6 ? article?.KLASIF6 : 'N/A',
    sap: article?.ORG ? article?.ORG : 'N/A',
  };
};
