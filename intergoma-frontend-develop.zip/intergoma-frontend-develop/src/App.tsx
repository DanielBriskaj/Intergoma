import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useRoutes } from 'react-router-dom';
import Footer from './components/Footer';
import { Navbar } from './components/Navbar/Navbar';
import { ROLES } from './constants/enums/roles';
import { getUserRole, tokenExpiry } from './helpers/getUserInfo';
import notificationThrower from './helpers/notificationThrower';
import { articleApi } from './redux/slices/articles/articlesApi';
import { useLazyLoggedUserQuery } from './redux/slices/auth/authApi';
import {
  resetLoggedState,
  selectLoggedState,
  setLoggedUser,
} from './redux/slices/auth/authSlice';
import { resetCartState } from './redux/slices/cart/cartSlice';
import { useLazyGetMessageNumberQuery } from './redux/slices/messages/messagesApi';
import {
  resetMiscellaneousState,
  updateMessageNumber,
} from './redux/slices/miscellaneous/miscellaneousSlice';
import mobileRoutes from './routes/mobileRoutes';
import routes from './routes/routes';

function App() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const expire = tokenExpiry();
  const role = getUserRole();
  const renderRoutes = useRoutes(routes);
  const renderMobileRoutes = useRoutes(mobileRoutes);
  const userData = useSelector(selectLoggedState);

  const { innerWidth: width, innerHeight: height } = window;
  const [getLoggedUser] = useLazyLoggedUserQuery();
  const [getMsgNumber] = useLazyGetMessageNumberQuery();

  const handleLogOut = () => {
    localStorage.clear();
    dispatch(resetCartState());
    dispatch(resetLoggedState());
    dispatch(resetMiscellaneousState());
    dispatch(articleApi.util.resetApiState());
    navigate('/login');
    window.location.reload();
  };
  useEffect(() => {
    window.scrollTo(0, 0);
    if (expire * 1000 < new Date().getTime()) {
      handleLogOut();
    }
    userData?.userId !== 0 &&
      role !== ROLES.ADMIN &&
      role !== ROLES.RESELLER &&
      getMsgNumber({ receiverId: userData?.userId, isRead: false })
        .unwrap()
        .then(payload => dispatch(updateMessageNumber(payload?.number)))
        .catch(error => {
          notificationThrower({
            type: 'error',
            title: 'Failed To Get Messages Count',
          });
        });
  }, [window.location.pathname]);

  useEffect(() => {
    if (localStorage.getItem('idToken')) {
      getLoggedUser()
        .unwrap()
        .then(payload => {
          dispatch(setLoggedUser(payload));
          role !== ROLES.ADMIN &&
            role !== ROLES.RESELLER &&
            getMsgNumber({ receiverId: payload?.id, isRead: false })
              .unwrap()
              .then(payload => dispatch(updateMessageNumber(payload?.number)))
              .catch(error => {
                notificationThrower({
                  type: 'error',
                  title: 'Failed To Get Messages Count',
                });
              });
        })
        .catch(error => {
          notificationThrower({
            type: 'error',
            title: 'Something Went Wrong',
          });
          handleLogOut();
        });
    }
  }, []);

  return (
    <div className="App">
      {width > 840 ? (
        <>
          <Navbar />
          <div className="global-container">{renderRoutes}</div>
          <Footer />
        </>
      ) : (
        <div className="mobile-app-container">
          <div className="image-wrapper">{renderMobileRoutes}</div>
        </div>
      )}
    </div>
  );
}

export default App;
