import React from 'react';
import { Link } from 'react-router-dom';
import { ReactComponent as Logo } from '../../assets/svgIcons/logo.svg';

export const MobileHeader: React.FunctionComponent = () => {
  return (
    <div className="mobile-header">
      <div className="logo-container">
        <Link to={localStorage.getItem('idToken') ? '/' : '/login'}>
          <Logo className="logo" />
        </Link>
      </div>
    </div>
  );
};
