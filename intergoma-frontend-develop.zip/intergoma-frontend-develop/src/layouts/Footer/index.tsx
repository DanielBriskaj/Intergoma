export { Footer as default } from './Footer';
